"""Verify completed corrected-physics reports; original cohort proof and benchmark code are unchanged."""
import hashlib
import json
import argparse
import functools
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from threading import Thread
from datetime import datetime, timezone
from pathlib import Path

from playwright.sync_api import sync_playwright


ROOT = Path(__file__).resolve().parent.parent
OUTPUT = ROOT / "report-ui"
VIEWPORT = {"width": 1600, "height": 1000}


class ReportHandler(SimpleHTTPRequestHandler):
    def log_message(self, _format, *_args):
        pass

    def do_GET(self):
        if self.path == "/favicon.ico":
            self.send_response(204)
            self.end_headers()
        else:
            super().do_GET()


def report_record(page, report_path, base_url):
    errors = {"consoleErrors": [], "pageErrors": []}
    page.on("console", lambda message: errors["consoleErrors"].append(message.text)
            if message.type == "error" else None)
    page.on("pageerror", lambda error: errors["pageErrors"].append(str(error)))
    url = f"{base_url}/{report_path.relative_to(ROOT).as_posix()}"
    page.goto(url, wait_until="load", timeout=30000)
    page.wait_for_function("window.__ODYSSEY_REPORT_READY__ === true", timeout=30000)
    embedded = json.loads(page.locator("#report-data").text_content())
    assert embedded["revision"]["head"] == "50789988ae038f5f32214869d5d4941f06235686"
    return {
        "sourceRevision": embedded["revision"],
        "path": str(report_path),
        "previewUrl": url,
        "sha256": hashlib.sha256(report_path.read_bytes()).hexdigest(),
        "verifiedAt": datetime.now(timezone.utc).isoformat(),
        "readiness": True,
        "attempts": embedded["totals"]["attempted"],
        "cards": page.locator("#cards").inner_text(),
        **errors,
    }, embedded


def verify_construction(browser, base_url):
    page = browser.new_page(viewport=VIEWPORT, device_scale_factor=1)
    record, embedded = report_record(page, ROOT / "construction" / "report.html", base_url)
    assert record["attempts"] == 0, record["attempts"]
    assert len(embedded["authoredConstruction"]) == 30
    assert page.locator("#construction-rows tr").count() == 30
    record["allRows"] = 30
    record["filteredRows"] = {}
    for policy in ["expert", "chain"]:
        page.locator("#profile").select_option(policy)
        rows = page.locator("#construction-rows tr")
        assert rows.count() == 15, (policy, rows.count())
        visible = json.loads(page.locator("#construction-data").text_content())
        assert all(demo["profileId"] == policy for demo in visible)
        assert {demo["targetDepth"] for demo in visible} == {8, 18, 12}
        assert all(demo["timed"] is False for demo in visible)
        assert all(demo["timeConstraintsStatus"] == "unverified" for demo in visible)
        assert all(demo["initialBoard"]["origin"] == "GameplayHybridEngine.createGameState authored start"
                   for demo in visible)
        assert all(demo["initialBoard"]["hash"] for demo in visible)
        assert {demo["levelId"]: demo["targetDepth"] for demo in visible} == {49: 8, 55: 18, 59: 12}
        assert any(item["scope"] == "primary" and item["type"] == "primary-acquisition-deadline"
                   for demo in visible for item in demo["timeConstraints"])
        record["filteredRows"][policy] = rows.count()
    page.locator("#profile").select_option("")
    section = page.locator("section:has(#construction-rows)")
    text = section.inner_text()
    for expected in ["Untimed", "unverified", "Normal auto-finish after primary cascade",
                     "Showcase continues after primary", "deadlines and timed stars remain unverified",
                     "Optional mastery shortfalls do not invalidate timed primary wins"]:
        assert expected in text, expected
    record["targetDepthByOrb"] = {49: 8, 55: 18, 59: 12}
    record["sourceAndTimingLabelsVerified"] = True
    page.get_by_role("heading", name="Authored-board construction diagnostics", exact=True).evaluate(
        "element => element.scrollIntoView({block: 'start'})")
    screenshot = OUTPUT / "construction-desktop.png"
    page.screenshot(path=str(screenshot), full_page=False)
    record["screenshot"] = str(screenshot)
    assert not record["consoleErrors"], record["consoleErrors"]
    assert not record["pageErrors"], record["pageErrors"]
    page.close()
    return record


def verify_duels(browser, base_url):
    page = browser.new_page(viewport=VIEWPORT, device_scale_factor=1)
    record, embedded = report_record(page, ROOT / "duels" / "report.html", base_url)
    assert record["attempts"] == 40, record["attempts"]
    assert embedded["authoredConstruction"] == []
    assert page.locator("#construction-rows tr").count() == 0
    record["constructionMessage"] = page.locator("#construction-count").inner_text()
    assert "No authored-board demonstrations recorded" in record["constructionMessage"]
    for policy in ["cascade", "duelist"]:
        page.locator("#profile").select_option(policy)
        assert page.locator("#rows tr").count() == 4
        assert page.locator("#construction-rows tr").count() == 0
    page.locator("#profile").select_option("")
    page.evaluate("window.scrollTo(0, 0)")
    screenshot = OUTPUT / "duels-desktop.png"
    page.screenshot(path=str(screenshot), full_page=False)
    record["screenshot"] = str(screenshot)
    assert not record["consoleErrors"], record["consoleErrors"]
    assert not record["pageErrors"], record["pageErrors"]
    page.close()
    return record


def verify_solo(browser, base_url):
    page = browser.new_page(viewport=VIEWPORT, device_scale_factor=1)
    record, embedded = report_record(page, ROOT / "solo" / "report.html", base_url)
    raw = [json.loads(line) for line in (ROOT / "solo" / "raw.jsonl").read_text().splitlines() if line]
    assert record["attempts"] == len(raw) == 18
    assert embedded["authoredConstruction"] == []
    assert page.locator("#construction-rows tr").count() == 0
    counts = {kind: sum(row["outcome"] == kind for row in raw) for kind in ["win", "loss", "censored", "error"]}
    assert embedded["totals"]["counts"] == counts
    quality_censored = [row for row in raw if row["qualityCensored"]]
    assert quality_censored, "This campaign must exercise a separate optional-quality cutoff"
    assert all(row["outcome"] == "win" and row["goalReached"] and not row["primaryCensored"] for row in quality_censored)
    assert embedded["totals"]["showcase"]["qualityCensored"] == len(quality_censored)
    assert embedded["totals"]["showcase"]["primaryCensored"] == 0
    record["counts"] = counts
    record["qualityCensoredWins"] = len(quality_censored)
    record["primaryCensored"] = 0
    record["qualityGroups"] = []
    for group in embedded["groups"]:
        sample = [row for row in raw if row["levelId"] == group["levelId"] and row["profileId"] == group["profileId"]]
        expected = {kind: sum(row["outcome"] == kind for row in sample) for kind in counts}
        assert group["counts"] == expected
        capped = sum(row["qualityCensored"] for row in sample)
        assert group["showcase"]["qualityCensored"] == capped
        if capped:
            assert not group["evidence"]["inconclusive"], group["evidence"]
            assert group["successRate"] == expected["win"] / (expected["win"] + expected["loss"])
            record["qualityGroups"].append({"levelId": group["levelId"], "profileId": group["profileId"], "counts": expected, "qualityCensored": capped, "successRate": group["successRate"]})
    for policy in ["cascade", "expert"]:
        page.locator("#profile").select_option(policy)
        assert page.locator("#rows tr").count() == 3
    page.locator("#profile").select_option("")
    rows = page.locator("#rows tr")
    assert rows.count() == 6
    quality_rows = rows.filter(has=page.locator("th", has_text="55 ·"))
    assert quality_rows.count() == 2
    for row in quality_rows.all():
        cells = row.locator("th, td")
        assert cells.nth(5).inner_text() == "3/0/0/0"
        assert "100%" in cells.nth(6).inner_text()
        assert "3 laps capped" in cells.nth(15).inner_text()
    assert "Primary-goal wins remain valid" in page.locator("#warnings").inner_text()
    assert "truncated showcase laps may understate final quality" in page.locator("section:has(#rows)").inner_text()
    record["primaryWinsAndQualityCensorSeparate"] = True
    page.evaluate("window.scrollTo(0, 0)")
    screenshot = OUTPUT / "solo-desktop.png"
    page.screenshot(path=str(screenshot), full_page=False)
    record["screenshot"] = str(screenshot)
    page.get_by_role("heading", name="Orb measurements", exact=True).evaluate("element => element.scrollIntoView({block: 'start'})")
    quality = OUTPUT / "solo-quality-desktop.png"
    page.locator("section:has(#rows) .table-scroll").evaluate("element => element.scrollLeft = element.scrollWidth")
    page.screenshot(path=str(quality), full_page=False)
    record["qualityScreenshot"] = str(quality)
    assert not record["consoleErrors"], record["consoleErrors"]
    assert not record["pageErrors"], record["pageErrors"]
    page.close()
    return record


def main():
    parser = argparse.ArgumentParser()
    scope = parser.add_mutually_exclusive_group()
    scope.add_argument("--construction-only", action="store_true")
    scope.add_argument("--duels-only", action="store_true")
    scope.add_argument("--solo-only", action="store_true")
    scope.add_argument("--available-only", action="store_true")
    args = parser.parse_args()
    reports = ["construction"] if args.construction_only else ["duels"] if args.duels_only else ["solo"] if args.solo_only else ["construction", "duels", "solo"]
    if args.available_only:
        reports = [report for report in reports if (ROOT / report / "report.html").is_file()]
    for relative in [f"{report}/report.html" for report in reports]:
        if not (ROOT / relative).is_file():
            raise SystemExit(f"Frozen cohort report is not ready: {ROOT / relative}")
    OUTPUT.mkdir(parents=True, exist_ok=True)
    inspection = {
        "startedAt": datetime.now(timezone.utc).isoformat(),
        "driver": "Python Playwright with system Chromium",
        "viewport": VIEWPORT,
        "status": "running",
        "reportsCheckedThisInvocation": reports,
    }
    previous_path = OUTPUT / "inspection.json"
    if previous_path.is_file():
        previous = json.loads(previous_path.read_text())
        for report in ["construction", "duels", "solo"]:
            prior = previous.get(report)
            source = ROOT / report / "report.html"
            if report not in reports and prior and source.is_file():
                if (not prior.get("consoleErrors") and not prior.get("pageErrors")
                        and prior.get("sha256") == hashlib.sha256(source.read_bytes()).hexdigest()):
                    inspection[report] = prior
    server = ThreadingHTTPServer(("127.0.0.1", 0), functools.partial(ReportHandler, directory=str(ROOT)))
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base_url = f"http://127.0.0.1:{server.server_address[1]}"
    try:
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(
                executable_path="/usr/bin/chromium", headless=True,
                args=["--no-sandbox", "--disable-dev-shm-usage"],
            )
            inspection["browserVersion"] = browser.version
            if "construction" in reports:
                inspection["construction"] = verify_construction(browser, base_url)
            if "duels" in reports:
                inspection["duels"] = verify_duels(browser, base_url)
            if "solo" in reports:
                inspection["solo"] = verify_solo(browser, base_url)
            browser.close()
        for report in reports:
            assert inspection[report]["sha256"] == hashlib.sha256((ROOT / report / "report.html").read_bytes()).hexdigest(), f"{report} changed during verification"
        inspection["currentHtmlHashesVerified"] = True
        inspection["status"] = "pass" if all(report in inspection for report in ["construction", "duels", "solo"]) else "partial-pass"
    except Exception as error:
        inspection["status"] = "fail"
        inspection["error"] = repr(error)
        raise
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)
        inspection["finishedAt"] = datetime.now(timezone.utc).isoformat()
        (OUTPUT / "inspection.json").write_text(json.dumps(inspection, indent=2) + "\n")
    print(json.dumps(inspection, indent=2))


if __name__ == "__main__":
    main()
