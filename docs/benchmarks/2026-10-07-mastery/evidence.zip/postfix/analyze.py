#!/usr/bin/env python3
"""Describe post-fix cohorts without nomination gates; verify archived source first."""
import argparse
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import zipfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load(path):
    return json.loads(path.read_text())


def require(condition, message):
    if not condition:
        raise ValueError(message)


def utf16(value):
    return value.encode("utf-16-be", errors="surrogatepass")


def read_archive(path):
    with zipfile.ZipFile(path) as archive:
        names = [item.filename for item in archive.infolist() if not item.is_dir()]
        require(len(names) == len(set(names)), f"Duplicate ZIP names: {path}")
        return {name: archive.read(name) for name in names}


def cohort_folder(root, registration, key):
    command = registration.get("commands", {}).get(key, [])
    name = Path(command[command.index("--output") + 1]).name if "--output" in command else key
    return root / name


def verify_source(root, registration):
    freeze = registration["sourceFreeze"]
    require(registration["executionReady"] is True, "Post-fix registration is not frozen")
    require(sha((root / "registration.json").read_bytes()) == (root / "registration.sha256").read_text().split()[0],
            "Post-fix registration checksum differs")
    require(sha(Path(__file__).read_bytes()) == freeze["analyzerSha256"], "Post-fix analyzer changed after freeze")
    manifest_path = root / freeze["sourceManifest"]["path"]
    require(sha(manifest_path.read_bytes()) == freeze["sourceManifest"]["sha256"], "Post-fix manifest changed")
    manifest = load(manifest_path)
    snapshot = freeze["sourceSnapshot"]
    base_path, overlay_path = root / snapshot["base"], root / snapshot["overlay"]
    require(sha(base_path.read_bytes()) == snapshot["baseSha256"], "Base source snapshot changed")
    require(sha(overlay_path.read_bytes()) == snapshot["overlaySha256"], "Source overlay changed")
    original_reg = load(root.parent / "registration.json")
    original_manifest_path = root.parent / original_reg["sourceFreeze"]["sourceManifest"]["path"]
    require(sha(original_manifest_path.read_bytes()) == original_reg["sourceFreeze"]["sourceManifest"]["sha256"],
            "Original source manifest changed")
    source = read_archive(base_path)
    original_manifest = load(original_manifest_path)
    require(set(source) == set(original_manifest), "Original ZIP/manifest names differ")
    require(all(sha(source[name]) == digest for name, digest in original_manifest.items()), "Original source bytes differ")
    overlay = read_archive(overlay_path)
    source.update(overlay)
    for name in snapshot.get("removedPaths", []):
        require(name in source, f"Unknown removed source: {name}")
        source.pop(name)
    require(set(source) == set(manifest), "Merged source/manifest paths differ")
    require(all(sha(source[name]) == digest for name, digest in manifest.items()), "Merged source bytes differ from manifest")
    application = sorted([name for name in source if (name.startswith("src/") or name in ("package.json", "package-lock.json"))
                          and re.search(r"\.(?:[cm]?[jt]s|json)$", name)], key=utf16)
    application_digest = hashlib.sha256()
    for name in application:
        application_digest.update((name + "\0").encode())
        application_digest.update(source[name])
    benchmark = ["scripts/odyssey-benchmark.mjs"] + sorted(
        [name for name in source if name.startswith("scripts/odyssey-benchmark/") and name.endswith(".mjs")], key=utf16)
    benchmark_digest = sha(b"".join(source[name] for name in benchmark))
    require(application_digest.hexdigest() == freeze["applicationHash"], "Merged-source application digest differs from CLI freeze")
    require(benchmark_digest == freeze["benchmarkHash"], "Merged-source benchmark digest differs")
    if freeze.get("sourcePatchSha256"):
        require(sha((root / "source.patch").read_bytes()) == freeze["sourcePatchSha256"], "Post-fix source patch differs")
    imported = registration["analysisImplementation"]["importedFrozenAnalyzer"]
    shared_path = root / imported["path"]
    require(sha(shared_path.read_bytes()) == imported["sha256"] == original_reg["sourceFreeze"]["analyzerSha256"],
            "Imported original metric implementation differs")
    configs = {}
    for key in ("duels", "construction", "solo"):
        path = cohort_folder(root, registration, key) / "config.json"
        if not path.exists():
            configs[key] = {"status": "not started"}
            continue
        config = load(path)
        expected = {"head": freeze["commit"], "benchmarkHash": benchmark_digest,
                    "applicationHash": application_digest.hexdigest(), "runtime": freeze["runtime"]}
        require(all(config["revision"].get(name) == value for name, value in expected.items()), f"{key} source/runtime differs")
        configs[key] = {"status": "verified", "sha256": sha(path.read_bytes()), "revision": config["revision"]}
    return {"verifiedFiles": len(source), "applicationFiles": len(application), "benchmarkFiles": len(benchmark),
            "overlayFiles": len(overlay), "applicationHash": application_digest.hexdigest(),
            "benchmarkHash": benchmark_digest, "configs": configs, "importedMetricCodeUnchanged": True}, shared_path


def normalized_registration(registration, shared_path):
    """Adapt the new descriptive cohort schema to unchanged old metric functions.

    The shared function verifies its own immutable code hash; this wrapper's code
    and full source verification are separately checked before calling it.
    """
    duel, construction = registration["timedDuels"], registration["construction"]
    freeze = copy.deepcopy(registration["sourceFreeze"])
    freeze["analyzerSha256"] = sha(shared_path.read_bytes())
    return {"executionReady": registration["executionReady"], "sourceFreeze": freeze,
            "duelScreen": {**duel, "seeds": {"from": min(duel["seeds"]), "to": max(duel["seeds"])},
                "attemptsPerOrbProfile": len(duel["seeds"]), "opponentPlanningPolicy": duel["opponentKnowledgePolicy"],
                "earlyPacingRecommendation": {"levels": [], "gatesPerOrb": {}}},
            "constructionScreen": {"profiles": construction["profiles"], "seeds": construction["seeds"],
                "maxPieces": construction["maxPieces"],
                "authored": {"levels": construction["authoredLevels"],
                    "primaryChainQuestions": construction["authoredEffectiveThreeStarChainTargets"]},
                "empty": {"modes": construction["emptyModes"], "targetDepth": construction["emptyTargetDepth"],
                    "recordedDepthTargets": construction["recordedDepthTargets"]}}}


def descriptive_duels(shared, folder, normalized):
    result = shared.analyze_duels(folder, normalized)
    result.pop("eligibleForGeneralEarlyConfirmationReview", None)
    for orb in result.get("orbs", []):
        orb.pop("earlyScreenGates", None)
        orb.pop("eligibleForOrbSpecificConfirmationReview", None)
    result["nominationGatesApplied"] = False
    result["interpretation"] = "Five-pair cells, corrected physics, descriptive only. No old ten-pair screen gates apply."
    return result


def analyze_solo(shared, folder, registration, normalized):
    path = folder / "config.json"
    if not path.exists():
        return {"status": "not started"}
    config, rule = load(path), registration["timedSolo"]
    errors = shared.provenance(config, normalized)
    for field, expected in {"levelIds": rule["levels"], "profileIds": rule["profiles"],
                           "cadenceIds": rule["cadences"], "scenarioIds": rule["scenarios"],
                           "samples": rule["samplesPerOrbProfile"], "seedStart": min(rule["seeds"]),
                           "plannedAttempts": rule["plannedAttempts"], "lapWindowSeconds": rule["lapWindowSeconds"],
                           **rule["budgets"]}.items():
        shared.assert_equal(errors, field, config.get(field), expected)
    raw = folder / "raw.jsonl"
    rows = [json.loads(line) for line in raw.read_text().splitlines() if line.strip()] if raw.exists() else []
    expected_keys = {(orb, policy, seed) for orb in rule["levels"] for policy in rule["profiles"] for seed in rule["seeds"]}
    indexed, row_errors = {}, []
    for row in rows:
        key = (row.get("levelId"), row.get("profileId"), row.get("seed"))
        if key not in expected_keys or key in indexed:
            errors.append({"field": "attempt keys", "key": key, "reason": "unexpected or duplicate"})
            continue
        indexed[key] = row
        details = []
        for field, expected in {"scenarioId": "baseline", "cadenceId": "steady", "humanPlanningPreviewLimit": 3}.items():
            shared.assert_equal(details, field, row.get(field), expected)
        if row.get("outcome") == "win":
            if not shared.finite(row.get("goalReachedAtSeconds")) or row.get("goalReached") is not True:
                details.append({"field": "primary acquisition", "reason": "win without recorded goal"})
            if row.get("primaryCensored"):
                details.append({"field": "primary censor", "reason": "a quality-limited win cannot be primary-censored"})
        if details:
            row_errors.append({"key": key, "errors": details})
    groups = []
    for orb in rule["levels"]:
        for policy in rule["profiles"]:
            group = [indexed[(orb, policy, seed)] for seed in rule["seeds"] if (orb, policy, seed) in indexed]
            wins = [row for row in group if row.get("outcome") == "win"]
            complete_quality = [row for row in wins if not shared.quality_censored(row)]
            capped_quality = [row for row in wins if shared.quality_censored(row)]
            observations = []
            for row in group:
                goal_time, elapsed = row.get("goalReachedAtSeconds"), row.get("elapsedSeconds")
                quality_duration = elapsed - goal_time if shared.finite(goal_time) and shared.finite(elapsed) else None
                observations.append({"seed": row["seed"], "outcome": row.get("outcome"), "reason": row.get("reason"),
                    "primaryReached": row.get("goalReached"), "primaryAcquisitionSeconds": goal_time,
                    "primaryCensored": bool(row.get("primaryCensored") or row.get("outcome") == "censored"),
                    "terminalSeconds": elapsed, "goalMetrics": row.get("goalMetrics"), "terminalMetrics": row.get("metrics"),
                    "goalStars": row.get("goalStars"), "observedStars": row.get("stars"),
                    "qualityCensored": shared.quality_censored(row), "qualityObservationSeconds": quality_duration,
                    "qualityEndReason": row.get("lapEndReason"), "showcaseFinishPolicy": row.get("showcaseFinishPolicy")})
            groups.append({"levelId": orb, "profile": policy, "planned": len(rule["seeds"]), "recorded": len(group),
                "primaryOutcomes": shared.count(row.get("outcome") for row in group),
                "lossReasons": shared.count(row.get("reason") for row in group if row.get("outcome") == "loss"),
                "primaryAcquisitionSecondsAmongWins": shared.describe(row.get("goalReachedAtSeconds") for row in wins),
                "primaryWinsWithCensoredQuality": len(capped_quality),
                "observedStarsCompleteQuality": shared.count(row.get("stars") for row in complete_quality),
                "observedStarsCensoredQuality": shared.count(row.get("stars") for row in capped_quality),
                "observations": observations})
    return {"status": "completed" if set(indexed) == expected_keys else "incomplete", "revision": config.get("revision"),
            "plannedAttempts": len(expected_keys), "recordedAttempts": len(rows), "missingAttempts": sorted(expected_keys - set(indexed)),
            "validationErrors": errors, "rowValidationErrors": row_errors, "groups": groups,
            "qualityWindowSeconds": 30, "nominationGatesApplied": False, "productionRetuneSelected": False,
            "interpretation": "Primary acquisition is separate from a capped quality observation. Quality censoring never converts a recorded win to an unfinished primary. No full-star or live finish-limit claim."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--verify-only", action="store_true")
    args = parser.parse_args()
    root = args.root.resolve()
    registration = load(root / "registration.json")
    verification, shared_path = verify_source(root, registration)
    if args.verify_only:
        print(json.dumps(verification, indent=2, sort_keys=True))
        return
    spec = importlib.util.spec_from_file_location("frozen_prefixed_metrics", shared_path)
    shared = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(shared)
    normalized = normalized_registration(registration, shared_path)
    result = {"schemaVersion": 1, "interpretation": "Post-fix descriptive coverage only; no pre-fix pooling, nomination gates or human fairness claim.",
              "sourceVerification": verification,
              "metricImplementation": {"wrapperSha256": sha(Path(__file__).read_bytes()), "importedFrozenAnalyzerSha256": sha(shared_path.read_bytes()),
                   "schemaAdaptation": "Use post-fix sample counts; imported functions verify their own immutable analyzer hash. Source/runtime and wrapper hash are independently verified before analysis."},
              "duels": descriptive_duels(shared, cohort_folder(root, registration, "duels"), normalized),
              "construction": shared.analyze_construction(cohort_folder(root, registration, "construction"), normalized),
              "solo": analyze_solo(shared, cohort_folder(root, registration, "solo"), registration, normalized)}
    paths = [root / "registration.json", root / "registration.sha256", Path(__file__).resolve(), shared_path,
             root / "source-manifest.json", root / "source-overlay.zip", root / "source.patch",
             root.parent / "source-snapshot.zip", root.parent / "source-manifest.json", root.parent / "registration.json"]
    for key in ("duels", "construction", "solo"):
        paths.extend(cohort_folder(root, registration, key) / name for name in ("config.json", "raw.jsonl", "capabilities.json"))
    result["inputHashes"] = {os.path.relpath(path.resolve(), root): sha(path.read_bytes()) for path in paths if path.exists()}
    (root / "analysis.json").write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"output": str(root / "analysis.json"), **{key: result[key]["status"] for key in ("duels", "construction", "solo")}}))


if __name__ == "__main__":
    main()
