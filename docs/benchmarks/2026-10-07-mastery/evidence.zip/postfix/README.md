# Corrected-physics mastery follow-up — 2026-10-07

Status: **frozen before execution at 2026-10-07 16:18:06 UTC, commit `5078998`**.
The source manifest, base-plus-overlay snapshot, exact CLI digests and external
registration checksum were verified before any post-fix cohort began.

The initial registration and all observations in the parent directory remain
**PRE-FIX evidence**. Four authored construction traces exposed a cell-loss defect;
their invalid outcomes are retained. This fresh continuation neither replaces those
traces nor pools initial and corrected-physics measurements. The new seeds differ,
so it is not a paired before/after efficacy comparison.

## Registered fresh cohorts

| Cohort | Conditions | Seeds | Count |
| --- | --- | --- | --- |
| Untimed construction | Expert/chain × empty Standard/Infinity and authored orbs 49/55/59; 128 pieces, empty target depth 18. | 10101–10105 | 50 runs |
| Timed duels | Cascade/duelist × orbs 4/9/53/58 × steady cadence, production opponent's real full queue and three player previews. | 10101–10105 | 40 attempts, five pairs per orb |
| Timed solo primary sanity | Cascade/expert × orbs 49/55/59 × steady cadence; explicit 30-second post-goal quality window. | 10101–10103 | 18 attempts |

The single construction command creates twenty empty and thirty authored runs once.
The duel CLI's ordinary twelve preflight empty probes use cascade/duelist,
Standard/Infinity and seeds 1001–1003 at forty pieces; they are instrument checks,
excluded from these fifty fresh construction runs. Four isolated defect fixtures
replayed through legacy and fixed physics are eight separate regression executions,
not fresh mastery samples. Seeds 11001 onward remain reserved.
The solo CLI also has twelve ordinary default-seed capability probes, excluded from
the fifty registered fresh constructions. Total fresh coverage is 108 observations:
fifty untimed constructions and 58 timed gameplay attempts.

## Source freeze and commands

Commit the correction, capture the manifest/source snapshot and record the exact
runtime and CLI fingerprints before execution. For the application digest, sort
**full repository-relative strings**, matching JavaScript UTF-16 string ordering.
Do not use the path-component ordering that caused the initial clerical mismatch.
Independently compute the same digest from archived bytes and require equality.
The original preregistration and its explicit correction record remain immutable.
Reuse the parent source snapshot as a base, apply the post-fix source overlay in
memory, and verify every resulting file against the full post-fix manifest. The
post-fix source patch separately preserves the correction and its tests.

After freeze, use new output directories:

```bash
npm run benchmark:odyssey -- \
  --capabilities-only \
  --levels 49,55,59 \
  --profiles expert,chain \
  --construction-levels 49,55,59 \
  --construction-seeds 10101,10102,10103,10104,10105 \
  --construction-pieces 128 \
  --output artifacts/odyssey-mastery-followup-2026-10-07/postfix/construction

npm run benchmark:odyssey -- \
  --levels 4,9,53,58 \
  --profiles cascade,duelist \
  --scenarios baseline \
  --cadences steady \
  --samples 5 \
  --seed-start 10101 \
  --workers 3 \
  --wall-ms 240000 \
  --max-seconds 1800 \
  --max-pieces 3000 \
  --output artifacts/odyssey-mastery-followup-2026-10-07/postfix/duels

npm run benchmark:odyssey -- \
  --levels 49,55,59 \
  --profiles cascade,expert \
  --scenarios baseline \
  --cadences steady \
  --samples 3 \
  --seed-start 10101 \
  --workers 3 \
  --wall-ms 240000 \
  --max-seconds 1800 \
  --max-pieces 3000 \
  --lap-seconds 30 \
  --output artifacts/odyssey-mastery-followup-2026-10-07/postfix/solo
```

Three duel workers may run alongside one construction driver. Keep the registered
budgets fixed and report any resource censor. The untimed construction driver has
no per-demonstration wall deadline; its bound is 128 pieces. An external interruption
is incomplete evidence and cannot silently disappear or become a replacement run.

## What the construction probes establish

Use authentic authored starting boards, scoring levels, modifiers, seeded bags and
three-preview planning. Retain normal orb 49's auto-finish after the entire
primary-winning resolution; retain showcase continuation on 55/59. Record goal
acquisition, termination, score, cascade/Quad counts, maximum depth/combo, individual
requirements and full untimed-condition coverage. The relevant authored three-star
wave targets are 8/18/12; depth alone cannot qualify the other requirements.

Check conservation, legal actions, unchanged planning state, board-hash continuity,
real top-out and fully drained resolution. No cells or placements may be inserted
after initialization. Distinguish legal grounded soft-drop stops from failed moves.
Preserve every invalid/incomplete trace and its reason separately from actual game
losses. Do not infer that a missed target is impossible.

These probes have no competing gravity or advancing clock. Presentation waits are
suppressed, and zero held time awards the maximum production 50-point lock bonus.
Deadlines, survival duration and timed stars remain unvalidated. Empty and authored
contexts stay separate, and the 128-piece cutoff is not a new live showcase limit.

## Descriptive duel reporting

Report each orb/policy and all five seed pairs, including primary/quality censors,
errors, paired win transitions, real seven-frag attribution, stars, attacks per human
piece, input failures and automatic locks. Compute successful duration only on the
identical both-win seed set, with median and nearest-rank p90 at `ceil(0.9 × n)`;
show the sample count and individual observations. Keep defeat duration separate.

There are **no nomination or retuning gates** in this post-fix continuation. The old
ten-pair screen's 15%/10% thresholds do not carry over to these five-pair cells.
Do not interpret a stronger synthetic player as a production balance improvement,
and do not pool old and corrected physics. This is mechanical validation and
descriptive policy coverage, not a human fairness assessment or statistical efficacy
claim. Any later balance decision needs its own registration and fresh confirmation.

## Timed solo primary sanity

The eighteen solo attempts exercise actual gravity, input timing and the corrected
physics at orb 49's normal finish, orb 55's showcase and orb 59's acquisition deadline.
Report primary outcome and `goalReachedAtSeconds` separately from terminal elapsed
time. The explicit 30-second post-goal window can truncate quality; the benchmark's
acquisition cutoff or resource budget can end observation earlier. A quality censor
must not relabel an acquired primary win as unfinished. Observed stars in this window
do not establish full mastery fairness or a live showcase finish limit.

These three-seed cells have no efficacy or retuning threshold and are not paired with
old physics. Their role is to check real timed behavior that untimed construction
cannot establish.

## Reproducible analysis

The post-fix `analyze.py` verifies the frozen source by merging the unchanged parent
ZIP with `source-overlay.zip`, checking all manifest hashes and exact CLI digests,
then checking each cohort's source/runtime/config. It reuses the original immutable
duel/construction metric functions with the newly registered sample counts and no
nomination gates. Solo primary and truncated quality observations are separate.
`--verify-only` checks source/config provenance without reading outcome files.

```bash
python artifacts/odyssey-mastery-followup-2026-10-07/postfix/analyze.py
```
