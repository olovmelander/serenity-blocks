"""Freeze the corrected physics using exact CLI hashing and an independently verified source overlay."""
import datetime,hashlib,json,subprocess,zipfile
from pathlib import Path
root=Path(__file__).resolve().parent
repo=root.parents[2]
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
def sha(data):return hashlib.sha256(data).hexdigest()
node=r'''
import {execFileSync} from 'node:child_process';
import {readFileSync,readdirSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
const hash=b=>createHash('sha256').update(b).digest('hex');
const bench=['scripts/odyssey-benchmark.mjs',...readdirSync('scripts/odyssey-benchmark').filter(n=>n.endsWith('.mjs')).sort().map(n=>'scripts/odyssey-benchmark/'+n)];
const app=execFileSync('git',['ls-files','-z','--cached','--others','--exclude-standard','--','src','package.json','package-lock.json'],{encoding:'utf8'}).split('\0').filter(f=>/\.(?:[cm]?[jt]s|json)$/.test(f)).sort();
const b=createHash('sha256'),a=createHash('sha256');
for(const f of bench)b.update(readFileSync(f));
for(const f of app){a.update(f+'\0');a.update(existsSync(f)?readFileSync(f):'<deleted>');}
console.log(JSON.stringify({head:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),benchmarkHash:b.digest('hex'),applicationHash:a.digest('hex'),runtime:{node:process.version,platform:process.platform,arch:process.arch},bench,app,manifest:Object.fromEntries([...bench,...app].map(f=>[f,hash(readFileSync(f))]))}));
'''
meta=json.loads(subprocess.check_output(['node','--input-type=module','-e',node],cwd=repo))
assert not git('diff','HEAD','--','src','scripts','tests','package.json','package-lock.json')
reg=json.loads((root/'registration.json').read_text());assert not reg['executionReady']
manifest=meta['manifest'];(root/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
base_path=root.parent/'source-snapshot.zip';overlay_path=root/'source-overlay.zip'
with zipfile.ZipFile(base_path) as base:
 old={name:base.read(name) for name in base.namelist()}
removed=sorted(set(old)-set(manifest))
with zipfile.ZipFile(overlay_path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as overlay:
 for name,digest in manifest.items():
  data=(repo/name).read_bytes();assert sha(data)==digest
  if name not in old or sha(old[name])!=digest:overlay.writestr(name,data)
with zipfile.ZipFile(overlay_path) as overlay:
 source={**old,**{name:overlay.read(name) for name in overlay.namelist()}}
for name in removed:del source[name]
assert set(source)==set(manifest)
assert all(sha(source[name])==digest for name,digest in manifest.items())
a=hashlib.sha256()
for name in sorted(meta['app'],key=lambda value:value.encode('utf-16-be')):
 a.update((name+'\0').encode());a.update(source[name])
assert a.hexdigest()==meta['applicationHash']
assert sha(b''.join(source[name] for name in meta['bench']))==meta['benchmarkHash']
patch=git('diff','--binary',reg['sourceFreeze']['baseCommit'],'HEAD','--','src','scripts','tests','package.json','package-lock.json')
(root/'source.patch').write_bytes(patch)
reg['sourceFreeze'].update({'frozenAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commit':meta['head'],'benchmarkHash':meta['benchmarkHash'],'applicationHash':meta['applicationHash'],'runtime':meta['runtime'],'analyzerSha256':sha((root/'analyze.py').read_bytes()),'sourceManifest':{'path':'source-manifest.json','sha256':sha((root/'source-manifest.json').read_bytes())},'sourceSnapshot':{'base':'../source-snapshot.zip','overlay':'source-overlay.zip','removedPaths':removed,'baseSha256':sha(base_path.read_bytes()),'overlaySha256':sha(overlay_path.read_bytes())},'sourcePatchSha256':sha(patch),'registrationSha256RecordedExternally':True})
prefix='artifacts/odyssey-mastery-followup-2026-10-07/postfix/'
reg['commands']={
'duels':['node','scripts/odyssey-benchmark.mjs','--levels','4,9,53,58','--profiles','cascade,duelist','--cadences','steady','--samples','5','--seed-start','10101','--workers','3','--max-seconds','1800','--max-pieces','3000','--wall-ms','240000','--output',prefix+'duels'],
'construction':['node','scripts/odyssey-benchmark.mjs','--capabilities-only','--levels','49,55,59','--profiles','expert,chain','--construction-levels','49,55,59','--construction-seeds','10101,10102,10103,10104,10105','--construction-pieces','128','--output',prefix+'construction'],
'solo':['node','scripts/odyssey-benchmark.mjs','--levels','49,55,59','--profiles','cascade,expert','--cadences','steady','--samples','3','--seed-start','10101','--workers','3','--max-seconds','1800','--max-pieces','3000','--wall-ms','240000','--lap-seconds','30','--output',prefix+'solo']}
reg['executionReady']=True;reg['status']='frozen-before-corrected-physics-observations'
(root/'registration.json').write_text(json.dumps(reg,indent=2)+'\n')
(root/'registration.sha256').write_text(sha((root/'registration.json').read_bytes())+'  registration.json\n')
print(json.dumps(reg['sourceFreeze'],indent=2))
