# Odyssey gameplay benchmark

**Preliminary pilot.** All policies are synthetic; results do not establish human skill rates, calibrated difficulty, fairness or fun.

Revision: 50789988ae03 · benchmark c344f45980a5 · working tree implementation. Orbs: 3/3. Attempts: 18. W/L/C/E: 17/1/0/0.

**Terminal win rate is conditional on completion.** Always read completion coverage and unresolved-outcome bounds beside it. Selective time/CPU caps can bias the rate.

## Run configuration

```json
{
  "levelIds": [
    49,
    55,
    59
  ],
  "profileIds": [
    "cascade",
    "expert"
  ],
  "scenarioIds": [
    "baseline"
  ],
  "cadenceIds": [
    "steady"
  ],
  "constructionLevelIds": [],
  "constructionSeeds": [
    1001,
    1002,
    1003
  ],
  "constructionMaxPieces": 40,
  "samples": 3,
  "seedStart": 10101,
  "workers": 3,
  "maxSimSeconds": 1800,
  "maxPieces": 3000,
  "wallBudgetMs": 240000,
  "lapWindowSeconds": 30,
  "outputDir": "/workspace/serenity-blocks/artifacts/odyssey-mastery-followup-2026-10-07/postfix/solo",
  "resume": false,
  "trace": false,
  "capabilitiesOnly": false,
  "help": false,
  "plannedAttempts": 18,
  "clock": "legacy-variable-v1 at controlled 60 Hz",
  "visiblePreviews": 3,
  "humanPlanningPreviewLimit": 3,
  "opponentKnowledgePolicy": "production-full-real-bag",
  "opponentVisiblePreviewCount": 3,
  "opponentPlanningPreviewLimit": null,
  "syntheticProfiles": true,
  "revision": {
    "head": "50789988ae038f5f32214869d5d4941f06235686",
    "benchmarkHash": "c344f45980a57811339d9f3f370a5505385143fa185745a9130f9968607783f5",
    "applicationHash": "3d1e7e953bb3a42a8bf20418780d7099e5dd849982282fb9270141038273373f",
    "runtime": {
      "node": "v24.19.0",
      "platform": "linux",
      "arch": "x64"
    },
    "workingTreeImplementation": true
  },
  "scenarios": [
    {
      "id": "baseline",
      "label": "Authored rules",
      "levelIds": null,
      "description": "Unchanged authored rules."
    }
  ],
  "cadences": [
    {
      "id": "steady",
      "label": "Steady pace",
      "description": "Uses the same moderate input timing for every strategy.",
      "reactionMs": [
        120,
        180
      ],
      "actionIntervalMs": 100
    }
  ],
  "effectiveLevels": [
    {
      "scenarioId": "baseline",
      "level": {
        "id": 49,
        "name": "Fluid Dreams",
        "chapter": 7,
        "chapterLevel": 1,
        "isChapterStart": true,
        "isChapterEnd": false,
        "pathPosition": 0.815,
        "theme": {
          "primary": "fluid-dreams",
          "overlays": [],
          "transitionIn": "crossfade",
          "transitionDuration": 4000
        },
        "mechanics": {
          "baseMode": "standard",
          "board": {
            "columns": 10,
            "rows": 20,
            "startingRows": 0
          },
          "speed": {
            "startLevel": 7,
            "levelProgression": true,
            "fixedDropInterval": null
          },
          "pieces": {
            "bagType": "7-bag",
            "customSequence": null,
            "previewCount": 5
          }
        },
        "victory": {
          "primary": {
            "type": "score",
            "target": 36000
          },
          "failure": {
            "type": "top-out",
            "value": null
          },
          "bonuses": [
            {
              "type": "tetris-count",
              "target": 12,
              "description": "Clear 12 Quads"
            },
            {
              "type": "combo",
              "target": 8,
              "description": "Reach 8x combo"
            }
          ]
        },
        "modifiers": {
          "active": [
            "combo-multiplier"
          ]
        },
        "stars": {
          "one": {
            "score": 36000
          },
          "two": {
            "score": 36000,
            "tetrises": 8
          },
          "three": {
            "score": 36000,
            "tetrises": 12,
            "combo": 8
          }
        },
        "metadata": {
          "description": "Reality softens into fluid motion. Let the first abstract chapter beat feel strange, but not yet hostile.",
          "difficulty": 8,
          "tip": "Trust the score game you already know. The visuals change first; the discipline stays the same.",
          "difficultyModel": {
            "scalar": 0.605,
            "band": "tough"
          }
        },
        "role": "arrival",
        "mechanicFocus": "score",
        "emotionalBeat": "awe",
        "victoryLapPolicy": "none"
      }
    },
    {
      "scenarioId": "baseline",
      "level": {
        "id": 55,
        "name": "Singularity Void",
        "chapter": 7,
        "chapterLevel": 7,
        "isChapterStart": false,
        "isChapterEnd": true,
        "pathPosition": 0.926,
        "theme": {
          "primary": "singing-bowl",
          "overlays": [
            "electric-dreams-v3",
            "black-hole"
          ],
          "transitionIn": "warp",
          "transitionDuration": 6000
        },
        "mechanics": {
          "baseMode": "infinity",
          "board": {
            "columns": 10,
            "rows": 100,
            "startingRows": 30
          },
          "speed": {
            "startLevel": 12,
            "levelProgression": false,
            "fixedDropInterval": 500
          },
          "pieces": {
            "bagType": "7-bag",
            "customSequence": null,
            "previewCount": 5
          }
        },
        "victory": {
          "primary": {
            "type": "score",
            "target": 250000
          },
          "failure": {
            "type": "time",
            "value": 480
          },
          "bonuses": [
            {
              "type": "max-cascade-depth",
              "target": 10,
              "description": "Trigger a 10-chain cascade"
            },
            {
              "type": "cascade",
              "target": 30,
              "description": "Trigger 30 cascades"
            },
            {
              "type": "tetris-count",
              "target": 20,
              "description": "Clear 20 Quads"
            },
            {
              "type": "combo",
              "target": 18,
              "description": "Reach 18x combo"
            }
          ]
        },
        "modifiers": {
          "active": [
            "gravity-cascade",
            "combo-multiplier"
          ]
        },
        "stars": {
          "one": {
            "score": 250000
          },
          "two": {
            "score": 350000,
            "cascades": 25,
            "maxCascadeDepth": 6
          },
          "three": {
            "score": 500000,
            "cascades": 35,
            "maxCascadeDepth": 10,
            "combo": 18
          }
        },
        "metadata": {
          "description": "The final abstract challenge. Build epic towers on a 100-row board and trigger legendary cascades.",
          "difficulty": 10,
          "tip": "Use the full height of the board. The bigger the tower, the greater the cascade!",
          "difficultyModel": {
            "scalar": 1,
            "band": "brutal"
          }
        },
        "role": "boss",
        "mechanicFocus": "hybrid",
        "emotionalBeat": "transcendence",
        "victoryLapPolicy": "showcase"
      }
    },
    {
      "scenarioId": "baseline",
      "level": {
        "id": 59,
        "name": "Electric Apex",
        "chapter": 8,
        "chapterLevel": 4,
        "isChapterStart": false,
        "isChapterEnd": true,
        "pathPosition": 1,
        "theme": {
          "primary": "neon-district",
          "overlays": [],
          "transitionIn": "warp",
          "transitionDuration": 2500
        },
        "mechanics": {
          "baseMode": "hybrid",
          "board": {
            "columns": 10,
            "rows": 30,
            "startingRows": 5
          },
          "speed": {
            "startLevel": 11,
            "levelProgression": true,
            "fixedDropInterval": null
          },
          "pieces": {
            "bagType": "7-bag",
            "customSequence": null,
            "previewCount": 4
          }
        },
        "victory": {
          "primary": {
            "type": "score",
            "target": 160000
          },
          "failure": {
            "type": "time",
            "value": 210
          },
          "bonuses": [
            {
              "type": "cascade",
              "target": 25,
              "description": "Trigger 25 cascades"
            },
            {
              "type": "max-cascade-depth",
              "target": 7,
              "description": "Trigger a 7-chain cascade"
            },
            {
              "type": "combo",
              "target": 12,
              "description": "Reach 12x combo"
            }
          ]
        },
        "modifiers": {
          "active": [
            "gravity-cascade",
            "combo-multiplier",
            "time-attack"
          ]
        },
        "stars": {
          "one": {
            "score": 160000
          },
          "two": {
            "score": 200000,
            "cascades": 20,
            "combo": 10
          },
          "three": {
            "score": 260000,
            "cascades": 25,
            "maxCascadeDepth": 7,
            "combo": 12
          }
        },
        "metadata": {
          "description": "The bonus chapter finale turns the city into a high-voltage arena. Push for one last spectacular score run.",
          "difficulty": 10,
          "tip": "Treat the opening stack like fuel. Convert it into momentum fast, then keep the combo engine alive as long as you can.",
          "difficultyModel": {
            "scalar": 0.801,
            "band": "brutal"
          }
        },
        "role": "encore",
        "mechanicFocus": "hybrid",
        "emotionalBeat": "transcendence",
        "victoryLapPolicy": "showcase"
      }
    }
  ]
}
```

## Measurements

| Orb | Synthetic policy | Scenario | Cadence | Evidence | W/L/C/E | Terminal win % | Wilson 95% | Completion | Overall win bounds | Terminal seconds median/p90 | Stars 1/2/3 | Median goal gap |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 49 · Fluid Dreams | Cascade builder | baseline | steady | pilot | 3/0/0/0 | 100% | 44%–100% | 3/3 (100%) | 100%–100% | 72.5 / 75.0 | 3/0/0 | 0.0 |
| 49 · Fluid Dreams | Objective specialist | baseline | steady | pilot | 3/0/0/0 | 100% | 44%–100% | 3/3 (100%) | 100%–100% | 58.5 / 59.5 | 3/0/0 | 0.0 |
| 55 · Singularity Void | Cascade builder | baseline | steady | pilot | 3/0/0/0 | 100% | 44%–100% | 3/3 (100%) | 100%–100% | 367.6 / 384.1 | 3/0/0 | 0.0 |
| 55 · Singularity Void | Objective specialist | baseline | steady | pilot | 3/0/0/0 | 100% | 44%–100% | 3/3 (100%) | 100%–100% | 311.8 / 330.8 | 3/0/0 | 0.0 |
| 59 · Electric Apex | Cascade builder | baseline | steady | pilot | 2/1/0/0 | 67% | 21%–94% | 3/3 (100%) | 67%–67% | 210.1 / 210.4 | 2/0/0 | 0.0 |
| 59 · Electric Apex | Objective specialist | baseline | steady | pilot | 3/0/0/0 | 100% | 44%–100% | 3/3 (100%) | 100%–100% | 210.0 / 210.1 | 3/0/0 | 0.0 |

## Authored-board construction diagnostics

These separate untimed demonstrations do not change timed primary wins or award stars. The target is the maximum recorded combo/depth requirement across primary, stars and bonuses; it is not necessarily needed to finish the orb. Timing constraints remain unverified.

| Orb | Policy | Seed | Authored start | Target depth | Observed depth | Trace | Finish policy | Stop | Timing | Time constraints |
|---|---|---|---|---|---|---|---|---|---|---|
No authored-board demonstrations recorded.

Recorded starting boards, exact requirements and unverified time constraints:

```json
[]
```

## Matched baseline versus variant


## Review candidates

No review candidates flagged. The sample/coverage thresholds may not be met; this does not establish a smooth curve.

## Method and limits

- Duel opponent planning: 0 production full-queue, 0 historical three-preview, 0 unrecorded observations. HUD preview counts do not establish planning limits. Mixed known policies cannot share an orb/policy/scenario/cadence group; mismatched policies are excluded from paired deltas.
- Wins divided by actual terminal wins + losses only. Censored attempts and errors are excluded from this conditional rate, never counted as losses.
- Completed terminal outcomes divided by all attempted runs. Selective censoring, including high CPU cost, can bias conditional rates.
- Deterministic all-attempt win bounds: wins/N to (wins+censored+errors)/N. These are unresolved-outcome bounds, not confidence intervals.
- 95% Wilson binomial score intervals are limited to a single orb, synthetic policy, scenario and cadence on terminal outcomes. Pooled totals/profile summaries are descriptive across heterogeneous orbs and reused seeds; their intervals are null.
- Median, p90 and p95 active virtual seconds; terminal, win, loss and censored durations are separated. Quantiles use linear interpolation.
- Counts use stars observed at benchmark stop on completed wins only. Truncated optional showcase laps may understate eventual star quality.
- Showcases follow the authored deadline by default (lapWindowSeconds null). An explicit window or harness budget censors quality separately: a completed primary goal remains a terminal win. A goalReached field by itself does not turn a censored attempt into a win.
- Policy comparisons hold orb, scenario and cadence fixed. Baseline-versus-variant comparisons also hold policy fixed. Only the same bag/board seeds are paired; unresolved or duplicate pairs are excluded from terminal deltas.
- Missing scenario/cadence IDs default to baseline/native. Experiment conditions stay separate in groups, profile summaries, heatmaps, curves and matched comparisons.
- Duel throughput uses measured sent attack rows per active minute and per whole virtual match minute. Round summaries distinguish completed and partial rounds. Perfect-clear rows are not cancellation counts.
- Review candidates require >=20 terminal attempts per group, >=80% completion, >=20 paired seeds, comparable adjacent goals and nonoverlapping intervals. A low-seed pilot cannot establish a smooth or fair difficulty curve.
- Failed capability checks make affected orbs/policies inconclusive. Engine wiring probes do not establish proficiency at effective authored combo/depth requirements, which can demand up to 18 cascade waves.
- Authored-board construction diagnostics match orb and policy and retain their recorded starting board and finish policy. They are untimed: cadence, gravity, deadlines and timed stars remain unverified. Optional mastery shortfalls do not invalidate a recorded timed primary win; these diagnostics do not establish impossibility or player fairness.
- 6 optional showcase laps were truncated by an explicit window or harness budget. Primary-goal wins remain valid; observed stars and quality metrics may be lower bounds on eventual lap quality.

Affected capability failures: 0 groups. Deep-goal strategy unvalidated: 6 groups.

Capabilities and policy demonstrations:

```json
{
  "version": 3,
  "timed": false,
  "kind": "mechanics-and-strategy-validation",
  "status": "pass",
  "mechanics": {
    "status": "pass",
    "fixtures": [
      {
        "id": "standard-two-wave",
        "status": "pass",
        "scope": {
          "baseModes": [
            "standard"
          ],
          "objectiveTypes": [
            "cascade",
            "combo",
            "score",
            "lines",
            "tetrises"
          ]
        },
        "reachable": true,
        "expected": {
          "lines": 2,
          "waves": 2
        },
        "actual": {
          "lines": 2,
          "waves": 2,
          "waveLines": [
            1,
            1
          ],
          "score": 4160
        },
        "canonicalMatches": true,
        "aiSimulator": {
          "status": "pass",
          "lines": 2,
          "waves": 2,
          "scoreProjection": {
            "estimated": 3520,
            "actual": 4160,
            "matches": false
          }
        },
        "initialOccupancy": "..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|####......|..........|....######|....######",
        "initialConnectivity": ".,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|0,0,0,0,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,1,1,1,1,1,1|.,.,.,.,2,2,2,2,2,2",
        "finalConnectivity": ".,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,."
      },
      {
        "id": "infinity-two-wave",
        "status": "pass",
        "scope": {
          "baseModes": [
            "infinity"
          ],
          "objectiveTypes": [
            "cascade",
            "combo",
            "score",
            "lines",
            "tetrises"
          ]
        },
        "reachable": true,
        "expected": {
          "lines": 2,
          "waves": 2
        },
        "actual": {
          "lines": 2,
          "waves": 2,
          "waveLines": [
            1,
            1
          ],
          "score": 4160
        },
        "canonicalMatches": true,
        "aiSimulator": {
          "status": "pass",
          "lines": 2,
          "waves": 2,
          "scoreProjection": {
            "estimated": 3520,
            "actual": 4160,
            "matches": false
          }
        },
        "initialOccupancy": "..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|####......|..........|....######|....######",
        "initialConnectivity": ".,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|0,0,0,0,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,1,1,1,1,1,1|.,.,.,.,2,2,2,2,2,2",
        "finalConnectivity": ".,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,."
      },
      {
        "id": "odyssey-score-modifier",
        "status": "pass",
        "scope": {
          "baseModes": [
            "standard"
          ],
          "objectiveTypes": [
            "cascade",
            "combo",
            "score",
            "lines",
            "tetrises"
          ]
        },
        "reachable": true,
        "expected": {
          "lines": 2,
          "waves": 2
        },
        "actual": {
          "lines": 2,
          "waves": 2,
          "waveLines": [
            1,
            1
          ],
          "score": 10880
        },
        "canonicalMatches": true,
        "aiSimulator": {
          "status": "pass",
          "lines": 2,
          "waves": 2,
          "scoreProjection": {
            "estimated": 3520,
            "actual": 10880,
            "matches": false
          }
        },
        "initialOccupancy": "..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|####......|..........|....######|....######",
        "initialConnectivity": ".,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|0,0,0,0,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,1,1,1,1,1,1|.,.,.,.,2,2,2,2,2,2",
        "finalConnectivity": ".,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,."
      },
      {
        "id": "infinity-playable-roof",
        "status": "pass",
        "scope": {
          "baseModes": [
            "infinity"
          ],
          "objectiveTypes": [
            "cascade",
            "combo",
            "score",
            "lines",
            "tetrises"
          ]
        },
        "reachable": true,
        "expected": {
          "lines": 1,
          "waves": 1
        },
        "actual": {
          "lines": 1,
          "waves": 1,
          "waveLines": [
            1
          ],
          "score": 325
        },
        "canonicalMatches": true,
        "aiSimulator": {
          "status": "pass",
          "lines": 1,
          "waves": 1,
          "scoreProjection": {
            "estimated": 275,
            "actual": 325,
            "matches": false
          }
        },
        "initialOccupancy": "..........|####..####|....##....|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........",
        "initialConnectivity": ".,.,.,.,.,.,.,.,.,.|0,0,0,0,.,.,1,1,1,1|.,.,.,.,2,2,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.",
        "finalConnectivity": ".,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,0,0,.,.,.,.|.,.,.,.,1,1,.,.,.,."
      },
      {
        "id": "connected-payload",
        "status": "pass",
        "scope": {
          "baseModes": [
            "standard"
          ],
          "objectiveTypes": [
            "cascade",
            "combo",
            "score",
            "lines",
            "tetrises"
          ]
        },
        "reachable": true,
        "expected": {
          "lines": 1,
          "waves": 1
        },
        "actual": {
          "lines": 1,
          "waves": 1,
          "waveLines": [
            1
          ],
          "score": 325
        },
        "canonicalMatches": true,
        "aiSimulator": {
          "status": "pass",
          "lines": 1,
          "waves": 1,
          "scoreProjection": {
            "estimated": 275,
            "actual": 325,
            "matches": false
          }
        },
        "initialOccupancy": "..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|##........|..........|#.........|######....",
        "initialConnectivity": ".,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|0,0,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|1,.,.,.,.,.,.,.,.,.|2,2,2,2,2,2,.,.,.,.",
        "finalConnectivity": ".,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|0,0,.,.,.,.,.,.,.,.|1,.,.,.,.,.,.,.,.,."
      },
      {
        "id": "separate-payload",
        "status": "pass",
        "scope": {
          "baseModes": [
            "standard"
          ],
          "objectiveTypes": [
            "cascade",
            "combo",
            "score",
            "lines",
            "tetrises"
          ]
        },
        "reachable": true,
        "expected": {
          "lines": 1,
          "waves": 1
        },
        "actual": {
          "lines": 1,
          "waves": 1,
          "waveLines": [
            1
          ],
          "score": 325
        },
        "canonicalMatches": true,
        "aiSimulator": {
          "status": "pass",
          "lines": 1,
          "waves": 1,
          "scoreProjection": {
            "estimated": 275,
            "actual": 325,
            "matches": false
          }
        },
        "initialOccupancy": "..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|..........|##........|..........|#.........|######....",
        "initialConnectivity": ".,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|0,1,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|2,.,.,.,.,.,.,.,.,.|3,3,3,3,3,3,.,.,.,.",
        "finalConnectivity": ".,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|.,.,.,.,.,.,.,.,.,.|0,.,.,.,.,.,.,.,.,.|1,2,.,.,.,.,.,.,.,."
      }
    ],
    "connectivityCacheCollision": {
      "status": "pass",
      "meaning": "Equal occupancy can yield different component outcomes; benchmark keys retain connectivity."
    }
  },
  "profiles": [
    {
      "profileId": "cascade",
      "status": "pass",
      "demonstrations": [
        {
          "id": "standard-two-wave:fire",
          "kind": "prepared-fixture",
          "timed": false,
          "status": "pass",
          "maximumDepth": 2,
          "cascades": 1,
          "plans": 1,
          "hardDrops": 1,
          "rejectedActions": 0,
          "topOut": false,
          "reason": "Executed a reachable two-wave chain with real game actions."
        },
        {
          "id": "standard-two-wave:preserve-then-fire",
          "kind": "prepared-fixture",
          "timed": false,
          "status": "pass",
          "maximumDepth": 2,
          "cascades": 1,
          "plans": 2,
          "hardDrops": 2,
          "rejectedActions": 0,
          "topOut": false,
          "reason": "Executed a reachable two-wave chain with real game actions."
        },
        {
          "id": "infinity-two-wave:fire",
          "kind": "prepared-fixture",
          "timed": false,
          "status": "pass",
          "maximumDepth": 2,
          "cascades": 1,
          "plans": 1,
          "hardDrops": 1,
          "rejectedActions": 0,
          "topOut": false,
          "reason": "Executed a reachable two-wave chain with real game actions."
        },
        {
          "id": "infinity-two-wave:preserve-then-fire",
          "kind": "prepared-fixture",
          "timed": false,
          "status": "pass",
          "maximumDepth": 2,
          "cascades": 1,
          "plans": 2,
          "hardDrops": 2,
          "rejectedActions": 0,
          "topOut": false,
          "reason": "Executed a reachable two-wave chain with real game actions."
        }
      ],
      "validatedMaxCascadeDepth": 2,
      "scope": {
        "baseModes": [
          "standard",
          "infinity"
        ],
        "objectiveTypes": [
          "cascade",
          "combo"
        ],
        "maximumValidatedDepth": 2
      },
      "construction": {
        "kind": "empty-board-construction",
        "timed": false,
        "status": "inconclusive",
        "demonstrations": [
          {
            "id": "standard:empty:cascade:1001",
            "kind": "empty-board-construction",
            "timed": false,
            "profileId": "cascade",
            "seed": 1001,
            "baseMode": "standard",
            "status": "inconclusive",
            "maximumDepth": 2,
            "cascades": 4,
            "tetrises": 0,
            "singles": 7,
            "piecesPlaced": 40,
            "pieceBudget": 40,
            "targetDepth": 10,
            "rejectedActions": 0,
            "topOut": false,
            "previewLimit": 3,
            "insertedCells": 0,
            "allTetrominoes": true,
            "trace": [
              {
                "step": 1,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "L",
                  "J",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 2,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "J",
                  "Z",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 3,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "Z",
                  "S",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 4,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "S",
                  "T",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 5,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "T",
                  "I",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 6,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "I",
                  "Z",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 7,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "Z",
                  "S",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": -1,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 8,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "S",
                  "O",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 9,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "O",
                  "T",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 10,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "T",
                  "I",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 11,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "I",
                  "L",
                  "J"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 12,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "L",
                  "J",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 13,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "J",
                  "T",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 14,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "T",
                  "O",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "rotate",
                    "dir": "flip"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": 3,
                  "y": 17,
                  "rotation": 1,
                  "shapeKey": "J"
                },
                "maximumDepth": 2,
                "lines": 2
              },
              {
                "step": 15,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "O",
                  "S",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 16,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "S",
                  "Z",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 17,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "Z",
                  "L",
                  "J"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 18,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "L",
                  "J",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 19,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "J",
                  "I",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "flip"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 6,
                  "y": 2,
                  "rotation": 2,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 20,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "I",
                  "I",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 6,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 21,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "I",
                  "L",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 22,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "L",
                  "J",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 23,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "J",
                  "T",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 24,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "T",
                  "Z",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "flip"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": 0,
                  "y": 2,
                  "rotation": 2,
                  "shapeKey": "J"
                },
                "maximumDepth": 2,
                "lines": 2
              },
              {
                "step": 25,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "Z",
                  "O",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "flip"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 2,
                  "rotation": 2,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 26,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "O",
                  "S",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 27,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "S",
                  "J",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 28,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "J",
                  "T",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 29,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "T",
                  "O",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 30,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "O",
                  "S",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 31,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "S",
                  "Z",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 32,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "Z",
                  "L",
                  "I"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 33,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "L",
                  "I",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 6,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 34,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "I",
                  "I",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "flip"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 2,
                  "rotation": 2,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 35,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "I",
                  "J",
                  "O"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 36,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "J",
                  "O",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 37,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "O",
                  "Z",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": -1,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "J"
                },
                "maximumDepth": 2,
                "lines": 3
              },
              {
                "step": 38,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "Z",
                  "S",
                  "T"
                ],
                "actions": [
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 39,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "S",
                  "T",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": 0,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "Z"
                },
                "maximumDepth": 2,
                "lines": 2
              },
              {
                "step": 40,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "T",
                  "L",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              }
            ],
            "preparedReplay": null,
            "reason": "The bounded policy did not construct a three-wave chain; deeper goals remain inconclusive."
          },
          {
            "id": "infinity:empty:cascade:1001",
            "kind": "empty-board-construction",
            "timed": false,
            "profileId": "cascade",
            "seed": 1001,
            "baseMode": "infinity",
            "status": "inconclusive",
            "maximumDepth": 2,
            "cascades": 3,
            "tetrises": 0,
            "singles": 6,
            "piecesPlaced": 40,
            "pieceBudget": 40,
            "targetDepth": 10,
            "rejectedActions": 0,
            "topOut": false,
            "previewLimit": 3,
            "insertedCells": 0,
            "allTetrominoes": true,
            "trace": [
              {
                "step": 1,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "L",
                  "J",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 2,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "J",
                  "Z",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 3,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "Z",
                  "S",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 4,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "S",
                  "T",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 5,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "T",
                  "I",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 6,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "I",
                  "Z",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 7,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "Z",
                  "S",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": -1,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 8,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "S",
                  "O",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 9,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "O",
                  "T",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 10,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "T",
                  "I",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 11,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "I",
                  "L",
                  "J"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 12,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "L",
                  "J",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 13,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "J",
                  "T",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 14,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "T",
                  "O",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "rotate",
                    "dir": "flip"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": 3,
                  "y": 37,
                  "rotation": 1,
                  "shapeKey": "J"
                },
                "maximumDepth": 2,
                "lines": 2
              },
              {
                "step": 15,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "O",
                  "S",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 16,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "S",
                  "Z",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 17,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "Z",
                  "L",
                  "J"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 18,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "L",
                  "J",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 19,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "J",
                  "I",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "flip"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 6,
                  "y": 22,
                  "rotation": 2,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 20,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "I",
                  "I",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 6,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 21,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "I",
                  "L",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 22,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "L",
                  "J",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 23,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "J",
                  "T",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 24,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "T",
                  "Z",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "flip"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": 0,
                  "y": 22,
                  "rotation": 2,
                  "shapeKey": "J"
                },
                "maximumDepth": 2,
                "lines": 2
              },
              {
                "step": 25,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "Z",
                  "O",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "flip"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 22,
                  "rotation": 2,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 26,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "O",
                  "S",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 27,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "S",
                  "J",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 28,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "J",
                  "T",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 29,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "T",
                  "O",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 30,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "O",
                  "S",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 31,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "S",
                  "Z",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 32,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "Z",
                  "L",
                  "I"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 33,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "L",
                  "I",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 6,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 34,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "I",
                  "I",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 35,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "I",
                  "J",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 36,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "J",
                  "O",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 37,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 18,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "O",
                  "Z",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": -1,
                  "y": 18,
                  "rotation": 3,
                  "shapeKey": "J"
                },
                "maximumDepth": 2,
                "lines": 2
              },
              {
                "step": 38,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 20,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "Z",
                  "S",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 20,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 39,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 20,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "S",
                  "T",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 20,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 40,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 20,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "T",
                  "L",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 20,
                  "rotation": 3,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              }
            ],
            "preparedReplay": null,
            "reason": "The bounded policy did not construct a three-wave chain; deeper goals remain inconclusive."
          },
          {
            "id": "standard:empty:cascade:1002",
            "kind": "empty-board-construction",
            "timed": false,
            "profileId": "cascade",
            "seed": 1002,
            "baseMode": "standard",
            "status": "inconclusive",
            "maximumDepth": 2,
            "cascades": 4,
            "tetrises": 0,
            "singles": 8,
            "piecesPlaced": 40,
            "pieceBudget": 40,
            "targetDepth": 10,
            "rejectedActions": 0,
            "topOut": false,
            "previewLimit": 3,
            "insertedCells": 0,
            "allTetrominoes": true,
            "trace": [
              {
                "step": 1,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "S",
                  "T",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 2,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "T",
                  "I",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 3,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "I",
                  "Z",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "flip"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 2,
                  "rotation": 2,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 4,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "Z",
                  "J",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 6,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 5,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "J",
                  "O",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 6,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "O",
                  "O",
                  "I"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 7,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "O",
                  "I",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 8,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 8,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "I",
                  "J",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 9,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "J",
                  "T",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": -1,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 10,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "T",
                  "L",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 1,
                "preDropPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 1
              },
              {
                "step": 11,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "L",
                  "S",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "flip"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 2,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 12,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "S",
                  "Z",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 13,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "Z",
                  "T",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 14,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "T",
                  "Z",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 15,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "Z",
                  "O",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": 5,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "maximumDepth": 2,
                "lines": 2
              },
              {
                "step": 16,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "O",
                  "L",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": 5,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "maximumDepth": 2,
                "lines": 2
              },
              {
                "step": 17,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "L",
                  "J",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 18,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "J",
                  "I",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "flip"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 2,
                  "rotation": 2,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 19,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "I",
                  "S",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 20,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "S",
                  "O",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 21,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "O",
                  "T",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 22,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "T",
                  "S",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 23,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "S",
                  "Z",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": -1,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 24,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "Z",
                  "I",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": 6,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "S"
                },
                "maximumDepth": 2,
                "lines": 2
              },
              {
                "step": 25,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "I",
                  "J",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 26,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "J",
                  "L",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 27,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "L",
                  "T",
                  "J"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 28,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "T",
                  "J",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 29,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "J",
                  "I",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": 6,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "T"
                },
                "maximumDepth": 2,
                "lines": 3
              },
              {
                "step": 30,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "I",
                  "L",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "flip"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 2,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 31,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "L",
                  "S",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 32,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "S",
                  "O",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 33,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "O",
                  "Z",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 34,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "Z",
                  "I",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 35,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "I",
                  "L",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 6,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 36,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "L",
                  "S",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": -1,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 37,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "S",
                  "O",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 38,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "O",
                  "T",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 39,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "T",
                  "Z",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 40,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "Z",
                  "J",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              }
            ],
            "preparedReplay": null,
            "reason": "The bounded policy did not construct a three-wave chain; deeper goals remain inconclusive."
          },
          {
            "id": "infinity:empty:cascade:1002",
            "kind": "empty-board-construction",
            "timed": false,
            "profileId": "cascade",
            "seed": 1002,
            "baseMode": "infinity",
            "status": "inconclusive",
            "maximumDepth": 2,
            "cascades": 4,
            "tetrises": 0,
            "singles": 5,
            "piecesPlaced": 40,
            "pieceBudget": 40,
            "targetDepth": 10,
            "rejectedActions": 0,
            "topOut": false,
            "previewLimit": 3,
            "insertedCells": 0,
            "allTetrominoes": true,
            "trace": [
              {
                "step": 1,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "S",
                  "T",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 2,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "T",
                  "I",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 3,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "I",
                  "Z",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "flip"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 22,
                  "rotation": 2,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 4,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "Z",
                  "J",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": -1,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 5,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "J",
                  "O",
                  "O"
                ],
                "actions": [
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 6,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "O",
                  "O",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 6,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 7,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "O",
                  "I",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 8,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "I",
                  "J",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 8,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 9,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "J",
                  "T",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": -1,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 10,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "T",
                  "L",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 11,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "L",
                  "S",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 6,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 12,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "S",
                  "Z",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": 1,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "L"
                },
                "maximumDepth": 2,
                "lines": 2
              },
              {
                "step": 13,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "Z",
                  "T",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 14,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "T",
                  "Z",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 15,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "Z",
                  "O",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 16,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "O",
                  "L",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 17,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "L",
                  "J",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 8,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 18,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "J",
                  "I",
                  "S"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "L"
                },
                "maximumDepth": 2,
                "lines": 3
              },
              {
                "step": 19,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "I",
                  "S",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 20,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "S",
                  "O",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 21,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "O",
                  "T",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 22,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "T",
                  "S",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 23,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "S",
                  "Z",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 24,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "Z",
                  "I",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": 1,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "S"
                },
                "maximumDepth": 2,
                "lines": 3
              },
              {
                "step": 25,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "I",
                  "J",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 26,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "J",
                  "L",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 6,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 27,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "L",
                  "T",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 28,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "T",
                  "J",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 29,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "J",
                  "I",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "flip"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 22,
                  "rotation": 2,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 30,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "I",
                  "L",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "flip"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 22,
                  "rotation": 2,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 31,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "L",
                  "S",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 32,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "S",
                  "O",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 33,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "O",
                  "Z",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 34,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "Z",
                  "I",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 35,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "I",
                  "L",
                  "S"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 36,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "L",
                  "S",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 37,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "S",
                  "O",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": -1,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "L"
                },
                "maximumDepth": 2,
                "lines": 3
              },
              {
                "step": 38,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "O",
                  "T",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 39,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "T",
                  "Z",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 40,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "Z",
                  "J",
                  "S"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              }
            ],
            "preparedReplay": null,
            "reason": "The bounded policy did not construct a three-wave chain; deeper goals remain inconclusive."
          },
          {
            "id": "standard:empty:cascade:1003",
            "kind": "empty-board-construction",
            "timed": false,
            "profileId": "cascade",
            "seed": 1003,
            "baseMode": "standard",
            "status": "pass",
            "maximumDepth": 3,
            "cascades": 5,
            "tetrises": 0,
            "singles": 12,
            "piecesPlaced": 40,
            "pieceBudget": 40,
            "targetDepth": 10,
            "rejectedActions": 0,
            "topOut": false,
            "previewLimit": 3,
            "insertedCells": 0,
            "allTetrominoes": true,
            "trace": [
              {
                "step": 1,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "Z",
                  "S",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 2,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "S",
                  "J",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 3,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "J",
                  "T",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 4,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "T",
                  "I",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 6,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 5,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "I",
                  "O",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "flip"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 2,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 6,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "O",
                  "T",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": -1,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 7,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "T",
                  "J",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 8,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "J",
                  "S",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 9,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "S",
                  "O",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 8,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 10,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "O",
                  "L",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 11,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "L",
                  "Z",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 12,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "Z",
                  "I",
                  "L"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 3,
                "preDropPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "L"
                },
                "maximumDepth": 3,
                "lines": 3
              },
              {
                "step": 13,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "I",
                  "L",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 14,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "L",
                  "Z",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 15,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "Z",
                  "I",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 16,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "I",
                  "S",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 17,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "S",
                  "T",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 18,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "T",
                  "J",
                  "O"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 19,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "J",
                  "O",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 20,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "O",
                  "O",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": -1,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "J"
                },
                "maximumDepth": 2,
                "lines": 2
              },
              {
                "step": 21,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "O",
                  "I",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 22,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "I",
                  "S",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 23,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "S",
                  "Z",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 24,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "Z",
                  "L",
                  "T"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 25,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "L",
                  "T",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 3,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "maximumDepth": 3,
                "lines": 3
              },
              {
                "step": 26,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "T",
                  "J",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 27,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "J",
                  "T",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 6,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 28,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "T",
                  "O",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 29,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "O",
                  "S",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "flip"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 2,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 30,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "S",
                  "J",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 31,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "J",
                  "I",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 32,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "I",
                  "Z",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": 8,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "J"
                },
                "maximumDepth": 2,
                "lines": 2
              },
              {
                "step": 33,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "Z",
                  "L",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 6,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 34,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "L",
                  "L",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 35,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "L",
                  "T",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 8,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 36,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "T",
                  "Z",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "flip"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": 0,
                  "y": 2,
                  "rotation": 2,
                  "shapeKey": "L"
                },
                "maximumDepth": 2,
                "lines": 2
              },
              {
                "step": 37,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "Z",
                  "I",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 38,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "I",
                  "O",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 6,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 39,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "O",
                  "S",
                  "J"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 40,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "S",
                  "J",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              }
            ],
            "preparedReplay": {
              "kind": "prepared-from-legal-construction",
              "timed": false,
              "sourceConstructionId": "standard:empty:cascade:1003",
              "maximumDepth": 3,
              "rejectedActions": 0,
              "status": "pass",
              "expectedDepth": 3,
              "sourcePrefixPieces": 11
            },
            "reason": "A real action trace constructed a chain from an empty board."
          },
          {
            "id": "infinity:empty:cascade:1003",
            "kind": "empty-board-construction",
            "timed": false,
            "profileId": "cascade",
            "seed": 1003,
            "baseMode": "infinity",
            "status": "pass",
            "maximumDepth": 3,
            "cascades": 5,
            "tetrises": 0,
            "singles": 12,
            "piecesPlaced": 40,
            "pieceBudget": 40,
            "targetDepth": 10,
            "rejectedActions": 0,
            "topOut": false,
            "previewLimit": 3,
            "insertedCells": 0,
            "allTetrominoes": true,
            "trace": [
              {
                "step": 1,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "Z",
                  "S",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 2,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "S",
                  "J",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 3,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "J",
                  "T",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 4,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "T",
                  "I",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 6,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 5,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "I",
                  "O",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "flip"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 42,
                  "rotation": 2,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 6,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "O",
                  "T",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": -1,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 7,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "T",
                  "J",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 8,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "J",
                  "S",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 9,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "S",
                  "O",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 8,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 10,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "O",
                  "L",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 11,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "L",
                  "Z",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 12,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "Z",
                  "I",
                  "L"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 3,
                "preDropPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "L"
                },
                "maximumDepth": 3,
                "lines": 3
              },
              {
                "step": 13,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "I",
                  "L",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 14,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "L",
                  "Z",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 15,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "Z",
                  "I",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 16,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "I",
                  "S",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 17,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "S",
                  "T",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 18,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "T",
                  "J",
                  "O"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 19,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "J",
                  "O",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 20,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "O",
                  "O",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": -1,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "J"
                },
                "maximumDepth": 2,
                "lines": 2
              },
              {
                "step": 21,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "O",
                  "I",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 22,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "I",
                  "S",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 23,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "S",
                  "Z",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 24,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "Z",
                  "L",
                  "T"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 25,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "L",
                  "T",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 3,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "maximumDepth": 3,
                "lines": 3
              },
              {
                "step": 26,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "T",
                  "J",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 27,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "J",
                  "T",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 6,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 28,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "T",
                  "O",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 29,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "O",
                  "S",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "flip"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 2,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 30,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "S",
                  "J",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 31,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "J",
                  "I",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 32,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "I",
                  "Z",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": 8,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "J"
                },
                "maximumDepth": 2,
                "lines": 2
              },
              {
                "step": 33,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "Z",
                  "L",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 6,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 34,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "L",
                  "L",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 35,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "L",
                  "T",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 8,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 36,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "T",
                  "Z",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "flip"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": 0,
                  "y": 22,
                  "rotation": 2,
                  "shapeKey": "L"
                },
                "maximumDepth": 2,
                "lines": 2
              },
              {
                "step": 37,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "Z",
                  "I",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 38,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "I",
                  "O",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 6,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 39,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "O",
                  "S",
                  "J"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 40,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "S",
                  "J",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              }
            ],
            "preparedReplay": {
              "kind": "prepared-from-legal-construction",
              "timed": false,
              "sourceConstructionId": "infinity:empty:cascade:1003",
              "maximumDepth": 3,
              "rejectedActions": 0,
              "status": "pass",
              "expectedDepth": 3,
              "sourcePrefixPieces": 11
            },
            "reason": "A real action trace constructed a chain from an empty board."
          }
        ],
        "targets": [
          {
            "targetDepth": 3,
            "passedDemonstrations": 2,
            "totalDemonstrations": 6,
            "status": "inconclusive"
          },
          {
            "targetDepth": 4,
            "passedDemonstrations": 0,
            "totalDemonstrations": 6,
            "status": "inconclusive"
          },
          {
            "targetDepth": 5,
            "passedDemonstrations": 0,
            "totalDemonstrations": 6,
            "status": "inconclusive"
          },
          {
            "targetDepth": 6,
            "passedDemonstrations": 0,
            "totalDemonstrations": 6,
            "status": "inconclusive"
          },
          {
            "targetDepth": 7,
            "passedDemonstrations": 0,
            "totalDemonstrations": 6,
            "status": "inconclusive"
          },
          {
            "targetDepth": 8,
            "passedDemonstrations": 0,
            "totalDemonstrations": 6,
            "status": "inconclusive"
          },
          {
            "targetDepth": 10,
            "passedDemonstrations": 0,
            "totalDemonstrations": 6,
            "status": "inconclusive"
          },
          {
            "targetDepth": 12,
            "passedDemonstrations": 0,
            "totalDemonstrations": 6,
            "status": "inconclusive"
          },
          {
            "targetDepth": 15,
            "passedDemonstrations": 0,
            "totalDemonstrations": 6,
            "status": "inconclusive"
          },
          {
            "targetDepth": 18,
            "passedDemonstrations": 0,
            "totalDemonstrations": 6,
            "status": "inconclusive"
          }
        ],
        "validatedMaxCascadeDepth": 3,
        "scope": {
          "baseModes": [
            "standard",
            "infinity"
          ],
          "objectiveTypes": [
            "cascade",
            "combo"
          ]
        }
      },
      "limitations": [
        "Two-wave prepared fixtures do not validate building deep chains from an empty board.",
        "Construction targets include authored effective wave requirements; missed depths remain inconclusive.",
        "Mechanics demonstrations bypass reaction, gravity timing and presentation delays.",
        "Planner scoring omits the time-dependent lock bonus; campaign scoring uses actual game state."
      ]
    },
    {
      "profileId": "expert",
      "status": "pass",
      "demonstrations": [
        {
          "id": "standard-two-wave:fire",
          "kind": "prepared-fixture",
          "timed": false,
          "status": "pass",
          "maximumDepth": 2,
          "cascades": 1,
          "plans": 1,
          "hardDrops": 1,
          "rejectedActions": 0,
          "topOut": false,
          "reason": "Executed a reachable two-wave chain with real game actions."
        },
        {
          "id": "standard-two-wave:preserve-then-fire",
          "kind": "prepared-fixture",
          "timed": false,
          "status": "pass",
          "maximumDepth": 2,
          "cascades": 1,
          "plans": 2,
          "hardDrops": 2,
          "rejectedActions": 0,
          "topOut": false,
          "reason": "Executed a reachable two-wave chain with real game actions."
        },
        {
          "id": "infinity-two-wave:fire",
          "kind": "prepared-fixture",
          "timed": false,
          "status": "pass",
          "maximumDepth": 2,
          "cascades": 1,
          "plans": 1,
          "hardDrops": 1,
          "rejectedActions": 0,
          "topOut": false,
          "reason": "Executed a reachable two-wave chain with real game actions."
        },
        {
          "id": "infinity-two-wave:preserve-then-fire",
          "kind": "prepared-fixture",
          "timed": false,
          "status": "pass",
          "maximumDepth": 2,
          "cascades": 1,
          "plans": 2,
          "hardDrops": 2,
          "rejectedActions": 0,
          "topOut": false,
          "reason": "Executed a reachable two-wave chain with real game actions."
        }
      ],
      "validatedMaxCascadeDepth": 2,
      "scope": {
        "baseModes": [
          "standard",
          "infinity"
        ],
        "objectiveTypes": [
          "cascade",
          "combo"
        ],
        "maximumValidatedDepth": 2
      },
      "construction": {
        "kind": "empty-board-construction",
        "timed": false,
        "status": "pass",
        "demonstrations": [
          {
            "id": "standard:empty:expert:1001",
            "kind": "empty-board-construction",
            "timed": false,
            "profileId": "expert",
            "seed": 1001,
            "baseMode": "standard",
            "status": "pass",
            "maximumDepth": 3,
            "cascades": 5,
            "tetrises": 0,
            "singles": 13,
            "piecesPlaced": 40,
            "pieceBudget": 40,
            "targetDepth": 10,
            "rejectedActions": 0,
            "topOut": false,
            "previewLimit": 3,
            "insertedCells": 0,
            "allTetrominoes": true,
            "trace": [
              {
                "step": 1,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "L",
                  "J",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 2,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "J",
                  "Z",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 3,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "Z",
                  "S",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 4,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "S",
                  "T",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 5,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "T",
                  "I",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 6,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "I",
                  "Z",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 7,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "Z",
                  "S",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": -1,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 8,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "S",
                  "O",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 9,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "O",
                  "T",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 10,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "T",
                  "I",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 11,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "I",
                  "L",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 1,
                "preDropPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 1
              },
              {
                "step": 12,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "L",
                  "J",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 13,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "J",
                  "T",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 14,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "T",
                  "O",
                  "S"
                ],
                "actions": [
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 15,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "O",
                  "S",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 3,
                "preDropPose": {
                  "x": 0,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "T"
                },
                "maximumDepth": 3,
                "lines": 3
              },
              {
                "step": 16,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "S",
                  "Z",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 17,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "Z",
                  "L",
                  "J"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 18,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "L",
                  "J",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 19,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "J",
                  "I",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 6,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 20,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "I",
                  "I",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 21,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "I",
                  "L",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 22,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "L",
                  "J",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 23,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "J",
                  "T",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 24,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "T",
                  "Z",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 25,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "Z",
                  "O",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": -1,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "T"
                },
                "maximumDepth": 2,
                "lines": 2
              },
              {
                "step": 26,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "O",
                  "S",
                  "J"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 27,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "S",
                  "J",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 8,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 28,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "J",
                  "T",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 29,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "T",
                  "O",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 3,
                "preDropPose": {
                  "x": 2,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "J"
                },
                "maximumDepth": 3,
                "lines": 3
              },
              {
                "step": 30,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "O",
                  "S",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": 2,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "T"
                },
                "maximumDepth": 2,
                "lines": 2
              },
              {
                "step": 31,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "S",
                  "Z",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 32,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "Z",
                  "L",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 33,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "L",
                  "I",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 34,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "I",
                  "I",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 35,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "I",
                  "J",
                  "O"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "I"
                },
                "maximumDepth": 2,
                "lines": 2
              },
              {
                "step": 36,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "J",
                  "O",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 37,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "O",
                  "Z",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "flip"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 2,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 38,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "Z",
                  "S",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 39,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "S",
                  "T",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 40,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "T",
                  "L",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              }
            ],
            "preparedReplay": {
              "kind": "prepared-from-legal-construction",
              "timed": false,
              "sourceConstructionId": "standard:empty:expert:1001",
              "maximumDepth": 3,
              "rejectedActions": 0,
              "status": "pass",
              "expectedDepth": 3,
              "sourcePrefixPieces": 14
            },
            "reason": "A real action trace constructed a chain from an empty board."
          },
          {
            "id": "infinity:empty:expert:1001",
            "kind": "empty-board-construction",
            "timed": false,
            "profileId": "expert",
            "seed": 1001,
            "baseMode": "infinity",
            "status": "pass",
            "maximumDepth": 3,
            "cascades": 5,
            "tetrises": 0,
            "singles": 13,
            "piecesPlaced": 40,
            "pieceBudget": 40,
            "targetDepth": 10,
            "rejectedActions": 0,
            "topOut": false,
            "previewLimit": 3,
            "insertedCells": 0,
            "allTetrominoes": true,
            "trace": [
              {
                "step": 1,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "L",
                  "J",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 2,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "J",
                  "Z",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 3,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "Z",
                  "S",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 4,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "S",
                  "T",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 5,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "T",
                  "I",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 6,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "I",
                  "Z",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 7,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "Z",
                  "S",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": -1,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 8,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "S",
                  "O",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 9,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "O",
                  "T",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 10,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "T",
                  "I",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 11,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "I",
                  "L",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 1,
                "preDropPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 1
              },
              {
                "step": 12,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "L",
                  "J",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 13,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "J",
                  "T",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 14,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "T",
                  "O",
                  "S"
                ],
                "actions": [
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 15,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "O",
                  "S",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 3,
                "preDropPose": {
                  "x": 0,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "T"
                },
                "maximumDepth": 3,
                "lines": 3
              },
              {
                "step": 16,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "S",
                  "Z",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 17,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "Z",
                  "L",
                  "J"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 18,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "L",
                  "J",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 19,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "J",
                  "I",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 6,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 20,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "I",
                  "I",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 21,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "I",
                  "L",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 22,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "L",
                  "J",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 23,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "J",
                  "T",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 24,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "T",
                  "Z",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 25,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "Z",
                  "O",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": -1,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "T"
                },
                "maximumDepth": 2,
                "lines": 2
              },
              {
                "step": 26,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "O",
                  "S",
                  "J"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 27,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "S",
                  "J",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 8,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 28,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "J",
                  "T",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 29,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "T",
                  "O",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 3,
                "preDropPose": {
                  "x": 2,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "J"
                },
                "maximumDepth": 3,
                "lines": 3
              },
              {
                "step": 30,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "O",
                  "S",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": 2,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "T"
                },
                "maximumDepth": 2,
                "lines": 2
              },
              {
                "step": 31,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "S",
                  "Z",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 32,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "Z",
                  "L",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 33,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "L",
                  "I",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 34,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "I",
                  "I",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 35,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "I",
                  "J",
                  "O"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "I"
                },
                "maximumDepth": 2,
                "lines": 2
              },
              {
                "step": 36,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "J",
                  "O",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 37,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "O",
                  "Z",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "flip"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 2,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 38,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "Z",
                  "S",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 39,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "S",
                  "T",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 40,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "T",
                  "L",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              }
            ],
            "preparedReplay": {
              "kind": "prepared-from-legal-construction",
              "timed": false,
              "sourceConstructionId": "infinity:empty:expert:1001",
              "maximumDepth": 3,
              "rejectedActions": 0,
              "status": "pass",
              "expectedDepth": 3,
              "sourcePrefixPieces": 14
            },
            "reason": "A real action trace constructed a chain from an empty board."
          },
          {
            "id": "standard:empty:expert:1002",
            "kind": "empty-board-construction",
            "timed": false,
            "profileId": "expert",
            "seed": 1002,
            "baseMode": "standard",
            "status": "pass",
            "maximumDepth": 3,
            "cascades": 5,
            "tetrises": 0,
            "singles": 11,
            "piecesPlaced": 40,
            "pieceBudget": 40,
            "targetDepth": 10,
            "rejectedActions": 0,
            "topOut": false,
            "previewLimit": 3,
            "insertedCells": 0,
            "allTetrominoes": true,
            "trace": [
              {
                "step": 1,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "S",
                  "T",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 2,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "T",
                  "I",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 3,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "I",
                  "Z",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "flip"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 2,
                  "rotation": 2,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 4,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "Z",
                  "J",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 6,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 5,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "J",
                  "O",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 6,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "O",
                  "O",
                  "I"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 7,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "O",
                  "I",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 8,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 8,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "I",
                  "J",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 6,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 9,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "J",
                  "T",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": -1,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 10,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "T",
                  "L",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 8,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 11,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "L",
                  "S",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 12,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "S",
                  "Z",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 3,
                "preDropPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "L"
                },
                "maximumDepth": 3,
                "lines": 3
              },
              {
                "step": 13,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "Z",
                  "T",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 14,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "T",
                  "Z",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 15,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "Z",
                  "O",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "flip"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 2,
                  "rotation": 2,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 16,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "O",
                  "L",
                  "J"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 17,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "L",
                  "J",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 18,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "J",
                  "I",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": -1,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 19,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "I",
                  "S",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 20,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "S",
                  "O",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 21,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "O",
                  "T",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 22,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "T",
                  "S",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 23,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "S",
                  "Z",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 24,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "Z",
                  "I",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "S"
                },
                "maximumDepth": 2,
                "lines": 2
              },
              {
                "step": 25,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "I",
                  "J",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 3,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "Z"
                },
                "maximumDepth": 3,
                "lines": 3
              },
              {
                "step": 26,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "J",
                  "L",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 27,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "L",
                  "T",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 28,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "T",
                  "J",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 29,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "J",
                  "I",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "T"
                },
                "maximumDepth": 2,
                "lines": 3
              },
              {
                "step": 30,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "I",
                  "L",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 31,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "L",
                  "S",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 32,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "S",
                  "O",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 33,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "O",
                  "Z",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 34,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "Z",
                  "I",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 35,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "I",
                  "L",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 36,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "L",
                  "S",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 37,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "S",
                  "O",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "flip"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": 0,
                  "y": 2,
                  "rotation": 2,
                  "shapeKey": "L"
                },
                "maximumDepth": 2,
                "lines": 2
              },
              {
                "step": 38,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "O",
                  "T",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 39,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "T",
                  "Z",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 40,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "Z",
                  "J",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              }
            ],
            "preparedReplay": {
              "kind": "prepared-from-legal-construction",
              "timed": false,
              "sourceConstructionId": "standard:empty:expert:1002",
              "maximumDepth": 3,
              "rejectedActions": 0,
              "status": "pass",
              "expectedDepth": 3,
              "sourcePrefixPieces": 11
            },
            "reason": "A real action trace constructed a chain from an empty board."
          },
          {
            "id": "infinity:empty:expert:1002",
            "kind": "empty-board-construction",
            "timed": false,
            "profileId": "expert",
            "seed": 1002,
            "baseMode": "infinity",
            "status": "pass",
            "maximumDepth": 3,
            "cascades": 5,
            "tetrises": 0,
            "singles": 11,
            "piecesPlaced": 40,
            "pieceBudget": 40,
            "targetDepth": 10,
            "rejectedActions": 0,
            "topOut": false,
            "previewLimit": 3,
            "insertedCells": 0,
            "allTetrominoes": true,
            "trace": [
              {
                "step": 1,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "S",
                  "T",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 2,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "T",
                  "I",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 3,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "I",
                  "Z",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "flip"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 22,
                  "rotation": 2,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 4,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "Z",
                  "J",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 6,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 5,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "J",
                  "O",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 6,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "O",
                  "O",
                  "I"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 7,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "O",
                  "I",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 8,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 8,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "I",
                  "J",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 6,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 9,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "J",
                  "T",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": -1,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 10,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "T",
                  "L",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 8,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 11,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "L",
                  "S",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 12,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "S",
                  "Z",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 3,
                "preDropPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "L"
                },
                "maximumDepth": 3,
                "lines": 3
              },
              {
                "step": 13,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "Z",
                  "T",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 14,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "T",
                  "Z",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 15,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "Z",
                  "O",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "flip"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 22,
                  "rotation": 2,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 16,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "O",
                  "L",
                  "J"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 17,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "L",
                  "J",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 18,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "J",
                  "I",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": -1,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 19,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "I",
                  "S",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 20,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "S",
                  "O",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 21,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "O",
                  "T",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 22,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "T",
                  "S",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 23,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "S",
                  "Z",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 24,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "Z",
                  "I",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "S"
                },
                "maximumDepth": 2,
                "lines": 2
              },
              {
                "step": 25,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "I",
                  "J",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 3,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "Z"
                },
                "maximumDepth": 3,
                "lines": 3
              },
              {
                "step": 26,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "J",
                  "L",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 27,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "L",
                  "T",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 28,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "T",
                  "J",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 29,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "J",
                  "I",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "T"
                },
                "maximumDepth": 2,
                "lines": 3
              },
              {
                "step": 30,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "I",
                  "L",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 31,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "L",
                  "S",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 32,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "S",
                  "O",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 33,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "O",
                  "Z",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 34,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "Z",
                  "I",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 35,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "I",
                  "L",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 36,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "L",
                  "S",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 37,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "S",
                  "O",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "flip"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": 0,
                  "y": 22,
                  "rotation": 2,
                  "shapeKey": "L"
                },
                "maximumDepth": 2,
                "lines": 2
              },
              {
                "step": 38,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "O",
                  "T",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 39,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "T",
                  "Z",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 40,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "Z",
                  "J",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              }
            ],
            "preparedReplay": {
              "kind": "prepared-from-legal-construction",
              "timed": false,
              "sourceConstructionId": "infinity:empty:expert:1002",
              "maximumDepth": 3,
              "rejectedActions": 0,
              "status": "pass",
              "expectedDepth": 3,
              "sourcePrefixPieces": 11
            },
            "reason": "A real action trace constructed a chain from an empty board."
          },
          {
            "id": "standard:empty:expert:1003",
            "kind": "empty-board-construction",
            "timed": false,
            "profileId": "expert",
            "seed": 1003,
            "baseMode": "standard",
            "status": "pass",
            "maximumDepth": 3,
            "cascades": 4,
            "tetrises": 0,
            "singles": 8,
            "piecesPlaced": 40,
            "pieceBudget": 40,
            "targetDepth": 10,
            "rejectedActions": 0,
            "topOut": false,
            "previewLimit": 3,
            "insertedCells": 0,
            "allTetrominoes": true,
            "trace": [
              {
                "step": 1,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "Z",
                  "S",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 2,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "S",
                  "J",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 3,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "J",
                  "T",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 6,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 4,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "T",
                  "I",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 8,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 5,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "I",
                  "O",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 6,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "O",
                  "T",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": -1,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 7,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "T",
                  "J",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 8,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "J",
                  "S",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 9,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "S",
                  "O",
                  "L"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 3,
                "preDropPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "J"
                },
                "maximumDepth": 3,
                "lines": 3
              },
              {
                "step": 10,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "O",
                  "L",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 11,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "L",
                  "Z",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 6,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 12,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "Z",
                  "I",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "flip"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 2,
                  "rotation": 2,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 13,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "I",
                  "L",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 14,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "L",
                  "Z",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 15,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "Z",
                  "I",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 16,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "I",
                  "S",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 17,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "S",
                  "T",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 18,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "T",
                  "J",
                  "O"
                ],
                "actions": [
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "rotate",
                    "dir": "flip"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 19,
                  "rotation": 2,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 19,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "J",
                  "O",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 20,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "O",
                  "O",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 21,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "O",
                  "I",
                  "S"
                ],
                "actions": [
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 22,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "I",
                  "S",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 23,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "S",
                  "Z",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 24,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "Z",
                  "L",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 25,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "L",
                  "T",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 6,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 26,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "T",
                  "J",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 27,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "J",
                  "T",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 6,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 28,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "T",
                  "O",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 29,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "O",
                  "S",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 30,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "S",
                  "J",
                  "I"
                ],
                "actions": [
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 31,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "J",
                  "I",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 3,
                "preDropPose": {
                  "x": 0,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "S"
                },
                "maximumDepth": 3,
                "lines": 3
              },
              {
                "step": 32,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "I",
                  "Z",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": -1,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "J"
                },
                "maximumDepth": 2,
                "lines": 4
              },
              {
                "step": 33,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "Z",
                  "L",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 34,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "L",
                  "L",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 35,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "L",
                  "T",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 36,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "T",
                  "Z",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": -1,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 37,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "Z",
                  "I",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": 8,
                  "y": 2,
                  "rotation": 1,
                  "shapeKey": "T"
                },
                "maximumDepth": 2,
                "lines": 2
              },
              {
                "step": 38,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "I",
                  "O",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 39,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "O",
                  "S",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 2,
                  "rotation": 3,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 40,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "S",
                  "J",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 2,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              }
            ],
            "preparedReplay": {
              "kind": "prepared-from-legal-construction",
              "timed": false,
              "sourceConstructionId": "standard:empty:expert:1003",
              "maximumDepth": 3,
              "rejectedActions": 0,
              "status": "pass",
              "expectedDepth": 3,
              "sourcePrefixPieces": 8
            },
            "reason": "A real action trace constructed a chain from an empty board."
          },
          {
            "id": "infinity:empty:expert:1003",
            "kind": "empty-board-construction",
            "timed": false,
            "profileId": "expert",
            "seed": 1003,
            "baseMode": "infinity",
            "status": "pass",
            "maximumDepth": 3,
            "cascades": 3,
            "tetrises": 0,
            "singles": 7,
            "piecesPlaced": 40,
            "pieceBudget": 40,
            "targetDepth": 10,
            "rejectedActions": 0,
            "topOut": false,
            "previewLimit": 3,
            "insertedCells": 0,
            "allTetrominoes": true,
            "trace": [
              {
                "step": 1,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "Z",
                  "S",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 2,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "S",
                  "J",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 3,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "J",
                  "T",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 6,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 4,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "T",
                  "I",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 8,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 5,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "I",
                  "O",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 6,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "O",
                  "T",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": -1,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 7,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "T",
                  "J",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 8,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "J",
                  "S",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 9,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "S",
                  "O",
                  "L"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 3,
                "preDropPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "J"
                },
                "maximumDepth": 3,
                "lines": 3
              },
              {
                "step": 10,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "O",
                  "L",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 11,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "L",
                  "Z",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 6,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 12,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "Z",
                  "I",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "flip"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 22,
                  "rotation": 2,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 13,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "I",
                  "L",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 14,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "L",
                  "Z",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 15,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "Z",
                  "I",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 16,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "I",
                  "S",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 17,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "S",
                  "T",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 18,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "T",
                  "J",
                  "O"
                ],
                "actions": [
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "softDrop"
                  },
                  {
                    "type": "rotate",
                    "dir": "flip"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 39,
                  "rotation": 2,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 19,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "J",
                  "O",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 20,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "O",
                  "O",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 21,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "O",
                  "I",
                  "S"
                ],
                "actions": [
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 22,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "I",
                  "S",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 23,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "S",
                  "Z",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 24,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "Z",
                  "L",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 6,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 25,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "L",
                  "T",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "Z"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 26,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "T",
                  "J",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 27,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "J",
                  "T",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "flip"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 2,
                  "y": 22,
                  "rotation": 2,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 28,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "T",
                  "O",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 29,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "O",
                  "S",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 30,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "S",
                  "J",
                  "I"
                ],
                "actions": [
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 31,
                "shapeKey": "S",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "S"
                },
                "preview": [
                  "J",
                  "I",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 5,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "S"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 32,
                "shapeKey": "J",
                "spawnPose": {
                  "x": 4,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "J"
                },
                "preview": [
                  "I",
                  "Z",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 0,
                  "y": 22,
                  "rotation": 3,
                  "shapeKey": "J"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 33,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "Z",
                  "L",
                  "L"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 34,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 19,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "L",
                  "L",
                  "T"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": 0,
                  "y": 19,
                  "rotation": 3,
                  "shapeKey": "Z"
                },
                "maximumDepth": 2,
                "lines": 2
              },
              {
                "step": 35,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 21,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "L",
                  "T",
                  "Z"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 21,
                  "rotation": 1,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 36,
                "shapeKey": "L",
                "spawnPose": {
                  "x": 4,
                  "y": 21,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "preview": [
                  "T",
                  "Z",
                  "I"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 3,
                  "y": 21,
                  "rotation": 0,
                  "shapeKey": "L"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 37,
                "shapeKey": "T",
                "spawnPose": {
                  "x": 4,
                  "y": 21,
                  "rotation": 0,
                  "shapeKey": "T"
                },
                "preview": [
                  "Z",
                  "I",
                  "O"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 1,
                  "y": 21,
                  "rotation": 1,
                  "shapeKey": "T"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 38,
                "shapeKey": "Z",
                "spawnPose": {
                  "x": 4,
                  "y": 21,
                  "rotation": 0,
                  "shapeKey": "Z"
                },
                "preview": [
                  "I",
                  "O",
                  "S"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "move",
                    "dir": -1
                  },
                  {
                    "type": "rotate",
                    "dir": "left"
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 2,
                "preDropPose": {
                  "x": 0,
                  "y": 21,
                  "rotation": 3,
                  "shapeKey": "Z"
                },
                "maximumDepth": 2,
                "lines": 2
              },
              {
                "step": 39,
                "shapeKey": "I",
                "spawnPose": {
                  "x": 3,
                  "y": 22,
                  "rotation": 0,
                  "shapeKey": "I"
                },
                "preview": [
                  "O",
                  "S",
                  "J"
                ],
                "actions": [
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "rotate",
                    "dir": "right"
                  },
                  {
                    "type": "move",
                    "dir": 1
                  },
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 7,
                  "y": 22,
                  "rotation": 1,
                  "shapeKey": "I"
                },
                "maximumDepth": 0,
                "lines": 0
              },
              {
                "step": 40,
                "shapeKey": "O",
                "spawnPose": {
                  "x": 4,
                  "y": 19,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "preview": [
                  "S",
                  "J",
                  "T"
                ],
                "actions": [
                  {
                    "type": "hardDrop"
                  }
                ],
                "predictedDepth": 0,
                "preDropPose": {
                  "x": 4,
                  "y": 19,
                  "rotation": 0,
                  "shapeKey": "O"
                },
                "maximumDepth": 0,
                "lines": 0
              }
            ],
            "preparedReplay": {
              "kind": "prepared-from-legal-construction",
              "timed": false,
              "sourceConstructionId": "infinity:empty:expert:1003",
              "maximumDepth": 3,
              "rejectedActions": 0,
              "status": "pass",
              "expectedDepth": 3,
              "sourcePrefixPieces": 8
            },
            "reason": "A real action trace constructed a chain from an empty board."
          }
        ],
        "targets": [
          {
            "targetDepth": 3,
            "passedDemonstrations": 6,
            "totalDemonstrations": 6,
            "status": "pass"
          },
          {
            "targetDepth": 4,
            "passedDemonstrations": 0,
            "totalDemonstrations": 6,
            "status": "inconclusive"
          },
          {
            "targetDepth": 5,
            "passedDemonstrations": 0,
            "totalDemonstrations": 6,
            "status": "inconclusive"
          },
          {
            "targetDepth": 6,
            "passedDemonstrations": 0,
            "totalDemonstrations": 6,
            "status": "inconclusive"
          },
          {
            "targetDepth": 7,
            "passedDemonstrations": 0,
            "totalDemonstrations": 6,
            "status": "inconclusive"
          },
          {
            "targetDepth": 8,
            "passedDemonstrations": 0,
            "totalDemonstrations": 6,
            "status": "inconclusive"
          },
          {
            "targetDepth": 10,
            "passedDemonstrations": 0,
            "totalDemonstrations": 6,
            "status": "inconclusive"
          },
          {
            "targetDepth": 12,
            "passedDemonstrations": 0,
            "totalDemonstrations": 6,
            "status": "inconclusive"
          },
          {
            "targetDepth": 15,
            "passedDemonstrations": 0,
            "totalDemonstrations": 6,
            "status": "inconclusive"
          },
          {
            "targetDepth": 18,
            "passedDemonstrations": 0,
            "totalDemonstrations": 6,
            "status": "inconclusive"
          }
        ],
        "validatedMaxCascadeDepth": 3,
        "scope": {
          "baseModes": [
            "standard",
            "infinity"
          ],
          "objectiveTypes": [
            "cascade",
            "combo"
          ]
        }
      },
      "limitations": [
        "Two-wave prepared fixtures do not validate building deep chains from an empty board.",
        "Construction targets include authored effective wave requirements; missed depths remain inconclusive.",
        "Mechanics demonstrations bypass reaction, gravity timing and presentation delays.",
        "Planner scoring omits the time-dependent lock bonus; campaign scoring uses actual game state."
      ]
    }
  ],
  "authoredConstruction": {
    "kind": "authored-board-construction",
    "timed": false,
    "demonstrations": [],
    "limitations": [
      "Legal construction from authored starts does not validate timed stars or human difficulty.",
      "Normal orbs stop after the primary goal and its complete cascade; showcase orbs can continue.",
      "Optional mastery observations do not invalidate timed primary campaign wins."
    ]
  },
  "limitations": [
    "This is mechanics validation, not clock-faithful campaign or human challenge calibration.",
    "Passing shared physics fixtures does not establish a policy can construct arbitrary cascade objectives."
  ]
}
```

Full aggregate metrics, per-star/bonus gaps and matched-seed comparisons are in summary.json. Individual recorded attempts are in raw.jsonl.
