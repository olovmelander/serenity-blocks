// Diagnostic replay only. Does not search policies or replace any original observation.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { GameplayHybridEngine } from '../../../src/core/odyssey/GameplayHybridEngine.js';
import { getLevelById } from '../../../src/core/odyssey/data/levels.js';
import { fillBag, spawnPiece, move, rotate, softDrop, hardDrop } from '../../../src/core/game.js';
import { calculateBuildHeight } from '../../../src/core/infinity-grid.js';
import { removeClearedLines } from '../../../src/core/cascade-helpers.js';
import { connectivityBoardKey } from '../../../scripts/odyssey-benchmark/profiles.mjs';

const sourceUrl = new URL('../construction/capabilities.json', import.meta.url);
const configUrl = new URL('../construction/config.json', import.meta.url);
const outputUrl = new URL('verification.json', import.meta.url);
const root = fileURLToPath(new URL('../../../', import.meta.url));
const originalBytes = readFileSync(sourceUrl);
const configBytes = readFileSync(configUrl);
const sha256 = (bytes) => createHash('sha256').update(bytes).digest('hex');
const sourceHash = sha256(originalBytes);
const records = JSON.parse(originalBytes).authoredConstruction.demonstrations.filter((entry) =>
    !entry.traceValid || (entry.levelId === 59 && entry.profileId === 'chain' && entry.seed === 10005));
const config = JSON.parse(configBytes);
assert.equal(records.length, 5);
const head = execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim();
assert.equal(head, config.revision.head);
const sourceDiff = execFileSync('git', ['diff', '--name-only', 'HEAD', '--', 'src', 'scripts'], {
    cwd: root, encoding: 'utf8',
}).trim();
assert.equal(sourceDiff, '', 'Frozen gameplay/harness source must remain unchanged during this audit');

function geometry(pieces) {
    const occupied = new Map();
    let total = 0;
    for (const piece of pieces) {
        for (let y = 0; y < piece.shape.length; y++) {
            for (let x = 0; x < piece.shape[y].length; x++) {
                if (!piece.shape[y][x]) continue;
                total++;
                const key = `${piece.x + x},${piece.y + y}`;
                occupied.set(key, [...(occupied.get(key) || []), piece.pieceId]);
            }
        }
    }
    return { total, unique: occupied.size, overlaps: [...occupied].filter(([, ids]) => ids.length > 1) };
}

const boardHash = (state) => sha256(connectivityBoardKey(state.boardGrid));
const pose = (piece) => piece ? {
    x: piece.x, y: piece.y, rotation: piece.rotation, shapeKey: piece.shapeKey,
} : null;

async function replay(record, physicsPath) {
    // Select an existing production path in this audit process only.
    const priorWindow = globalThis.window;
    globalThis.window = { location: { search: `?cascadeV2=${physicsPath === 'resolved' ? 1 : 0}` } };
    const engine = new GameplayHybridEngine();
    engine.configure(getLevelById(record.levelId));
    const state = engine.createGameState({ rngSeed: record.seed });
    state.isSeeking = true;
    state.suppressExternalInput = true;
    if (state.isInfinityMode) engine.victoryEvaluator.updateHeight(calculateBuildHeight(state));
    let step = 0;
    let actionsReplayed = 0;
    let maximumDepth = 0;
    const maximumDepthSteps = [];
    const clearDefects = [];
    const triggerSnapshots = [];
    const interestingSteps = new Set([record.trace.at(-1).step,
        ...record.trace.filter((entry) => entry.maximumDepth === record.maximumDepth).map((entry) => entry.step)]);
    const callbacks = engine.buildPhysicsCallbacks({
        onHardDrop: ({ piece }) => {
            if (!interestingSteps.has(step)) return;
            triggerSnapshots.push({
                step,
                boardHeight: state.boardGrid.length,
                isInfinityMode: state.isInfinityMode,
                activePiece: structuredClone(piece),
                lockedPieces: structuredClone(state.lockedPieces),
                metricsBefore: engine.getMetrics(),
            });
        },
        triggerCascadeWave: (depth) => {
            if (depth > maximumDepth) {
                maximumDepth = depth;
                maximumDepthSteps.push({ step, depth });
            }
        },
        onLineClear: (count, holes, masks, fullLines, wave) => {
            // Run the shared primitive on a clone to locate collisions before the real
            // board rebuild; this diagnostic cannot alter the active simulation.
            const before = structuredClone(state.lockedPieces);
            const after = removeClearedLines(structuredClone(before), fullLines);
            const beforeGeometry = geometry(before);
            const afterGeometry = geometry(after);
            if (afterGeometry.overlaps.length || afterGeometry.total !== beforeGeometry.total - 10 * count) {
                clearDefects.push({
                    step, wave, fullLines,
                    beforeGeometry, afterGeometry,
                    piecesBefore: before,
                    piecesAfter: after,
                });
            }
        },
    });
    try {
        fillBag(state.nextPieces, state.randomGenerator);
        assert.equal(boardHash(state), record.initialBoardHash);
        for (const entry of record.trace) {
            step = entry.step;
            spawnPiece(state, null, () => { state.isGameOver = true; });
            assert.equal(state.isGameOver, false);
            assert.deepEqual(pose(state.currentPiece), entry.spawnPose);
            assert.equal(boardHash(state), entry.boardHashBefore);
            assert.deepEqual(state.nextPieces.slice(0, 3), entry.preview);
            assert.deepEqual(engine.getMetrics(), entry.metricsBefore);
            for (const command of entry.actions) {
                assert.deepEqual(pose(state.currentPiece), command.beforePose);
                let accepted;
                if (command.type === 'move') accepted = move(state, command.dir);
                else if (command.type === 'rotate') accepted = rotate(state, command.dir);
                else if (command.type === 'softDrop') accepted = softDrop(state, null, callbacks);
                else if (command.type === 'hardDrop') accepted = hardDrop(state, null, callbacks);
                else throw new Error(`Unknown recorded action: ${command.type}`);
                assert.equal(accepted, command.accepted);
                assert.deepEqual(pose(state.currentPiece), command.afterPose);
                actionsReplayed++;
                if (state.latestPhysicsPromise) await state.latestPhysicsPromise;
            }
            engine.updateScore(state.score);
            if (state.isInfinityMode) engine.victoryEvaluator.updateHeight(calculateBuildHeight(state));
            assert.equal(state.isProcessingPhysics, false);
            assert.equal(boardHash(state), entry.boardHashAfter);
            assert.deepEqual(engine.getMetrics(), entry.metricsAfter);
        }
        assert.equal(maximumDepth, record.maximumDepth);
        assert.deepEqual({ ...engine.getMetrics(), time: null }, record.metrics);
        return {
            recordId: record.id,
            levelId: record.levelId,
            profileId: record.profileId,
            seed: record.seed,
            physicsPath,
            originalTraceValid: record.traceValid,
            originalTermination: record.termination,
            allRecordedPosesPreviewsBoardHashesAndMetricsMatched: true,
            replayedPieces: record.trace.length,
            replayedActions: actionsReplayed,
            maximumDepth,
            maximumDepthSteps,
            finalMetrics: engine.getMetrics(),
            finalGeometry: geometry(state.lockedPieces),
            finalRecordedConservation: record.trace.at(-1).cellConservation,
            clearDefects,
            triggerSnapshots,
        };
    } finally {
        state.reset();
        engine.reset();
        if (priorWindow === undefined) delete globalThis.window;
        else globalThis.window = priorWindow;
    }
}

const originalLog = console.log;
console.log = () => {};
const results = [];
try {
    for (const record of records) {
        for (const physicsPath of ['legacy', 'resolved']) {
            results.push(await replay(record, physicsPath));
        }
    }
} finally { console.log = originalLog; }
assert.equal(sha256(readFileSync(sourceUrl)), sourceHash);
assert.equal(sha256(readFileSync(configUrl)), sha256(configBytes));
const audit = {
    kind: 'independent-recorded-action-replay',
    timed: false,
    policySearchPerformed: false,
    replacesOriginalObservations: false,
    frozenRevision: head,
    runtime: { node: process.version, platform: process.platform, arch: process.arch },
    inputCapabilitiesSha256: sourceHash,
    inputConfigSha256: sha256(configBytes),
    sourceAndOriginalRecordsUnchanged: true,
    interpretation: 'Replay verification of five preserved records, not fresh benchmark observations or timing validation.',
    results,
};
writeFileSync(outputUrl, `${JSON.stringify(audit, null, 2)}\n`);
console.log(JSON.stringify({
    output: fileURLToPath(outputUrl),
    results: results.map(({ recordId, physicsPath, replayedPieces, replayedActions, maximumDepth, clearDefects }) => ({
        recordId, physicsPath, replayedPieces, replayedActions, maximumDepth, defects: clearDefects.length,
    })),
}));
