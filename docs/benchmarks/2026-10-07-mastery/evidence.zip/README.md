# Odyssey mastery follow-up preregistration — 2026-10-07

Status: **frozen before execution at 2026-10-07 15:59:13 UTC, commit `b89bbec`**.
No fresh campaign or construction outcomes were inspected before this registration.
The finalized `sourceFreeze` and `registration.sha256` preserve the source and registration fingerprints; `source.patch`, `source-manifest.json` and `source-snapshot.zip` preserve the implementation before execution.
Both policies in each comparison must use the same exact frozen source and runtime.

This is a benchmark-policy and construction investigation. It introduces no production
retune and makes no claim about human difficulty, enjoyment or success probabilities.
All recorded variants in `artifacts/odyssey-depth-probes/`, including unsuccessful
development probes, must accompany the later evidence archive. The six-wave seed-9101
development example is not fresh validation. Preserve the complete directory and
refresh `development-inventory.json` at freeze if development is still ongoing.

## Registered work

| Cohort | Conditions | Fresh seeds | Count |
| --- | --- | --- | --- |
| Timed duel screen | Orbs 4/9/53/58 × cascade/duelist × steady cadence; shipped opponent sees its real full queue, player sees three previews. | 10001–10010 | 80 attempts, ten pairs per orb |
| Authored untimed construction | Orbs 49/55/59 × expert/chain; authentic seeded starts and authored primary/showcase finish policy. | 10001–10005 | 30 runs |
| Empty untimed construction | Standard/Infinity × expert/chain, target depth 18. | 10001–10005 | 20 runs |

The single fresh capabilities command performs the twenty empty and thirty authored runs;
do not launch a duplicate empty-board batch. Mechanic/prepared fixtures from that CLI
remain a separate validation class, not extra construction samples. The duel CLI's
ordinary instrument preflight also runs twelve empty probes: cascade/duelist ×
Standard/Infinity × development/check seeds 1001–1003, at forty pieces. These are
separate instrument checks, excluded from the fifty fresh construction runs and all
fresh-screen outcome counts. All fifty registered construction runs allow at most
128 placed tetrominoes. The capabilities driver has no separate
per-demonstration wall deadline; an external interruption is incomplete evidence.

## Commands after source freeze

Use new, nonexisting output directories. The duel execution keeps the 240,000 ms wall,
1,800 simulated-second and 3,000-piece budgets per attempt. The construction command
does not advance gameplay time or compete with gravity.

```bash
npm run benchmark:odyssey -- \
  --levels 4,9,53,58 \
  --profiles cascade,duelist \
  --scenarios baseline \
  --cadences steady \
  --samples 10 \
  --seed-start 10001 \
  --workers 2 \
  --wall-ms 240000 \
  --max-seconds 1800 \
  --max-pieces 3000 \
  --output artifacts/odyssey-mastery-followup-2026-10-07/duels

npm run benchmark:odyssey -- \
  --capabilities-only \
  --levels 49,55,59 \
  --profiles expert,chain \
  --construction-levels 49,55,59 \
  --construction-seeds 10001,10002,10003,10004,10005 \
  --construction-pieces 128 \
  --output artifacts/odyssey-mastery-followup-2026-10-07/construction
```

Before execution, root must verify these CLI names against the frozen parser and that
empty demonstrations record `targetDepth: 18`, rather than stopping at depth ten.
The recorded target list is 3/4/5/6/7/8/10/12/15/18. Source/runtime changes require a new
registered revision and fresh directory; do not silently append changed conditions.

## Duel analysis and recommendation

Compare each orb separately on the same seeds. Report all wins, losses, runtime errors,
censors and paired win transitions. At least 95% of ten assigned pairs means all ten
must resolve. Compute completed-match pacing only on pairs where both policies win;
show defeats separately. Use `elapsedSeconds` for the primary pacing summary, with
active play, resolution and intermission breakdowns alongside it.

Report median and nearest-rank p90: sort `n` values and select one-based index
`ceil(0.9 × n)` for p90. The two policies must use the identical both-win seed set.
The reduction is one minus candidate divided by baseline, using the respective
median or p90 on that set. Also retain individual paired differences. Faster defeats
never count as improved pacing.

An early orb can be nominated for a later confirmation only with no lost baseline
primary win, no runtime error, full required paired coverage, at least eight both-win
pairs, at least 15% shorter median and 10% shorter p90, and positive median paired
change in actual sent attack rows per human piece. Report stars and investigate any
lower-star pair or attribution problem. Evaluate 4 and 9 separately: nomination may
be limited to a qualifying orb, and a general early-duel recommendation needs both.
The eight-paired-win minimum prevents a small set of selected wins from carrying a
pacing recommendation. These are screening gates, not statistical efficacy claims.

Late tiers 7/8 (orbs 53/58) are descriptive tests of whether the attack policy changes
the measurement of strong authored opponents. No fresh win-rate adoption threshold
is assigned to them. Improving a synthetic player's policy changes the instrument;
it does not establish that production difficulty itself changed. No production
retuning follows from this screen, even when an early pacing gate passes.

## Construction qualification

The authored questions are actual eight-wave construction for orb 49, eighteen for
55 and twelve for 59, based on the combo requirements and current wave-ordinal metric.
Record every score, cascade count, Quad, explicit depth and bonus requirement too;
reaching the chain target alone is not a completed mastery demonstration.

Orb 49 ends after the full primary-winning resolution; do not give it a post-win lap.
Orbs 55/59 retain showcase continuation until the driver meets all untimed conditions
or reaches top-out, validation failure or 128 pieces. This is an observation cutoff,
not a new live finish rule. Empty Standard/Infinity results remain a separate context.

Verify real seeded tetrominoes, three-preview planning, initial board hashes, legal
action traces, cell conservation and fully drained physics. Never add cells or
teleport a planned placement. Invalid actions, planning mutations, physics errors or
incomplete traces cannot qualify a demonstration; distinguish a legal grounded
soft-drop stop from an illegal rejected move. Replaying a prepared trigger does not
create another construction success. Report invalid/incomplete observations instead
of replacing them silently.

These probes disable competing gravity and do not advance the clock. Production
scoring still runs, including the maximum 50-point lock bonus from zero held time.
Acquisition deadlines, survival duration and timed stars/bonuses remain unvalidated.
An unmet target within this bounded search is inconclusive, not an impossibility
proof or a reason to lower an authored mastery target.

Reserve seeds **11001 onward** for a separate confirmation registration. Its exact
sample size, seed range, comparisons, multiplicity and preservation rules must be
fixed before those outcomes are opened; this registration does not launch it.

## Reproducible analysis

After recorded outcomes are available, run:

```bash
python artifacts/odyssey-mastery-followup-2026-10-07/analyze.py
```

The analyzer uses `registration.json`, each cohort's `config.json`, duel `raw.jsonl`
and construction `capabilities.json`, without depending on `summary.json`. It records
input hashes, configuration/provenance errors, missing/duplicate attempts, paired
gates and separate authored/empty results. It reads the output folder names from the
frozen commands, so an extracted archive remains analyzable. Frozen analyzer hash
verification prevents an unrecorded later analysis change from silently qualifying
a candidate. Partial runs retain their missing observations and unresolved pairs.

Its construction verification checks recorded flags, actions, board-hash continuity
and conservation records; this Python analysis does not independently replay gameplay
physics. The production driver and its regressions provide that execution evidence.

## Completed record

This directory preserves the pre-fix screen; `postfix/` preserves the separate corrected-physics cohorts. The original registration and analyzer are unchanged. Run `python analyze-verified.py` to verify the pre-execution source bytes and reproduce the explicitly documented source-ordering correction, then `python postfix/analyze.py` for corrected-engine results. See the repository handover and durable archive README for interpretation and compatibility limits.
