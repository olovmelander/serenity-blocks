"""Package the completed follow-up and verify every member; run from repository root."""
import hashlib,json,zipfile
from pathlib import Path
root=Path(__file__).resolve().parent
repo=root.parents[1]
out=repo/'docs/benchmarks/2026-10-07-mastery'
analysis=json.loads((root/'analysis.json').read_text())
assert analysis['duels']['status']=='completed' and analysis['construction']['status']=='completed'
assert not analysis['duels']['validationErrors'] and not analysis['duels']['rowValidationErrors']
assert not analysis['construction']['validationErrors']
postfix=json.loads((root/'postfix/analysis.json').read_text())
for cohort in ['duels','construction','solo']:
 assert postfix[cohort]['status']=='completed' and not postfix[cohort]['validationErrors']
 assert not postfix[cohort].get('rowValidationErrors',[])
validation=json.loads((root/'validation.json').read_text())
assert validation['fullSuite']['exitCode']==0
out.mkdir(parents=True,exist_ok=True)
files=sorted(p for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc')
entries=[]
archive=out/'evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for path in files:
  name=path.relative_to(root).as_posix(); data=path.read_bytes()
  z.writestr(name,data)
  entries.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())=={entry['path'] for entry in entries}
 for entry in entries:
  data=z.read(entry['path'])
  assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256']
manifest={'schemaVersion':1,'sourceCommit':analysis['duels']['revision']['head'],'preFixSourceCommit':analysis['duels']['revision']['head'],'postFixSourceCommit':postfix['duels']['revision']['head'],'registeredTimedAttempts':138,'registeredConstructionRuns':100,'preFix':{'duels':80,'construction':50},'postFix':{'duels':40,'solo':18,'construction':50},'humanCalibration':False,'sourceOrderingCorrection':'provenance-correction.json preserves the unchanged original registration and verifies the same archived bytes under the CLI file ordering.','archive':{'path':'evidence.zip','bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},'files':entries}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'archive':str(archive),'members':len(entries),**manifest['archive']},indent=2))
