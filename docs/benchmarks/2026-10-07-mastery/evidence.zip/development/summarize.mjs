import {readFile,readdir,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const base='artifacts/odyssey-depth-probes';
const sourceHead='12c68f499a87cbd6edade539585b76d00eeb5418';
const rows=[];
for(const name of (await readdir(base)).sort()){
 const match=name.match(/^(.*)-(\d+)-h(\d+)\.json$/);
 if(!match)continue;
 const [,variant,seed,horizon]=match;
 const r=JSON.parse(await readFile(`${base}/${name}`,'utf8'));
 r.exploratoryPolicy={variant,planningProfile:r.profileId,horizon:Number(horizon),sourceHead,developmentOnly:true,source:'probe.mjs',maxPieces:128};
 await writeFile(`${base}/${name}`,JSON.stringify(r,null,2));
 rows.push({file:name,variant,seed:Number(seed),horizon:Number(horizon),maximumDepth:r.maximumDepth,pieces:r.piecesPlaced,firstBest:r.trace.find(x=>x.maximumDepth===r.maximumDepth)?.step,rejected:r.rejectedActions,topOut:r.topOut,preparedReplay:r.preparedReplay?.status,sha256:createHash('sha256').update(await readFile(`${base}/${name}`)).digest('hex')});
}
const manifest={
 kind:'bounded-policy-development',sourceHead,runtime:{node:process.version,platform:process.platform,arch:process.arch},
 interpretation:'Post-exploration record of adaptive policy development, not a preregistered comparison, independent holdout, timed campaign, or human calibration. Every trace begins from an empty infinity board and uses only real seeded tetromino actions. Trigger replays are separately labeled prepared evidence.',
 boardRows:44,previewLimit:3,decisionSeed:'capabilities-v2:<seed>',
 baseProfile:'expert',chosenVariant:'progress',chosenParameters:{futureHorizon:3,lookaheadBreadth:6,rootShortlist:4,futureShortlist:2,exactTieRanking:'existing expert score',newRecordScale:300,repeatedDepthScale:15,depthExponent:3,preparation:10,holes:-7,maxHeight:-3,bumpiness:-2,topOutRisk:-200,pathCost:-0.3},
 tradeoff:'Chosen for deepest demonstrated construction (six waves) and smaller search budget; one of three development seeds tops out at piece127. Wider root8 candidate reaches4/5/5 with no top-outs. Neither establishes higher-star fairness or preservation.',
 rows,
};
await writeFile(`${base}/manifest.json`,JSON.stringify(manifest,null,2));
console.log(JSON.stringify({runs:rows.length,placements:rows.reduce((n,r)=>n+r.pieces,0),maximumDepth:Math.max(...rows.map(r=>r.maximumDepth)),rejected:rows.reduce((n,r)=>n+r.rejected,0),topOuts:rows.filter(r=>r.topOut).length,manifest:`${base}/manifest.json`}));
