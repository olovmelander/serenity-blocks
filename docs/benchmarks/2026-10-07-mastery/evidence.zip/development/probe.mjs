import { BenchmarkBot } from '../../scripts/odyssey-benchmark/profiles.mjs';
import { demonstrateConstruction } from '../../scripts/odyssey-benchmark/capabilities.mjs';
import { writeFile } from 'node:fs/promises';
const variant=process.argv[2] || 'baseline';
const seed=Number(process.argv[3] || 9101);
const horizon=Number(process.argv[4] || 2);
const originalPlan=BenchmarkBot.prototype.plan;
const originalRank=BenchmarkBot.prototype.rank;
if(variant!=='baseline') {
 BenchmarkBot.prototype.plan=function(){this.config.lookaheadDepth=horizon; if(variant==='progresswide') this.config.lookaheadBreadth=16; return originalPlan.call(this);};
 BenchmarkBot.prototype.rank=function(candidates,config=this.config){
  const ranked=originalRank.call(this,candidates,config);
  for(const c of ranked){
   const m=c.boardMetrics,p=c.preparationAfter,d=c.cascadeCount;
   let score=c.evaluation.score;
   if(variant==='delay') score-=c.totalLines>0&&d<5 ? 500+c.totalLines*120 : 0;
   if(variant==='prepare') score+=p.preparationScore*15+(c.totalLines>0&&d<5?-600:0);
   if(variant==='progress'||variant==='progresswide') score=(d>=2 ? d**3*(d>(c.metricsBefore.maxCascadeDepth||0)?300:15) : 0)+p.preparationScore*10-m.holes*7-m.maxHeight*3-m.bumpiness*2-m.topOutRisk*200-c.pathCost*.3;
   if(variant==='depth') score=d>=2?d**3*300:0, score+=p.preparationScore*10-m.holes*7-m.maxHeight*3-m.bumpiness*2-m.topOutRisk*200-c.pathCost*.3;
   c.evaluation.score=score;
  }
  return ranked.sort((a,b)=>b.evaluation.score-a.evaluation.score);
 };
}
const start=performance.now();
const result=await demonstrateConstruction({profileId:'expert',seed,infinity:true,maxPieces:128});
await writeFile(`artifacts/odyssey-depth-probes/${variant}-${seed}-h${horizon}.json`,JSON.stringify(result,null,2));
console.log(JSON.stringify({variant,seed,horizon,ms:Math.round(performance.now()-start),depth:result.maximumDepth,pieces:result.piecesPlaced,rejected:result.rejectedActions,topOut:result.topOut,cascades:result.cascades}));
