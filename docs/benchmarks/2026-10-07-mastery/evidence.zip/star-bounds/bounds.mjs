import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { getLevelById } from '/workspace/serenity-blocks/src/core/odyssey/data/levels.js';
import { calculateLineClearScore } from '/workspace/serenity-blocks/src/core/scoring.js';
import { COLS, HIDDEN_ROWS } from '/workspace/serenity-blocks/src/core/constants.js';
const repo='/workspace/serenity-blocks';
const sources=['src/core/odyssey/data/levels.js','src/core/scoring.js','src/core/constants.js','src/core/physics.js','src/core/odyssey/VictoryConditionEvaluator.js','src/core/game-modes/OdysseyMode.js'];
const fingerprints=Object.fromEntries(sources.map(path=>[path,createHash('sha256').update(readFileSync(`${repo}/${path}`)).digest('hex')]));
const minima=[14,30,36,40,49,55,59].map(id=>{
 const config=getLevelById(id);const depth=Math.max(...Object.values(config.stars).map(s=>s.combo||0));
 const minimumChainScore=Array.from({length:depth},(_,wave)=>calculateLineClearScore(1,config.mechanics.speed.startLevel,wave+1,false)).reduce((a,b)=>a+b,0);
 return {id,scoreGoal:config.victory.primary.target,scoreLevel:config.mechanics.speed.startLevel,depth,minimumChainScore,minimumCells:depth*COLS,generousBoardCellCap:(config.mechanics.board.rows+HIDDEN_ROWS)*COLS,showcase:config.victoryLapPolicy==='showcase',stars:config.stars};
});
const config=getLevelById(49);let level=config.mechanics.speed.startLevel;let untilNextLevel=15;let score=0;let lines=0;let quads=0;let depth=0;
function cascade(waves){
 const startScore=score;for(const[count,index]of waves.map((value,i)=>[value,i+1])){
  lines+=count;untilNextLevel-=count;if(untilNextLevel<=0){level++;untilNextLevel+=15;}
  score+=calculateLineClearScore(count,level,index,false);if(count===4)quads++;
 }
 depth=Math.max(depth,waves.length);return{waves,startScore,score,level,lines,quads,depth};
}
const prefix=Array.from({length:9},()=>cascade([4]));assert.equal(score,32200);assert.equal(quads,9);
const final=cascade([4,4,4,1,1,1,1,1]);assert.equal(final.score,102280);assert.equal(final.quads,12);assert.equal(final.depth,8);assert.equal(final.lines,53);
const metrics={};let quadLevel=7;let remaining=15;let quadScore=0;
for(let q=1;q<=12;q++){remaining-=4;if(remaining<=0){quadLevel++;remaining+=15;}quadScore+=calculateLineClearScore(4,quadLevel,1,false);metrics[q]=quadScore;}
assert.equal(metrics[10],36000);
const output={kind:'necessary-bounds-and-relaxed-score-schedule',legalConstructionDemonstrated:false,sourceFingerprints:fingerprints,minima,orb49:{priorQuadScoreLowerBounds:metrics,conclusions:{minimumChainScore:51000,chainMustBeFinal:true,maxPriorQuads:9,maxFinalQuadsFromGenerous240CellCap:5,minPriorQuads:7,minFinalQuads:3,minFinalCascadeLines:17,minFinalCascadeCells:170},relaxedScoreSchedule:{prefix,final,assumptions:['Separate locks between prior Quads reset consecutive-clear multipliers.','Lock bonus can be zero once piece age reaches 100 simulation frames.','No perfect clears occur.','No board geometry, legal tetromino construction, random bag or finite input reachability is claimed.','The last cascade drains in full before the no-lap objective closes the attempt.']}}};
writeFileSync('/workspace/scratch/odyssey-star-bounds/analysis.json',JSON.stringify(output,null,2)+'\n');
console.log(JSON.stringify({minima:output.minima.map(({stars,...entry})=>entry),orb49:output.orb49.conclusions,relaxedFinal:final},null,2));
