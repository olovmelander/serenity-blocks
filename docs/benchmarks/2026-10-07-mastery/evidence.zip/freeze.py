import hashlib,json,re,subprocess,datetime
from pathlib import Path
root=Path(__file__).resolve().parent
repo=root.parents[1]
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
def sha(data):return hashlib.sha256(data).hexdigest()
registration=json.loads((root/'registration.json').read_text())
assert not registration['executionReady']
benchmark=[repo/'scripts/odyssey-benchmark.mjs',*sorted((repo/'scripts/odyssey-benchmark').glob('*.mjs'))]
application=[repo/name for name in git('ls-files','-z','--cached','--others','--exclude-standard','--','src','package.json','package-lock.json').decode().split('\0') if re.search(r'\.(?:[cm]?[jt]s|json)$',name)]
application.sort()
bh=hashlib.sha256();ah=hashlib.sha256()
for path in benchmark:bh.update(path.read_bytes())
for path in application:
    ah.update((str(path.relative_to(repo))+'\0').encode());ah.update(path.read_bytes() if path.exists() else b'<deleted>')
working=git('diff','HEAD','--','src','scripts','tests','package.json','package-lock.json')
assert not working, 'Commit implementation and tests before freezing'
manifest={str(p.relative_to(repo)):sha(p.read_bytes()) for p in [*benchmark,*application]}
(root/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
base='ca3884e70a868f1ff346ec0ca851476fb53481ef'
patch=git('diff','--binary',base,'HEAD','--','src','scripts','tests','package.json','package-lock.json')
(root/'source.patch').write_bytes(patch)
(root/'working-tree.patch').write_bytes(working)
freeze=registration['sourceFreeze']
freeze.update({'frozenAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commit':git('rev-parse','HEAD').decode().strip(),'benchmarkHash':bh.hexdigest(),'applicationHash':ah.hexdigest(),'runtime':json.loads(subprocess.check_output(['node','-e','console.log(JSON.stringify({node:process.version,platform:process.platform,arch:process.arch}))'],cwd=repo)),'workingTreePatchSha256':sha(working),'baseCommit':base,'sourcePatchSha256':sha(patch),'sourceManifest':{'path':'source-manifest.json','sha256':sha((root/'source-manifest.json').read_bytes())},'registrationSha256RecordedExternally':True})
commands={
'duels':['node','scripts/odyssey-benchmark.mjs','--levels','4,9,53,58','--profiles','cascade,duelist','--cadences','steady','--samples','10','--seed-start','10001','--workers','2','--max-seconds','1800','--max-pieces','3000','--wall-ms','240000','--output','artifacts/odyssey-mastery-followup-2026-10-07/duels'],
'construction':['node','scripts/odyssey-benchmark.mjs','--capabilities-only','--levels','49,55,59','--profiles','expert,chain','--construction-levels','49,55,59','--construction-seeds','10001,10002,10003,10004,10005','--construction-pieces','128','--output','artifacts/odyssey-mastery-followup-2026-10-07/construction']}
registration['commands']=commands
registration['status']='frozen-before-fresh-observations';registration['executionReady']=True
(root/'registration.json').write_text(json.dumps(registration,indent=2)+'\n')
(root/'registration.sha256').write_text(sha((root/'registration.json').read_bytes())+'  registration.json\n')
print(json.dumps(freeze,indent=2))
