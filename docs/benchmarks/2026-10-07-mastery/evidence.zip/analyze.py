#!/usr/bin/env python3
"""Deterministic analysis from registered raw/config/capability artifacts only.

No summary.json dependency, inferential tests, imputation or replacement attempts.
Construction checks inspect recorded traces; they do not independently replay physics.
"""
import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import statistics


def read_json(path):
    return json.loads(path.read_text()) if path.exists() else None


def finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def describe(values):
    values = sorted(v for v in values if finite(v))
    return {"n": len(values), "median": statistics.median(values) if values else None,
            "p90": values[math.ceil(.9 * len(values)) - 1] if values else None}


def count(values):
    return dict(sorted(Counter(str(v) for v in values).items()))


def reduction(before, after, key):
    a, b = before[key], after[key]
    return 1 - b / a if finite(a) and finite(b) and a > 0 else None


def quality_censored(row):
    return bool(row.get("qualityCensored") or row.get("lapCensored"))


def resolved(row):
    return row is not None and row.get("outcome") in ("win", "loss") and not row.get("primaryCensored")


def attack_yield(row):
    players = (row.get("duel") or {}).get("telemetry", {}).get("players", [])
    numerator = players[0].get("attackLinesSent") if players else None
    denominator = row.get("pieces")
    return numerator / denominator if finite(numerator) and finite(denominator) and denominator > 0 else None


def assert_equal(errors, label, actual, expected):
    if actual != expected:
        errors.append({"field": label, "actual": actual, "expected": expected})


def provenance(config, registration):
    errors = []
    freeze = registration.get("sourceFreeze", {})
    if registration.get("executionReady") is not True:
        errors.append({"field": "registration.executionReady", "expected": True})
    analyzer_hash = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    assert_equal(errors, "sourceFreeze.analyzerSha256", freeze.get("analyzerSha256"), analyzer_hash)
    expected = {"head": freeze.get("commit") or freeze.get("head"),
                "benchmarkHash": freeze.get("benchmarkHash"),
                "applicationHash": freeze.get("applicationHash"), "runtime": freeze.get("runtime")}
    for key, value in expected.items():
        if value is None:
            errors.append({"field": "sourceFreeze." + key, "reason": "not frozen"})
        elif config is not None:
            assert_equal(errors, "revision." + key, config.get("revision", {}).get(key), value)
    return errors


def outcome_summary(rows, planned):
    wins = [r for r in rows if r.get("outcome") == "win"]
    return {"planned": planned, "recorded": len(rows), "outcomes": count(r.get("outcome") for r in rows),
            "lossReasons": count(r.get("reason") for r in rows if r.get("outcome") == "loss"),
            "primaryCensored": sum(bool(r.get("primaryCensored") or r.get("outcome") == "censored") for r in rows),
            "qualityCensored": sum(quality_censored(r) for r in rows),
            "winStars": count(r.get("stars") for r in wins if not quality_censored(r)),
            "successfulSeconds": describe(r.get("elapsedSeconds") for r in wins),
            "defeatSeconds": describe(r.get("elapsedSeconds") for r in rows if r.get("outcome") == "loss"),
            "attackRowsPerPieceAllRecorded": describe(attack_yield(r) for r in rows)}


def attribution_issues(row):
    issues = []
    duel = row.get("duel") or {}
    telemetry = duel.get("telemetry", {})
    players = telemetry.get("players", [])
    if len(players) != 2:
        return ["missing two-player telemetry"]
    primary = row.get("effectiveConfig", {}).get("victory", {}).get("primary", {})
    if primary.get("type") != "frags" or primary.get("target") != 7:
        issues.append("effective primary is not seven frags")
    if row.get("outcome") == "win" and players[0].get("frags") != 7:
        issues.append("win without seven human frags")
    for index, player in enumerate(players):
        if player.get("deaths") != player.get("creditedDeaths", 0) + player.get("uncreditedDeaths", 0):
            issues.append(f"player {index} death totals mismatch")
        if player.get("frags") != players[1 - index].get("creditedDeaths"):
            issues.append(f"player {index} frag attribution mismatch")
    return issues


def analyze_duels(folder, reg):
    config, rules = read_json(folder / "config.json"), reg["duelScreen"]
    raw_path = folder / "raw.jsonl"
    rows = [json.loads(line) for line in raw_path.read_text().splitlines() if line.strip()] if raw_path.exists() else []
    errors = provenance(config, reg)
    if config is None:
        return {"status": "not started", "validationErrors": errors}
    for key, expected in (("levelIds", rules["levels"]), ("profileIds", rules["profiles"]),
                          ("cadenceIds", rules["cadences"]), ("scenarioIds", rules["scenarios"])):
        assert_equal(errors, key, sorted(config.get(key, [])), sorted(expected))
    for key, expected in {**rules["budgets"], "samples": rules["attemptsPerOrbProfile"],
                          "seedStart": rules["seeds"]["from"], "plannedAttempts": rules["plannedAttempts"],
                          "humanPlanningPreviewLimit": 3, "opponentPlanningPreviewLimit": None,
                          "opponentKnowledgePolicy": rules["opponentPlanningPolicy"]}.items():
        assert_equal(errors, key, config.get(key), expected)
    seeds = list(range(rules["seeds"]["from"], rules["seeds"]["to"] + 1))
    expected_keys = {(level, profile, seed) for level in rules["levels"] for profile in rules["profiles"] for seed in seeds}
    by_key, row_errors = {}, []
    for row in rows:
        key = (row.get("levelId"), row.get("profileId"), row.get("seed"))
        if key not in expected_keys or key in by_key:
            errors.append({"field": "attempt keys", "key": key, "reason": "unexpected or duplicate"})
            continue
        by_key[key] = row
        details = []
        for field, expected in {"scenarioId": "baseline", "cadenceId": "steady", "humanPlanningPreviewLimit": 3,
                                "opponentKnowledgePolicy": rules["opponentPlanningPolicy"],
                                "opponentPlanningPreviewLimit": None, "opponentPreviewCount": None}.items():
            assert_equal(details, field, row.get(field), expected)
        if resolved(row):
            details.extend({"field": "attribution", "reason": issue} for issue in attribution_issues(row))
        if details:
            row_errors.append({"key": key, "errors": details})
    orbs = []
    base, candidate = rules["baselineProfile"], rules["candidateProfile"]
    for level in rules["levels"]:
        transitions, pairs, win_pairs, lower_stars, higher_stars = Counter(), [], [], [], []
        for seed in seeds:
            a, b = by_key.get((level, base, seed)), by_key.get((level, candidate, seed))
            if not resolved(a) or not resolved(b):
                transition = "unresolved"
            elif a["outcome"] == "win" and b["outcome"] == "win":
                transition = "bothWin"
                win_pairs.append((seed, a, b))
                if not quality_censored(a) and not quality_censored(b):
                    if b["stars"] < a["stars"]: lower_stars.append(seed)
                    if b["stars"] > a["stars"]: higher_stars.append(seed)
            elif a["outcome"] == "win": transition = "lostBaselineWin"
            elif b["outcome"] == "win": transition = "gainedWin"
            else: transition = "bothLose"
            transitions[transition] += 1
            pairs.append({"seed": seed, "transition": transition,
                          "baselineOutcome": a.get("outcome") if a else "missing",
                          "candidateOutcome": b.get("outcome") if b else "missing"})
        times_a = describe(a.get("elapsedSeconds") for _, a, _ in win_pairs)
        times_b = describe(b.get("elapsedSeconds") for _, _, b in win_pairs)
        deltas = []
        for seed, a, b in win_pairs:
            ya, yb = attack_yield(a), attack_yield(b)
            deltas.append({"seed": seed, "baselineSeconds": a.get("elapsedSeconds"),
                           "candidateSeconds": b.get("elapsedSeconds"),
                           "secondsDelta": b["elapsedSeconds"] - a["elapsedSeconds"],
                           "baselineAttackRowsPerPiece": ya, "candidateAttackRowsPerPiece": yb,
                           "attackRowsPerPieceDelta": yb - ya if ya is not None and yb is not None else None})
        yield_deltas = describe(pair["attackRowsPerPieceDelta"] for pair in deltas)
        improvement = {"median": reduction(times_a, times_b, "median"), "p90": reduction(times_a, times_b, "p90")}
        gates = None
        if level in rules["earlyPacingRecommendation"]["levels"]:
            g = rules["earlyPacingRecommendation"]["gatesPerOrb"]
            local_rows = [r for key, r in by_key.items() if key[0] == level]
            gates = {
                "sourceAndConfiguration": not errors,
                "rowMetadataAndAttribution": not any(e["key"][0] == level for e in row_errors),
                "resolvedCoverage": (len(seeds) - transitions["unresolved"]) / len(seeds) >= g["minimumResolvedPairFraction"],
                "noRuntimeErrors": all(r.get("outcome") != "error" for r in local_rows),
                "noLostBaselineWins": transitions["lostBaselineWin"] <= g["maximumLostBaselinePrimaryWins"],
                "bothWinMinimum": len(win_pairs) >= g["minimumBothWinPairs"],
                "medianImprovement": finite(improvement["median"]) and improvement["median"] >= g["minimumMedianSuccessfulTimeImprovement"],
                "p90Improvement": finite(improvement["p90"]) and improvement["p90"] >= g["minimumP90SuccessfulTimeImprovement"],
                "attackYieldIncrease": yield_deltas["n"] == len(win_pairs) and finite(yield_deltas["median"]) and yield_deltas["median"] > 0,
            }
        orbs.append({"levelId": level, "profiles": {p: outcome_summary([r for k, r in by_key.items() if k[:2] == (level, p)], len(seeds)) for p in rules["profiles"]},
                     "pairedTransitions": dict(transitions), "pairs": pairs,
                     "bothWinPacing": {"baseline": times_a, "candidate": times_b, "relativeImprovement": improvement,
                                       "pairedSecondsDelta": describe(p["secondsDelta"] for p in deltas), "pairs": deltas},
                     "pairedAttackYieldDelta": yield_deltas,
                     "lowerStarsAmongBothWins": lower_stars, "higherStarsAmongBothWins": higher_stars,
                     "earlyScreenGates": gates,
                     "eligibleForOrbSpecificConfirmationReview": all(gates.values()) if gates else None,
                     "additionalReviewRequired": bool(lower_stars)})
    early = [orb for orb in orbs if orb["earlyScreenGates"] is not None]
    return {"status": "completed" if set(by_key) == expected_keys else "incomplete", "revision": config.get("revision"),
            "plannedAttempts": len(expected_keys), "recordedAttempts": len(rows),
            "missingAttempts": sorted(expected_keys - set(by_key)), "validationErrors": errors,
            "rowValidationErrors": row_errors, "orbs": orbs,
            "eligibleForGeneralEarlyConfirmationReview": all(o["eligibleForOrbSpecificConfirmationReview"] for o in early),
            "productionRetuneSelected": False}


def authored_trace_checks(demo):
    trace = demo.get("trace", [])
    issues = []
    for field, expected in {"traceValid": True, "traceComplete": True, "allTetrominoes": True,
                            "addedCellsAfterStart": 0, "failedActions": 0, "previewLimit": 3, "timed": False}.items():
        if demo.get(field) != expected: issues.append(field)
    if demo.get("error"): issues.append("error")
    if not trace: issues.append("empty trace")
    if len(trace) != demo.get("piecesPlaced"): issues.append("trace/piece count")
    previous_hash = demo.get("initialBoardHash")
    for entry in trace:
        if not entry.get("completed"): issues.append("incomplete entry")
        if entry.get("boardHashBefore") != previous_hash: issues.append("board hash continuity")
        previous_hash = entry.get("boardHashAfter")
        conservation = entry.get("cellConservation", {})
        if conservation.get("actual") != conservation.get("expected") or not conservation:
            issues.append("cell conservation")
        if entry.get("lockedPiece", {}).get("cells") != 4: issues.append("tetromino cells")
        if len(entry.get("preview", [])) > 3: issues.append("preview count")
        for action in entry.get("actions", []):
            if not action.get("accepted") and not action.get("legalStop"): issues.append("illegal action")
    if demo.get("levelId") == 49 and demo.get("primaryReachedAtPiece") is not None:
        if demo.get("piecesPlaced") != demo["primaryReachedAtPiece"] or demo.get("termination") != "primary-complete":
            issues.append("normal finish policy")
    return sorted(set(issues))


def analyze_construction(folder, reg):
    config, caps = read_json(folder / "config.json"), read_json(folder / "capabilities.json")
    rules, errors = reg["constructionScreen"], provenance(config, reg)
    if config is None or caps is None:
        return {"status": "not started" if config is None else "incomplete", "validationErrors": errors}
    for key, expected in {"levelIds": rules["authored"]["levels"], "profileIds": rules["profiles"],
                          "constructionLevelIds": rules["authored"]["levels"], "constructionSeeds": rules["seeds"],
                          "constructionMaxPieces": rules["maxPieces"], "capabilitiesOnly": True}.items():
        assert_equal(errors, key, config.get(key), expected)
    authored = caps.get("authoredConstruction", {}).get("demonstrations", [])
    empty = [demo for profile in caps.get("profiles", []) for demo in profile.get("construction", {}).get("demonstrations", [])]
    output = []
    for kind, demos, contexts, context_key in (("authored", authored, rules["authored"]["levels"], "levelId"),
                                              ("empty", empty, rules["empty"]["modes"], "baseMode")):
        expected = {(context, profile, seed) for context in contexts for profile in rules["profiles"] for seed in rules["seeds"]}
        seen, groups = set(), []
        for context in contexts:
            for profile in rules["profiles"]:
                observations = []
                for demo in demos:
                    if demo.get(context_key) != context or demo.get("profileId") != profile: continue
                    key = (context, profile, demo.get("seed"))
                    if key in seen or key not in expected:
                        errors.append({"field": kind + " keys", "key": key, "reason": "unexpected or duplicate"})
                    seen.add(key)
                    assert_equal(errors, f"{kind} {key} pieceBudget", demo.get("pieceBudget"), rules["maxPieces"])
                    if kind == "authored":
                        issues = authored_trace_checks(demo)
                        target = rules["authored"]["primaryChainQuestions"][str(context)]
                    else:
                        issues = [field for field, value in {"timed": False, "previewLimit": 3, "rejectedActions": 0,
                                  "insertedCells": 0, "allTetrominoes": True}.items() if demo.get(field) != value]
                        if demo.get("error"): issues.append("error")
                        if not demo.get("trace"): issues.append("empty trace")
                        assert_equal(errors, f"empty {key} targetDepth", demo.get("targetDepth"), rules["empty"]["targetDepth"])
                        target = rules["empty"]["targetDepth"]
                    qualified = not issues
                    depth = demo.get("maximumDepth", 0)
                    observations.append({"seed": demo.get("seed"), "driverStatus": demo.get("status"),
                        "recordedTraceQualified": qualified, "traceIssues": issues,
                        "maximumDepth": depth, "targetDepth": target,
                        "qualifiedTargetAttained": qualified and depth >= target,
                        "piecesPlaced": demo.get("piecesPlaced"), "termination": demo.get("termination"),
                        "topOut": demo.get("topOut"), "primaryReachedAtPiece": demo.get("primaryReachedAtPiece"),
                        "metrics": demo.get("metrics"), "quality": demo.get("quality"),
                        "requirements": demo.get("requirements"),
                        "initialBoardHash": demo.get("initialBoardHash"),
                        "preparedReplayStatus": (demo.get("preparedReplay") or {}).get("status")})
                qualified = [o for o in observations if o["recordedTraceQualified"]]
                groups.append({"context": context, "profile": profile, "planned": len(rules["seeds"]),
                    "recorded": len(observations), "qualifiedRecordedTraces": len(qualified),
                    "depthTargets": {str(target): sum(o["maximumDepth"] >= target for o in qualified) for target in rules["empty"]["recordedDepthTargets"]},
                    "maximumQualifiedDepth": max((o["maximumDepth"] for o in qualified), default=None),
                    "observations": sorted(observations, key=lambda o: o["seed"])})
        for demo in demos:
            key = (demo.get(context_key), demo.get("profileId"), demo.get("seed"))
            if key not in expected:
                errors.append({"field": kind + " keys", "key": key, "reason": "unexpected"})
        output.append({"kind": kind, "planned": len(expected), "recorded": len(demos),
                       "missing": sorted(expected - seen), "groups": groups})
    return {"status": "completed" if all(not item["missing"] for item in output) else "incomplete",
            "revision": config.get("revision"), "validationErrors": errors,
            "mechanicsStatus": caps.get("mechanics", {}).get("status"), "timed": False,
            "traceVerificationScope": "Recorded driver flags and trace structure; no independent physics replay by this Python analyzer.",
            "contexts": output, "timedStarValidation": False, "productionRetuneSelected": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    reg = read_json(root / "registration.json")
    if reg is None: raise SystemExit("Missing registration.json")
    def output_folder(command_key, fallback):
        command = reg.get("commands", {}).get(command_key, [])
        name = Path(command[command.index("--output") + 1]).name if "--output" in command else fallback
        return root / name
    duel_folder = output_folder("duels", "duels")
    construction_folder = output_folder("construction", "construction")
    paths = [root / "registration.json", Path(__file__).resolve()]
    for folder in (duel_folder, construction_folder):
        paths += [folder / filename for filename in ("config.json", "capabilities.json", "raw.jsonl")]
    analysis = {
        "schemaVersion": 1,
        "interpretation": "Descriptive registered policy screen and untimed construction; no human validation or production adoption.",
        "quantiles": "Median; nearest-rank p90 at ceil(0.9*n), one-based. Successful pacing uses identical both-win pairs.",
        "inputHashes": {str(path.relative_to(root)) if path.is_relative_to(root) else path.name:
                        hashlib.sha256(path.read_bytes()).hexdigest() for path in paths if path.exists()},
        "duels": analyze_duels(duel_folder, reg),
        "construction": analyze_construction(construction_folder, reg),
    }
    output = args.output or root / "analysis.json"
    output.write_text(json.dumps(analysis, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"output": str(output), "duels": analysis["duels"]["status"],
                      "construction": analysis["construction"]["status"]}))


if __name__ == "__main__":
    main()
