import json, pathlib, shutil
from playwright.sync_api import sync_playwright
output=pathlib.Path('/workspace/serenity-blocks/artifacts/odyssey-mastery-ui')
results=[]
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=shutil.which('chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    for size in [{'name':'desktop','width':1440,'height':1000},{'name':'phone','width':430,'height':844}]:
        page=browser.new_page(viewport={'width':size['width'],'height':size['height']},device_scale_factor=1,reduced_motion='reduce')
        errors=[]
        page.on('pageerror',lambda error: errors.append(str(error)))
        page.on('console',lambda msg: errors.append(msg.text) if msg.type=='error' else None)
        page.goto('http://127.0.0.1:5187/artifacts/odyssey-mastery-ui/fixture.html',wait_until='networkidle')
        page.wait_for_function('window.__HUD_READY__ === true')
        for orb,depth in [(49,8),(55,18),(59,12)]:
            page.evaluate('(id)=>fixture.setLevel(id)',orb)
            hud=page.locator('#odyssey-hud')
            assert page.locator('.star-row').nth(2).inner_text().count(f'{depth}-wave chain')==1
            assert 'x combo' not in hud.inner_text()
            page.locator('.star-row').nth(2).scroll_into_view_if_needed()
            page.screenshot(path=str(output/f'{size["name"]}-orb{orb}-stars.png'))
            page.evaluate('fixture.hud.guide.open=true; fixture.hud.container.scrollTop=0')
            page.locator('.level-guide').scroll_into_view_if_needed()
            page.screenshot(path=str(output/f'{size["name"]}-orb{orb}-guide.png'))
            metrics=page.evaluate('''()=>({guide:fixture.hud.guideText.textContent,width:fixture.hud.container.clientWidth,scrollWidth:fixture.hud.container.scrollWidth,height:fixture.hud.container.clientHeight,scrollHeight:fixture.hud.container.scrollHeight,stars:[...document.querySelectorAll('.star-row')].map(e=>e.innerText)})''')
            assert metrics['scrollWidth']<=metrics['width']+1
            results.append({'viewport':size['name'],'orb':orb,**metrics,'consoleErrors':list(errors)})
        page.close()
    browser.close()
(output/'inspection.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps([{'viewport':r['viewport'],'orb':r['orb'],'height':r['height'],'scrollHeight':r['scrollHeight'],'horizontalOverflow':r['scrollWidth']-r['width'],'consoleErrors':r['consoleErrors']} for r in results],indent=2))
