#!/usr/bin/env python3
"""Verify frozen archived bytes, then correct only the application digest in memory.

Use --verify-only before outcomes may be inspected. Ordinary execution runs the
unchanged original analyzer and preserves analysis-original.json before producing
analysis.json with the explicit provenance correction and expanded input hashes.
"""
import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys
import zipfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load(path):
    return json.loads(path.read_text())


def require(condition, message):
    if not condition:
        raise ValueError(message)


def output_folder(root, registration, key):
    command = registration["commands"][key]
    return root / Path(command[command.index("--output") + 1]).name


def verify(root):
    correction = load(root / "provenance-correction.json")
    registration = load(root / "registration.json")
    freeze = registration["sourceFreeze"]
    require(registration["executionReady"] is True, "Registration is not frozen")
    for name, expected_hash in correction["immutableArtifactHashes"].items():
        require(sha((root / name).read_bytes()) == expected_hash, f"Artifact bytes changed: {name}")
    require((root / "registration.sha256").read_text().split()[0] == sha((root / "registration.json").read_bytes()),
            "Original external registration checksum differs")
    require(sha((root / "analyze.py").read_bytes()) == freeze["analyzerSha256"], "Original analyzer changed")
    manifest_path = root / freeze["sourceManifest"]["path"]
    require(sha(manifest_path.read_bytes()) == freeze["sourceManifest"]["sha256"], "Pre-run manifest changed")
    manifest = load(manifest_path)
    with zipfile.ZipFile(root / "source-snapshot.zip") as archive:
        names = [info.filename for info in archive.infolist() if not info.is_dir()]
        require(len(names) == len(set(names)) == len(manifest), "Snapshot duplicate or extra/missing entries")
        require(set(names) == set(manifest), "Snapshot/manifest paths differ")
        source = {}
        for name in names:
            data = archive.read(name)
            require(sha(data) == manifest[name], f"Archived source mismatch: {name}")
            source[name] = data
    application_names = [name for name in names if (name.startswith("src/") or name in ("package.json", "package-lock.json"))
                         and re.search(r"\.(?:[cm]?[jt]s|json)$", name)]
    # JavaScript Array.sort() compares UTF-16 code units, not filesystem components.
    cli_names = sorted(application_names, key=lambda name: name.encode("utf-16-be", errors="surrogatepass"))
    buggy_names = sorted(application_names, key=lambda name: PurePosixPath(name).parts)
    def application_digest(ordered):
        digest = hashlib.sha256()
        for name in ordered:
            digest.update((name + "\0").encode("utf-8"))
            digest.update(source[name])
        return digest.hexdigest()
    corrected_digest = application_digest(cli_names)
    recorded_digest = application_digest(buggy_names)
    require(recorded_digest == freeze["applicationHash"] == correction["recordedApplicationHash"],
            "Archived bytes do not reproduce the originally registered component-sorted digest")
    require(corrected_digest == correction["correctApplicationHash"], "Corrected CLI digest differs from correction record")
    benchmark_names = ["scripts/odyssey-benchmark.mjs"] + sorted(
        [name for name in names if name.startswith("scripts/odyssey-benchmark/") and name.endswith(".mjs")],
        key=lambda name: name.encode("utf-16-be", errors="surrogatepass"))
    benchmark_digest = sha(b"".join(source[name] for name in benchmark_names))
    require(benchmark_digest == freeze["benchmarkHash"], "Archived benchmark digest changed")
    configs = {}
    for key in ("duels", "construction"):
        path = output_folder(root, registration, key) / "config.json"
        config = load(path)
        expected = {"head": freeze["commit"], "benchmarkHash": benchmark_digest,
                    "applicationHash": corrected_digest, "runtime": freeze["runtime"]}
        require(all(config["revision"].get(field) == value for field, value in expected.items()),
                f"{key} config does not match frozen source/runtime and computed CLI digest")
        configs[key] = {"path": str(path.relative_to(root)), "sha256": sha(path.read_bytes()), "revision": config["revision"]}
    return registration, correction, {
        "verifiedArchivedSourceFiles": len(source), "applicationFiles": len(application_names),
        "benchmarkFiles": len(benchmark_names), "originalDigestReproduced": recorded_digest,
        "computedCliApplicationHash": corrected_digest, "computedBenchmarkHash": benchmark_digest,
        "configs": configs, "metricCodeUnchanged": True, "cohortsReplaced": False,
        "registrationBytesUnchanged": True, "sourceBytesUnchanged": True,
    }


def metric_view(value):
    """Remove only provenance eligibility fields; every recorded measurement remains."""
    if isinstance(value, list):
        return [metric_view(item) for item in value]
    if not isinstance(value, dict):
        return value
    ignored = {"validationErrors", "eligibleForOrbSpecificConfirmationReview", "eligibleForGeneralEarlyConfirmationReview"}
    result = {}
    for key, item in value.items():
        if key in ignored:
            continue
        if key == "earlyScreenGates" and isinstance(item, dict):
            item = {gate: outcome for gate, outcome in item.items() if gate != "sourceAndConfiguration"}
        result[key] = metric_view(item)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--verify-only", action="store_true")
    args = parser.parse_args()
    root = args.root.resolve()
    registration, correction, verification = verify(root)
    if args.verify_only:
        print(json.dumps(verification, indent=2, sort_keys=True))
        return
    original_path = root / "analyze.py"
    original_output = root / "analysis-original.json"
    if not original_output.exists():
        subprocess.run([sys.executable, str(original_path), "--root", str(root), "--output", str(original_output)], check=True)
    original = load(original_output)
    for name, expected_hash in original["inputHashes"].items():
        require(sha((root / name).read_bytes()) == expected_hash, f"Original-analysis input changed: {name}")
    spec = importlib.util.spec_from_file_location("frozen_mastery_analysis", original_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    effective_registration = copy.deepcopy(registration)
    effective_registration["sourceFreeze"]["applicationHash"] = verification["computedCliApplicationHash"]
    result = copy.deepcopy(original)
    result["duels"] = module.analyze_duels(output_folder(root, registration, "duels"), effective_registration)
    result["construction"] = module.analyze_construction(output_folder(root, registration, "construction"), effective_registration)
    require(metric_view(original["duels"]) == metric_view(result["duels"]), "Duel metrics changed during provenance correction")
    require(metric_view(original["construction"]) == metric_view(result["construction"]), "Construction metrics changed during provenance correction")
    result["provenanceCorrection"] = {"record": correction, "verification": verification,
        "effectiveRegistrationChange": "Only sourceFreeze.applicationHash is replaced in an in-memory copy with the digest computed from the frozen ZIP.",
        "originalAnalysis": "analysis-original.json", "metricCodeUnchanged": True,
        "allRecordedMeasurementsUnchanged": True, "cohortsReplaced": False}
    names = ["registration.json", "registration.sha256", "analyze.py", "analyze-verified.py",
             "provenance-correction.json", "source-manifest.json", "source-snapshot.zip", "source.patch",
             "working-tree.patch", "freeze.py", "analysis-original.json"]
    result["inputHashes"].update({name: sha((root / name).read_bytes()) for name in names})
    (root / "analysis.json").write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"output": str(root / "analysis.json"), "originalAnalysis": str(original_output),
                      "metricCodeUnchanged": True, "duels": result["duels"]["status"], "construction": result["construction"]["status"]}))


if __name__ == "__main__":
    main()
