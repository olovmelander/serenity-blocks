#!/usr/bin/env python3
"""Portable mapping of original assignments and separate recovery observations; never pool cohorts."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    root = args.root.resolve()
    hashes = {}

    def read(name):
        data = (root / name).read_bytes()
        hashes[name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        return data

    def load(name):
        return json.loads(read(name))

    original = load('registration.json')
    recovery = load('recovery/registration.json')
    for prefix in ('', 'recovery/'):
        registration_hash = hashes[prefix + 'registration.json']['sha256']
        assert registration_hash == read(prefix + 'registration.sha256').decode().split()[0]
    provenance = recovery['recoveryProvenance']
    for key in ('originalRegistration', 'preservedPartialManifest', 'preparationScript', 'sourceCheck'):
        reference = provenance[key]
        path = (root / 'recovery' / reference['path']).resolve().relative_to(root).as_posix()
        assert hashlib.sha256(read(path)).hexdigest() == reference['sha256'], key
    preserved = load('interruption-preserved-files.json')
    for path, details in preserved['files'].items():
        data = read(path)
        assert details == {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}, path
    for name in ('analyze.py', 'analysis-shared.py', 'run.py', 'freeze.mjs'):
        assert read(name) == read('recovery/' + name), name
    assert original['sourceFreeze']['commit'] == recovery['sourceFreeze']['commit']
    assert original['sourceFreeze']['sourceHash'] == recovery['sourceFreeze']['sourceHash']
    original_analysis = load('analysis.json')
    recovery_analysis = load('recovery/analysis.json')
    for analysis, registration in [(original_analysis, original), (recovery_analysis, recovery)]:
        assert analysis['sourceVerification']['verified'] is True
        assert analysis['sourceVerification']['sourceHash'] == registration['sourceFreeze']['sourceHash']
    original_rows = {row['id']: row for row in original_analysis['tasks']}
    retry_rows = {row['id']: row for row in recovery_analysis['tasks']}
    original_children = {task['dependsOn']: task for task in original['tasks'] if task.get('dependsOn')}
    retry_children = {task['dependsOn']: task for task in recovery['tasks'] if task.get('dependsOn')}
    retry_parents = {task['retryOf']['taskId']: task for task in recovery['tasks'] if task['stage'] == 'online'}

    def compact(row):
        observation = row.get('observation', {})
        return {'id': row['id'], 'output': row['output'], 'status': row['status'],
                'provenanceVerified': row['provenanceVerified'], 'execution': row.get('execution'),
                'metrics': observation.get('metrics'), 'reason': observation.get('reason', observation.get('termination')),
                'primaryReached': observation.get('primaryReached', observation.get('primaryReachedUntimed')),
                'qualityCensored': observation.get('qualityCensored'),
                'independentUntimedReplayQualified': observation.get('independentUntimedReplayQualified'),
                'independentTimestampReplayQualified': observation.get('independentTimestampReplayQualified'),
                'independentlyReplayedFixedCadenceMastery': observation.get('independentlyReplayedFixedCadenceMastery'),
                'realTimePlanningQualified': observation.get('realTimePlanningQualified')}

    def completed_pair(parent, child):
        return all(row['status'] == 'completed' and row['provenanceVerified'] for row in (parent, child))

    mappings = []
    prefixes = []
    for parent in original['tasks']:
        if parent['stage'] not in ('search', 'online'):
            continue
        child = original_children[parent['id']]
        p, c = original_rows[parent['id']], original_rows[child['id']]
        mapping = {'originalParentId': parent['id'], 'levelId': parent['levelId'], 'seed': parent['seed'],
                   'cadence': parent.get('cadence'), 'stage': parent['stage'],
                   'original': {'parent': compact(p), 'replay': compact(c)}, 'recovery': None,
                   'selectedCompletedObservationSource': 'original' if completed_pair(p, c) else None,
                   'selectionIsCoverageOnly': True}
        if parent['id'] in retry_parents:
            retry = retry_parents[parent['id']]
            retry_child = retry_children[retry['id']]
            rp, rc = retry_rows[retry['id']], retry_rows[retry_child['id']]
            assert mapping['selectedCompletedObservationSource'] is None
            assert p['status'] == 'incomplete' and c['status'] == 'not-executed'
            mapping['recovery'] = {'parent': compact(rp), 'replay': compact(rc)}
            if completed_pair(rp, rc):
                mapping['selectedCompletedObservationSource'] = 'recovery'
            paths = [parent['output'] + '/progress.jsonl', 'recovery/' + retry['output'] + '/progress.jsonl']
            parsed, malformed = [], []
            for path in paths:
                records, bad = [], []
                for line_number, line in enumerate(read(path).decode().splitlines(), 1):
                    try:
                        records.append(json.loads(line))
                    except ValueError:
                        bad.append(line_number)
                parsed.append(records); malformed.append(bad)
            fields = ['step', 'piecesPlaced', 'metrics', 'nodes', 'decisions', 'counters', 'simSeconds']
            left = [{key: row.get(key) for key in fields} for row in parsed[0]]
            right = [{key: row.get(key) for key in fields} for row in parsed[1]]
            match_count, mismatch = 0, None
            for i, (before, after) in enumerate(zip(left, right)):
                if before != after:
                    mismatch = {'record': i + 1, 'original': before, 'retry': after}; break
                match_count += 1
            status = 'exact-recorded-prefix-match' if len(right) >= len(left) and mismatch is None else (
                'diverged' if mismatch else 'retry-shorter-than-interrupted-prefix')
            prefixes.append({'originalParentId': parent['id'], 'recoveryParentId': retry['id'],
                'originalCompleteProgressRecords': len(left), 'retryCompleteProgressRecords': len(right),
                'matchingRecords': match_count, 'status': status, 'firstMismatch': mismatch,
                'unparseableOriginalLines': malformed[0], 'unparseableRetryLines': malformed[1],
                'comparedFields': fields, 'excludedFields': ['elapsedWallMs', 'plannerWallMs', 'plannerCpuMs'],
                'qualification': 'Exact recorded progress prefix only; no observation was substituted into the original interrupted assignment.'})
        mappings.append(mapping)
    assert len(mappings) == 27 and len(prefixes) == 3
    output = {'schemaVersion': 1, 'kind': 'Separate-cohort observation coverage after an external interruption',
        'sourceCommit': original['sourceFreeze']['commit'], 'sourceHash': original['sourceFreeze']['sourceHash'],
        'original': {'registeredTasks': len(original['tasks']), 'taskStatuses': original_analysis['taskStatuses'],
                     'analysis': 'analysis.json', 'originalRecordsRetained': True},
        'recovery': {'registeredTasks': len(recovery['tasks']), 'taskStatuses': recovery_analysis['taskStatuses'],
                     'analysis': 'recovery/analysis.json', 'parameterChanges': []},
        'coverage': {'registeredOriginalParentReplayPairs': len(mappings),
                     'completedObservationPairsBySource': dict(Counter(row['selectedCompletedObservationSource'] or 'uncovered' for row in mappings)),
                     'purpose': 'Coverage accounting, not a pooled outcome cohort or replacement of interrupted originals.'},
        'parentReplayMappings': mappings, 'interruptedProgressPrefixComparisons': prefixes,
        'preservedPartialFilesVerified': len(preserved['files']),
        'limits': ['Original54 and recovery6 remain separate analyses with original interrupted and skipped rows intact.',
                   'Retries use the same previously used development seeds, source and options; they are not fresh confirmation.',
                   'Same seed/source alone does not prove the same path; recorded prefix equality or divergence is reported explicitly.',
                   'Planning wall/CPU time is uncharged to simulated gameplay; real-time planning and human feasibility remain unverified.',
                   'No causal effect, player win-rate or human fairness claim follows from combined observation coverage.'],
        'scriptSha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'inputHashes': dict(sorted(hashes.items()))}
    (root / 'combined-coverage.json').write_text(json.dumps(output, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'original': output['original'], 'recovery': output['recovery'], 'coverage': output['coverage'],
                      'prefixes': [{key: row[key] for key in ['originalParentId', 'status', 'matchingRecords', 'originalCompleteProgressRecords', 'retryCompleteProgressRecords']}
                                   for row in prefixes]}, indent=2))


if __name__ == '__main__':
    main()
