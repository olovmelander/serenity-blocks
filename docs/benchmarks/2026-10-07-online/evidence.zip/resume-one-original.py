#!/usr/bin/env python3
"""Resume only the original parent that had never started; preserve all existing files."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
registration = json.loads((root / 'registration.json').read_text())
assert hashlib.sha256((root / 'registration.json').read_bytes()).hexdigest() == (root / 'registration.sha256').read_text().split()[0]
task = next(task for task in registration['tasks'] if task['id'] == 'online-deliberate-orb-59-seed-9103')
assert not (root / task['output']).exists(), 'Original task has existing output; do not replace it'
assert not (root / 'execution-resumed-parent.json').exists()
log_name = 'logs/resumed-' + task['id'] + '.log'
launch = {'id': task['id'], 'output': task['output'], 'command': task['command'],
          'startedAt': datetime.now(timezone.utc).isoformat(), 'log': log_name,
          'scope': 'Untouched original assignment; same frozen command and original output path.'}
with (root / 'resume-launch.json').open('x') as file:
    file.write(json.dumps(launch, indent=2) + '\n')
print(json.dumps({'status': 'started', **launch}), flush=True)
with (root / log_name).open('x') as log:
    result = subprocess.run(task['command'], cwd=registration['repositoryRoot'], stdout=log, stderr=subprocess.STDOUT)
record = {'id': task['id'], 'exitCode': result.returncode, 'exitCodeObserved': True,
          'log': log_name, 'output': task['output'], 'resumedOriginalAssignment': True,
          'completedAt': datetime.now(timezone.utc).isoformat()}
with (root / 'execution-resumed-parent.json').open('x') as file:
    file.write(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
