#!/usr/bin/env python3
"""Checksum interrupted evidence, reconstruct known completion, and freeze separate retries."""
import copy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
INTERRUPTED = ['online-steady-orb-55-seed-9103', 'online-deliberate-orb-55-seed-9103', 'online-steady-orb-59-seed-9103']
UNSTARTED = 'online-deliberate-orb-59-seed-9103'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text())


def write(path, data):
    with path.open('x') as file:
        file.write(json.dumps(data, indent=2, sort_keys=True) + '\n')


def main():
    original = load(ROOT / 'registration.json')
    assert sha(ROOT / 'registration.json') == (ROOT / 'registration.sha256').read_text().split()[0]
    assert sha(ROOT / 'analyze.py') == original['sourceFreeze']['analyzerSha256']
    assert sha(ROOT / 'run.py') == original['runnerSha256']
    actual = json.loads(subprocess.check_output(['node', '--input-type=module', '-e',
        "import {captureSourceRevision} from './scripts/odyssey-mastery.mjs'; console.log(JSON.stringify(captureSourceRevision().revision));"],
        cwd=original['repositoryRoot'], text=True))
    assert actual['head'] == original['sourceFreeze']['commit']
    assert actual['sourceHash'] == original['sourceFreeze']['sourceHash']
    assert actual['runtime'] == original['sourceFreeze']['runtime']
    by_id = {task['id']: task for task in original['tasks']}
    hashes, records = {}, []
    for task in original['tasks']:
        if task['stage'] not in ('search', 'online') or task['id'] == UNSTARTED:
            continue
        directory = ROOT / task['output']
        if task['id'] in INTERRUPTED:
            assert directory.is_dir() and not (directory / 'summary.json').exists()
            assert not (directory / 'witness.json').exists() and not (directory / 'failure.json').exists()
            for path in directory.rglob('*'):
                if path.is_file():
                    hashes[path.relative_to(ROOT).as_posix()] = {'bytes': path.stat().st_size, 'sha256': sha(path)}
            log = ROOT / 'logs' / (task['id'] + '.log')
            if log.exists():
                hashes[log.relative_to(ROOT).as_posix()] = {'bytes': log.stat().st_size, 'sha256': sha(log)}
            records.append({'id': task['id'], 'output': task['output'], 'status': 'interrupted',
                'exitCodeObserved': False, 'reason': 'Execution environment/session ended without a final result; exact cause and exit code unavailable.',
                'preservedPartialOutput': True})
        else:
            config = load(directory / 'config.json'); summary = load(directory / 'summary.json')
            result = directory / summary['result']['path']
            assert summary['status'] == 'completed' and summary['sourceStable'] is True
            assert summary['revision'] == config['revision']
            assert config['revision']['sourceHash'] == original['sourceFreeze']['sourceHash']
            assert summary['result']['sha256'] == sha(result) and summary['result']['bytes'] == result.stat().st_size
            records.append({'id': task['id'], 'output': task['output'], 'status': 'completed-output-recovered',
                'exitCodeObserved': False, 'basis': 'Checksummed stable-source summary/result and retained log; process exit code unavailable.',
                'resultSha256': sha(result), 'summarySha256': sha(directory / 'summary.json'),
                'log': 'logs/' + task['id'] + '.log'})
    assert len(records) == 26 and sum(record['status'] == 'interrupted' for record in records) == 3
    write(ROOT / 'interruption-preserved-files.json', {'files': hashes, 'capturedAt': datetime.now(timezone.utc).isoformat(),
        'scope': 'Immutable files belonging to the three interrupted original parents, including their logs.'})
    write(ROOT / 'execution-reconstructed.json', {'records': records, 'originalRegistrationSha256': sha(ROOT / 'registration.json'),
        'notYetIncludedOriginalParent': UNSTARTED, 'exactInterruptionCause': None, 'originalExitCodesAvailable': False})
    recovery = ROOT / 'recovery'
    recovery.mkdir()
    for name in ('analyze.py', 'analysis-shared.py', 'run.py', 'freeze.mjs', 'environment.json'):
        shutil.copyfile(ROOT / name, recovery / name)
    tasks = []
    for original_id in INTERRUPTED:
        parent = copy.deepcopy(by_id[original_id])
        old_parent = copy.deepcopy(parent)
        parent['id'] = 'retry1-' + original_id
        parent['output'] = 'online/' + parent['id']
        parent['command'][parent['command'].index('--output') + 1] = str(recovery / parent['output'])
        parent['expectedOptions']['outputDir'] = str(recovery / parent['output'])
        parent['retryOf'] = {'taskId': original_id, 'originalOutput': old_parent['output'],
                             'originalRegistrationSha256': sha(ROOT / 'registration.json')}
        assert {k: v for k, v in parent['expectedOptions'].items() if k != 'outputDir'} == {
            k: v for k, v in old_parent['expectedOptions'].items() if k != 'outputDir'}
        tasks.append(parent)
        child = copy.deepcopy(next(task for task in original['tasks'] if task.get('dependsOn') == original_id))
        child['id'] = 'replay-' + parent['id']
        child['dependsOn'] = parent['id']
        child['output'] = 'replay-online/' + parent['id']
        child['witness'] = parent['output'] + '/witness.json'
        child['command'][child['command'].index('--output') + 1] = str(recovery / child['output'])
        child['command'][child['command'].index('--witness') + 1] = str(recovery / child['witness'])
        child['expectedOptions']['outputDir'] = str(recovery / child['output'])
        child['expectedOptions']['witnessPath'] = str(recovery / child['witness'])
        child['retryOf'] = {'taskId': next(task['id'] for task in original['tasks'] if task.get('dependsOn') == original_id),
                            'originalRegistrationSha256': sha(ROOT / 'registration.json')}
        tasks.append(child)
    reg = copy.deepcopy(original)
    reg['frozenAt'] = datetime.now(timezone.utc).isoformat()
    reg['purpose'] = 'Separate recovery of three externally interrupted development assignments; original partial records remain unchanged.'
    reg['tasks'] = tasks
    reg['plannedCounts'] = {'online': 3, 'replay-online': 3}
    for key in ('sourceManifest', 'sourceSnapshot', 'sourcePatch'):
        reg['sourceFreeze'][key]['path'] = '../' + original['sourceFreeze'][key]['path']
    reg['baselineEvidence']['path'] = '../' + original['baselineEvidence']['path']
    reg['selectionRule'] = 'Retry all three original parents lacking final results after the external interruption, with identical source/options/seeds; no outcome-based selection or replacement of originals.'
    reg['recoveryProvenance'] = {'originalRegistration': {'path': '../registration.json', 'sha256': sha(ROOT / 'registration.json')},
        'preservedPartialManifest': {'path': '../interruption-preserved-files.json', 'sha256': sha(ROOT / 'interruption-preserved-files.json')},
        'preparationScript': {'path': '../prepare-recovery.py', 'sha256': sha(Path(__file__))},
        'sourceCheck': {'path': '../interruption-source-check.json', 'sha256': sha(ROOT / 'interruption-source-check.json')},
        'sourceRuntimeVerifiedAtPreparation': actual, 'parameterChanges': [],
        'copiedFrozenScaffolds': 'Original analyzer/shared/runner/freezer bytes copied unchanged. This separate registration was written by prepare-recovery.py; copied freeze.mjs was not executed.',
        'interpretation': 'Separate retry cohort, not fresh confirmation, not substituted into original54 analysis, no causal claim.'}
    write(recovery / 'registration.json', reg)
    with (recovery / 'registration.sha256').open('x') as file:
        file.write(sha(recovery / 'registration.json') + '  registration.json\n')
    write(ROOT / 'recovery-registration-notice.json', {'recoveryRegistrationSha256': sha(recovery / 'registration.json'),
        'sourceHash': actual['sourceHash'], 'registeredRetries': INTERRUPTED, 'tasks': len(tasks), 'frozenAt': reg['frozenAt']})
    print(json.dumps({'registration': str(recovery / 'registration.json'), 'sha256': sha(recovery / 'registration.json'),
                      'tasks': len(tasks), 'preservedFiles': len(hashes), 'reconstructedParents': len(records)}))


if __name__ == '__main__':
    main()
