#!/usr/bin/env python3
"""Verify and describe the frozen structural/online development campaign; execute no game code."""
import argparse
from collections import Counter, defaultdict
import hashlib
import importlib.util
import json
import math
from pathlib import Path, PurePosixPath
import statistics
import zipfile

ROOT = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('mastery_shared', ROOT / 'analysis-shared.py')
SHARED = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(SHARED)
FINISHES = {'primary-goal', 'manual-showcase-finish', 'showcase-top-out'}
RESULT_NAMES = {'search': 'candidate.json', 'replay': 'replay.json', 'online': 'witness.json', 'replay-online': 'replay.json'}
OPTION_FLAGS = {'--output': 'outputDir', '--wall-ms': 'wallBudgetMs', '--level': 'levelId', '--seed': 'seed',
                '--max-pieces': 'maxPieces', '--beam-width': 'beamWidth', '--max-nodes': 'maxNodes',
                '--nodes-per-plan': 'maxNodesPerPlan', '--unknown-tail-depth': 'unknownTailDepth',
                '--setup-strategy': 'setupStrategy', '--candidate': 'candidatePath', '--mode': 'mode',
                '--reaction-ms': 'reactionMs', '--action-ms': 'actionIntervalMs', '--max-seconds': 'maxSimSeconds',
                '--timing-policy': 'timingPolicy', '--max-decisions': 'maxDecisions',
                '--replans-per-piece': 'maxReplansPerPiece', '--witness': 'witnessPath'}
PROJECTION_KEYS = ['levelId', 'seed', 'initialBoardHash', 'commands', 'trace', 'outcome', 'reason', 'qualityCensored',
                   'primaryReachedAtPiece', 'primaryReached', 'goalReachedAtSeconds', 'stoppedAtSeconds', 'stopPhase',
                   'physicsDrainedThroughSeconds', 'metrics', 'quality']


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


class Inputs:
    def __init__(self, root):
        self.root, self.hashes = root, {}

    def read(self, name):
        data = (self.root / name).read_bytes()
        self.hashes[name] = {'bytes': len(data), 'sha256': sha(data)}
        return data

    def json(self, name):
        return json.loads(self.read(name))

    def reference(self, reference):
        data = self.read(reference['path'])
        require(sha(data) == reference['sha256'], 'Reference checksum differs: ' + reference['path'])
        return data


def verify_source(reg, inputs):
    freeze = reg['sourceFreeze']
    require(reg['executionReady'] is True, 'Registration not frozen')
    require(sha(inputs.read('registration.json')) == inputs.read('registration.sha256').decode().split()[0], 'Registration changed')
    require(sha(Path(__file__).read_bytes()) == freeze['analyzerSha256'], 'Running analyzer changed')
    require(sha(inputs.read('analyze.py')) == freeze['analyzerSha256'], 'Archived analyzer changed')
    require(sha(inputs.read('run.py')) == reg['runnerSha256'], 'Runner changed')
    require(sha(inputs.read('freeze.mjs')) == reg['freezeScriptSha256'], 'Freezer changed')
    require(sha(inputs.read('analysis-shared.py')) == freeze['sharedAnalyzer']['sha256'], 'Shared analyzer changed')
    require(sha((ROOT / 'analysis-shared.py').read_bytes()) == freeze['sharedAnalyzer']['sha256'], 'Running shared analyzer differs')
    manifest = json.loads(inputs.reference(freeze['sourceManifest']))
    inputs.reference(freeze['sourceSnapshot'])
    inputs.reference(freeze['sourcePatch'])
    inputs.reference(reg['environment'])
    inputs.reference(reg['baselineEvidence'])
    digest = hashlib.sha256()
    with zipfile.ZipFile(inputs.root / freeze['sourceSnapshot']['path']) as archive:
        members = [item.filename for item in archive.infolist() if not item.is_dir()]
        require(len(members) == len(set(members)) and set(members) == set(manifest), 'ZIP/manifest paths differ')
        for name in sorted(members, key=lambda value: value.encode('utf-16-be', errors='surrogatepass')):
            path = PurePosixPath(name)
            require(not path.is_absolute() and '..' not in path.parts, 'Unsafe source archive path')
            data = archive.read(name)
            require(manifest[name] == {'bytes': len(data), 'sha256': sha(data)}, 'Source bytes differ: ' + name)
            digest.update((name + '\0').encode()); digest.update(data)
    require(digest.hexdigest() == freeze['sourceHash'], 'Full-path/NUL/source digest differs')
    return manifest, {'verified': True, 'files': len(manifest), 'commit': freeze['commit'],
                      'sourceHash': digest.hexdigest(), 'runtime': freeze['runtime']}


def check_options(task, options):
    require(options == task['expectedOptions'], 'Config options differ from frozen expected options')
    argv = task['command']
    require(len(argv) >= 3 and Path(argv[1]).name == 'odyssey-mastery.mjs' and argv[2] == task['stage'], 'Command stage/tool differs')
    require(options['command'] == task['stage'], 'Options command differs')
    tokens = argv[3:]
    require(len(tokens) % 2 == 0, 'Registration commands require explicit flag/value pairs')
    seen = set()
    for flag, value in zip(tokens[::2], tokens[1::2]):
        require(flag in OPTION_FLAGS and flag not in seen, 'Unknown/duplicate command flag: ' + flag)
        seen.add(flag)
        require(str(options[OPTION_FLAGS[flag]]) == value, 'Option differs from command: ' + flag)
    parts = PurePosixPath(task['output']).parts
    require(parts and '..' not in parts and not PurePosixPath(task['output']).is_absolute(), 'Unsafe task output')
    output = Path(options['outputDir'])
    require(output.parts[-len(parts):] == parts, 'Output path differs from task')
    original_root = output.parents[len(parts) - 1]
    for field, option in [('candidate', 'candidatePath'), ('witness', 'witnessPath')]:
        if field in task:
            require(Path(options[option]) == original_root / task[field], 'Input path differs from task')
    for field in ('levelId', 'seed'):
        if field in options:
            require(options[field] == task[field], 'Task identity differs from options')


def distribution(values):
    values = [value for value in values if isinstance(value, (int, float))]
    if not values:
        return {'count': 0, 'sum': 0, 'median': None, 'p90NearestRank': None, 'maximum': None}
    ordered = sorted(values)
    return {'count': len(values), 'sum': sum(values), 'median': statistics.median(values),
            'p90NearestRank': ordered[math.ceil(.9 * len(values)) - 1], 'maximum': max(values)}


def online_trace_checks(result):
    config = result.get('config', {})
    trace = result.get('trace', [])
    commands = result.get('commands', [])
    completed = [entry for entry in trace if entry.get('completed')]
    errors = []
    previous_hash = result.get('initialBoardHash')
    for entry in trace:
        if previous_hash is not None and entry.get('boardHashBefore') != previous_hash:
            errors.append({'step': entry.get('step'), 'kind': 'board-continuity'})
        previous_hash = entry.get('boardHashAfter')
        if len(entry.get('preview', [])) != 3:
            errors.append({'step': entry.get('step'), 'kind': 'preview-count'})
        for action in entry.get('actions', []):
            if action['atMs'] + 1e-7 < entry['spawnAtMs'] + config.get('reactionMs', 0):
                errors.append({'step': entry.get('step'), 'kind': 'reaction-gate'})
        if entry.get('completed'):
            piece = entry.get('lockedPiece', {})
            if sum(bool(cell) for row in piece.get('shape', []) for cell in row) != 4:
                errors.append({'step': entry.get('step'), 'kind': 'non-tetromino'})
            cell = entry.get('cellConservation', {})
            if not cell.get('valid') or cell.get('overlap') or cell.get('expected') != cell.get('actual'):
                errors.append({'step': entry.get('step'), 'kind': 'conservation'})
    if [action for entry in trace for action in entry.get('actions', [])] != commands:
        errors.append({'kind': 'command-trace-projection'})
    for before, after in zip(commands, commands[1:]):
        if after['atMs'] <= before['atMs'] or after['atMs'] - before['atMs'] + 1e-7 < config.get('actionIntervalMs', 0):
            errors.append({'kind': 'action-cadence'})
    if any(command['atMs'] > result.get('stoppedAtSeconds', float('inf')) * 1000 + 1e-7 for command in commands):
        errors.append({'kind': 'command-after-terminal'})
    metrics = result.get('metrics')
    if metrics:
        observed = {'piecesPlaced': len(completed), 'lines': sum(sum(entry['lineClears']) for entry in completed),
                    'cascades': sum(len(entry['lineClears']) >= 2 for entry in completed),
                    'tetrises': sum(value == 4 for entry in completed for value in entry['lineClears'])}
        for key, value in observed.items():
            if metrics.get(key) != value:
                errors.append({'kind': 'trace-metric', 'metric': key, 'computed': value, 'reported': metrics.get(key)})
    return {'validRecordedEvidence': not errors, 'errors': errors, 'spawnedEntries': len(trace),
            'completedLocks': len(completed), 'unlockedEntries': sum(not entry.get('lockedPiece') for entry in trace),
            'lockedIncompleteEntries': sum(bool(entry.get('lockedPiece')) and not entry.get('completed') for entry in trace),
            'rejectedInputs': sum(not command.get('accepted') and not command.get('legalStop') for command in commands),
            'groundedStops': sum(bool(command.get('legalStop')) for command in commands),
            'automaticLocks': sum(entry.get('lockSource') == 'automatic' for entry in trace),
            'interpretation': 'Rejected commands and automatic locks are recorded online events, not automatically invalid traces. Production timestamp replay validates execution.'}


def describe_online(result, expected=None):
    evidence = online_trace_checks(result)
    quality = result.get('quality', {})
    metrics = result.get('metrics', {})
    conditions = result.get('requirements', {}).get('stars', {}).get('three', {}).get('conditions', {})
    bonuses = sum(item.get('conditionMet') is True for item in quality.get('optionalBonuses', []))
    independent = SHARED.independently_met(conditions, metrics, bonuses)
    censored = bool(result.get('qualityCensored') or quality.get('censored'))
    valid = result.get('traceValid') is True and evidence['validRecordedEvidence']
    fixed_mastery = bool(valid and result.get('outcome') == 'win' and result.get('reason') in FINISHES
                         and not censored and result.get('primaryReached') is True
                         and quality.get('masteryConditionsMet') is True and independent['conditionsMet'])
    decisions = result.get('decisions', [])
    compute = {'decisions': len(decisions), 'nodes': result.get('nodes'), 'plannerWallMs': result.get('plannerWallMs'),
               'plannerCpuMs': result.get('plannerCpuMs'),
               'decisionWallMs': distribution([item.get('plannerWallMs') for item in decisions]),
               'decisionCpuMs': distribution([item.get('plannerCpuMs') for item in decisions]),
               'decisionNodes': distribution([item.get('nodes') for item in decisions]),
               'chargedToSimulation': result.get('plannerWallTimeChargedToSimulation'),
               'reportedRealTimePlanningFeasibility': result.get('realtimePlanningFeasibility'),
               'realTimePlanningQualified': False}
    compute['nodeAccountingAgrees'] = sum(item.get('nodes', 0) for item in decisions) == result.get('nodes', 0)
    compute['wallAccountingAgrees'] = math.isclose(sum(item.get('plannerWallMs', 0) for item in decisions),
                                                 result.get('plannerWallMs', 0), rel_tol=1e-9, abs_tol=1e-6)
    compute['cpuAccountingAgrees'] = math.isclose(sum(item.get('plannerCpuMs', 0) for item in decisions),
                                                result.get('plannerCpuMs', 0), rel_tol=1e-9, abs_tol=1e-6)
    replay_checks = None
    if expected is not None:
        projection_matches = {key: result.get(key) for key in PROJECTION_KEYS} == {key: expected.get(key) for key in PROJECTION_KEYS}
        hash_matches = (isinstance(result.get('expectedExecutionHash'), str)
                        and len(result['expectedExecutionHash']) == 64
                        and result['expectedExecutionHash'] == result.get('actualExecutionHash'))
        replay_checks = {'reportedReplayValid': result.get('replayValid') is True,
                         'reportedTraceComplete': result.get('traceComplete') is True,
                         'independentProjectionMatches': projection_matches,
                         'executionHashMatches': hash_matches,
                         'qualifiedTimestampReplay': bool(valid and projection_matches and hash_matches and result.get('replayValid') is True
                             and result.get('traceComplete') is True and result.get('status') == 'pass')}
        fixed_mastery &= replay_checks['qualifiedTimestampReplay']
    return {'resultStatus': result.get('status', 'returned'), 'outcome': result.get('outcome'), 'reason': result.get('reason'),
            'recordedTraceValid': valid, 'traceEvidence': evidence, 'primaryReached': result.get('primaryReached') is True,
            'primaryReachedAtPiece': result.get('primaryReachedAtPiece'), 'goalReachedAtSeconds': result.get('goalReachedAtSeconds'),
            'primaryCensored': result.get('outcome') == 'censored' and not result.get('primaryReached'),
            'qualityCensored': censored, 'tierThreeConditionsMet': quality.get('tierThreeConditionsMet') is True,
            'independentTierThree': independent, 'optionalBonuses': quality.get('optionalBonuses'),
            'timedStars': quality.get('timedStars'), 'fixedCadenceFullMasteryObserved': fixed_mastery,
            'realTimePlanningQualified': False, 'humanValidated': False, 'compute': compute,
            'metrics': metrics, 'maximumDepth': result.get('maximumDepth'), 'counters': result.get('counters'),
            'budgetReached': result.get('reason') in {'piece-budget', 'node-budget', 'decision-budget', 'wall-budget', 'simulation-budget'},
            'config': result.get('config'), 'wallMs': result.get('wallMs'), 'failure': result.get('failure'),
            'timestampReplay': replay_checks}


def analyze_task(task, reg, manifest, inputs, execution, raw_results):
    record = {key: task.get(key) for key in ('id', 'stage', 'output', 'levelId', 'seed', 'cadence', 'dependsOn', 'baselineTaskId', 'witnessScope')}
    record.update({'status': 'missing', 'provenanceVerified': False, 'execution': execution.get(task['id'])})
    folder = task['output']
    try:
        check_options(task, task['expectedOptions'])
        if not (inputs.root / folder).exists():
            run = record['execution'] or {}
            if run.get('status') == 'not executed':
                record['status'] = 'not-executed'
            elif run.get('status') == 'runner error' or run.get('exitCode', 0) != 0:
                record['status'] = 'error'
            return record
        if not (inputs.root / folder / 'config.json').exists():
            record['status'] = 'missing-config'; return record
        config = inputs.json(folder + '/config.json')
        check_options(task, config['options'])
        require(config.get('schemaVersion') == 1, 'Unknown config schema')
        for field, expected in [('head', reg['sourceFreeze']['commit']), ('sourceHash', reg['sourceFreeze']['sourceHash']),
                                ('runtime', reg['sourceFreeze']['runtime'])]:
            require(config['revision'].get(field) == expected, 'Invocation source/runtime differs: ' + field)
        require(inputs.json(folder + '/source-manifest.json') == manifest, 'Invocation manifest differs')
        inputs.read(folder + '/source.patch')
        parent = None
        for field in ('candidate', 'witness'):
            name = field + 'Sha256'
            if field in task:
                data = inputs.read(task[field])
                require(config.get(name) == sha(data), 'Input hash differs: ' + field)
                require(inputs.read(folder + '/input-' + field + '.json') == data, 'Copied input differs: ' + field)
                parent = json.loads(data)
            else:
                require(config.get(name) is None, 'Unexpected input hash: ' + name)
        record['provenanceVerified'] = True
        if (inputs.root / folder / 'failure.json').exists():
            record['failure'] = inputs.json(folder + '/failure.json')
        if not (inputs.root / folder / 'summary.json').exists():
            record['status'] = 'error' if record.get('failure') else 'incomplete'
            if (inputs.root / folder / RESULT_NAMES[task['stage']]).exists():
                inputs.read(folder + '/' + RESULT_NAMES[task['stage']]); record['unqualifiedResultRetained'] = True
            return record
        summary = inputs.json(folder + '/summary.json')
        require(not record.get('failure'), 'Success summary and failure record both present')
        require(summary['status'] == 'completed' and summary['sourceStable'] is True, 'Source unstable or tool incomplete')
        require(summary['command'] == task['stage'] and summary['revision'] == config['revision'], 'Summary differs from config')
        for field in ('candidateSha256', 'witnessSha256'):
            require(summary.get(field) == config.get(field), 'Summary input hash differs')
        filename = RESULT_NAMES[task['stage']]
        data = inputs.read(folder + '/' + filename)
        require(summary['result'] == {'path': filename, 'bytes': len(data), 'sha256': sha(data)}, 'Result bytes/hash differ')
        result = json.loads(data)
        require(result.get('schemaVersion') == 1, 'Unknown result schema')
        require(result.get('levelId') == task['levelId'] and result.get('seed') == task['seed'], 'Result identity differs')
        options = config['options']
        stage = task['stage']
        require(result.get('kind') == {'search': 'targeted-mastery-search', 'replay': 'mastery-candidate-replay',
                                      'online': 'online-mastery-witness', 'replay-online': 'online-mastery-replay'}[stage], 'Unexpected result kind')
        if stage == 'search':
            expected_budgets = {key: options[key] for key in ('maxPieces', 'beamWidth', 'maxNodes', 'maxNodesPerPlan', 'wallBudgetMs', 'unknownTailDepth')}
            # Setup strategy may be recorded outside budgets; all common budget fields must match.
            require(all(result.get('budgets', {}).get(key) == value for key, value in expected_budgets.items()), 'Search budgets differ')
            require(result.get('budgets', {}).get('setupStrategy') == options['setupStrategy'], 'Search setup strategy differs')
            require(result.get('previewLimit') == 3 and result.get('timed') is False, 'Search observation/timing differs')
            observation = SHARED.describe_search(result)
            observation['setupStrategy'] = options['setupStrategy']
            objectives = [entry.get('planning', {}).get('geometryObjective') for entry in result.get('trace', [])]
            objectives = [entry for entry in objectives if entry]
            observation['setupDiagnostics'] = {'recordedObjectives': len(objectives),
                'phases': dict(Counter(entry.get('phase') for entry in objectives)),
                'lastObjective': objectives[-1] if objectives else None,
                'scope': 'Soft preferences and necessary bounds only; actual metrics and replay qualify construction.'}
        elif stage == 'replay':
            require(result.get('mode') == options['mode'] and result.get('timed') is False, 'Untimed replay mode differs')
            observation = SHARED.describe_replay(result, parent)
        else:
            expected_config = {key: value for key, value in options.items() if key not in ('command', 'outputDir')}
            if stage == 'replay-online':
                expected_config = parent['config']
            require(result.get('config') == expected_config, 'Online result configuration differs')
            require(result.get('plannerWallTimeChargedToSimulation') is False
                    and result.get('realtimePlanningFeasibility') == 'unverified', 'Unexpected compute qualification')
            observation = describe_online(result, parent if stage == 'replay-online' else None)
        raw_results[task['id']] = result
        record.update({'status': 'result-error' if result.get('status') == 'error' or result.get('error') else 'completed',
                       'resultSha256': sha(data), 'elapsedWallMs': summary.get('elapsedWallMs'), 'observation': observation})
        run = record.get('execution') or {}
        if run.get('status') in ('runner error', 'not executed') or run.get('exitCode', 0) != 0:
            record['status'] = 'execution-contradiction'
            record['qualificationSuppressed'] = 'Completed output conflicts with runner status; raw observation retained.'
            for key in ('qualifiedUntimedSearchCandidate', 'qualifiedUntimedReplayMastery',
                        'qualifiedTimedFullWitness', 'fixedCadenceFullMasteryObserved'):
                if key in observation:
                    observation[key] = False
            if observation.get('timestampReplay'):
                observation['timestampReplay']['qualifiedTimestampReplay'] = False
        return record
    except (ValueError, KeyError, TypeError, OSError, IndexError) as error:
        record.update({'status': 'verification-error', 'provenanceVerified': False, 'verificationError': str(error)})
        record.pop('observation', None)
        return record


def baseline_comparison(record, current, baseline):
    old = {item['id']: item for item in baseline['tasks']}
    key = record.get('baselineTaskId') if record['stage'] == 'online' else f"orb-{record['levelId']}-seed-{record['seed']}"
    if key not in old:
        return None
    prior = old[key]
    prefix, divergence = 0, None
    for index, (left, right) in enumerate(zip(prior['trace'], current.get('trace', [])), 1):
        if not left.get('completed') or not right.get('completed'):
            break
        if left.get('boardHashAfter') != right.get('boardHashAfter') or left.get('shapeKey') != right.get('shapeKey'):
            divergence = index; break
        prefix += 1
    metrics = current.get('metrics', {})
    return {'baselineTaskId': key, 'baselineSourceHash': baseline['sourceHash'], 'crossSourceDescriptiveOnly': True,
            'exactPrefixRescueMeasured': False, 'matchingCompletedBoardPrefixPieces': prefix,
            'firstComparedBoardDivergencePiece': divergence,
            'baselineMetrics': prior['metrics'], 'currentMetrics': metrics,
            'baselineReason': prior.get('reason', prior.get('termination')), 'baselineFailure': prior.get('failure'),
            'baselinePrimaryReached': prior['primaryReached'],
            'currentPrimaryReached': current.get('primaryReached', current.get('quality', {}).get('primaryReachedUntimed', False)),
            'passedBaselineReportedPieceCount': metrics.get('piecesPlaced', 0) > prior.get('piecesReplayed', 0),
            'limits': 'Source clock/spin/history handling and decisions can differ. Passing a piece count or changing a failure label is not exact-target rescue or a causal effect estimate.'}


def analyze(root):
    inputs = Inputs(root.resolve())
    reg = inputs.json('registration.json')
    manifest, source = verify_source(reg, inputs)
    baseline = inputs.json(reg['baselineEvidence']['path'])
    tasks = reg['tasks']
    require(len(tasks) == len({task['id'] for task in tasks}) == len({task['output'] for task in tasks}), 'Duplicate task IDs/output paths')
    require(dict(Counter(task['stage'] for task in tasks)) == reg['plannedCounts'], 'Task counts differ from registration')
    task_by_id = {task['id']: task for task in tasks}
    child_counts = Counter()
    for task in tasks:
        if task['stage'] not in ('replay', 'replay-online'):
            require(not task.get('dependsOn'), 'Parent task unexpectedly has a dependency')
            continue
        require(task.get('dependsOn') in task_by_id, 'Replay parent is not registered')
        parent_task = task_by_id[task['dependsOn']]
        expected_stage = 'search' if task['stage'] == 'replay' else 'online'
        field = 'candidate' if task['stage'] == 'replay' else 'witness'
        require(parent_task['stage'] == expected_stage, 'Replay parent stage differs')
        require(all(task.get(key) == parent_task.get(key) for key in ('levelId', 'seed', 'cadence')), 'Replay/parent identity differs')
        require(task[field] == parent_task['output'] + '/' + RESULT_NAMES[expected_stage], 'Replay input is not its declared parent output')
        child_counts[parent_task['id']] += 1
    require(all(child_counts[task['id']] == 1 for task in tasks if task['stage'] in ('search', 'online')),
            'Each registered search/online parent requires exactly one independent replay')
    execution = {}
    for name in ('execution-parents.json', 'execution-replays.json', 'execution.json'):
        if (inputs.root / name).exists():
            values = inputs.json(name)
            require(len(values) == len({entry['id'] for entry in values}), 'Duplicate execution IDs')
            require(set(entry['id'] for entry in values) <= set(task['id'] for task in tasks), 'Unknown execution task')
            execution.update({entry['id']: entry for entry in values})
    raw_results = {}
    records = [analyze_task(task, reg, manifest, inputs, execution, raw_results) for task in tasks]
    by_id = {record['id']: record for record in records}
    children = {task['dependsOn']: task['id'] for task in tasks if task.get('dependsOn')}
    for record in records:
        if record['stage'] in ('search', 'online') and record.get('observation'):
            record['baselineComparison'] = baseline_comparison(record, raw_results[record['id']], baseline)
            child = by_id.get(children.get(record['id']), {})
            if record['stage'] == 'online':
                replay = child.get('observation', {}).get('timestampReplay') or {}
                record['observation']['independentTimestampReplayQualified'] = bool(
                    record['status'] == 'completed' and child.get('status') == 'completed'
                    and replay.get('qualifiedTimestampReplay', False))
                record['observation']['independentlyReplayedFixedCadenceMastery'] = bool(
                    record['observation']['fixedCadenceFullMasteryObserved']
                    and record['observation']['independentTimestampReplayQualified'])
            else:
                record['observation']['independentUntimedReplayQualified'] = bool(
                    record['status'] == 'completed' and child.get('status') == 'completed'
                    and child.get('provenanceVerified') and child.get('observation', {}).get('replayValidWithEvidenceChecks')
                    and child.get('observation', {}).get('traceComplete'))
    groups = defaultdict(list)
    for record in records:
        groups[f"{record['stage']}/orb-{record['levelId']}" + (f"/{record['cadence']}" if record.get('cadence') else '')].append(record)
    aggregates = {}
    for key, members in sorted(groups.items()):
        observations = [record['observation'] for record in members if record.get('provenanceVerified') and record.get('observation')]
        depths = [item.get('maximumDepth') for item in observations if isinstance(item.get('maximumDepth'), (int, float))]
        aggregates[key] = {'planned': len(members), 'statuses': dict(Counter(item['status'] for item in members)),
                           'observed': len(observations), 'maximumObservedDepth': max(depths, default=None),
                           'outcomes': dict(Counter(item['outcome'] for item in observations if item.get('outcome'))),
                           'reasons': dict(Counter(item.get('reason') or item.get('termination') for item in observations)),
                           'primaryReached': sum(item.get('primaryReached', item.get('primaryReachedUntimed', False)) for item in observations),
                           'primaryCensored': sum(item.get('primaryCensored', False) for item in observations),
                           'qualityCensored': sum(item.get('qualityCensored', False) for item in observations),
                           'budgetReached': sum(item.get('budgetReached', False) for item in observations),
                           'qualifiedUntimedSearchCandidates': sum(item.get('qualifiedUntimedSearchCandidate', False) for item in observations),
                           'qualifiedUntimedReplayMastery': sum(item.get('qualifiedUntimedReplayMastery', False) for item in observations),
                           'fixedCadenceFullMasteryObserved': sum(item.get('fixedCadenceFullMasteryObserved', False) for item in observations),
                           'independentlyReplayedFixedCadenceMastery': sum(item.get('independentlyReplayedFixedCadenceMastery', False) for item in observations),
                           'timestampReplaysQualified': sum(bool((item.get('timestampReplay') or {}).get('qualifiedTimestampReplay')) for item in observations),
                           'realTimePlanningQualified': 0}
    return {'schemaVersion': 1, 'kind': 'Independent structural/online development artifact analysis',
            'sourceVerification': source, 'plannedTasks': len(tasks), 'plannedStages': reg['plannedCounts'],
            'taskStatuses': dict(Counter(record['status'] for record in records)), 'groups': aggregates, 'tasks': records,
            'allPlannedInvocationsCompleted': all(record['status'] == 'completed' for record in records),
            'limits': ['Seeds 9101–9103 are development only; 11001+ remains reserved.',
                       'Fixed-cadence planning computation is measured but uncharged; no real-time planning or human qualification.',
                       'Tool completion, valid trace, primary acquisition, live finish, quality and optional bonuses are distinct.',
                       'Automatic locks and recoverable rejected inputs are online events; the old fixed-script invalidation labels are not an equivalent success metric.',
                       'Baseline comparisons are cross-source descriptive; clock/spin/history changes and policy trajectories may differ.',
                       'No exact-prefix rescue task is registered; trajectory comparisons cannot establish rescue of an old specific tuck.',
                       'Python verifies provenance and recorded arithmetic; Node production replay supplies execution evidence.',
                       'Planner preview/seed isolation depends on source and focused tests, not this artifact analyzer.',
                       'The earlier solver forwarded an unused seed option to its planner. The new allowlist hardens this boundary; no hidden-queue/RNG use or retrospective result invalidity was established.'],
            'inputHashes': dict(sorted(inputs.hashes.items()))}


def self_test():
    import copy
    import shutil
    import tempfile
    import unittest

    class Tests(unittest.TestCase):
        def online(self):
            return {'traceValid': True, 'config': {'reactionMs': 150, 'actionIntervalMs': 100},
                    'trace': [], 'commands': [], 'decisions': [], 'nodes': 0, 'plannerWallMs': 0, 'plannerCpuMs': 0,
                    'metrics': {'piecesPlaced': 0, 'lines': 0, 'cascades': 0, 'tetrises': 0, 'score': 500000},
                    'requirements': {'stars': {'three': {'conditions': {'score': 500000}}}},
                    'quality': {'masteryConditionsMet': True, 'tierThreeConditionsMet': True, 'censored': False},
                    'outcome': 'win', 'reason': 'manual-showcase-finish', 'qualityCensored': False,
                    'primaryReached': True, 'plannerWallTimeChargedToSimulation': False,
                    'realtimePlanningFeasibility': 'unverified'}

        def test_compute_never_qualified(self):
            observation = describe_online(self.online())
            self.assertTrue(observation['fixedCadenceFullMasteryObserved'])
            self.assertFalse(observation['realTimePlanningQualified'])

        def test_censored_raw_quality_does_not_qualify(self):
            result = self.online(); result['qualityCensored'] = True
            self.assertFalse(describe_online(result)['fixedCadenceFullMasteryObserved'])
            result = self.online(); result['reason'] = 'wall-budget'
            self.assertFalse(describe_online(result)['fixedCadenceFullMasteryObserved'])

        def test_replay_mismatch_does_not_qualify(self):
            expected = self.online(); actual = copy.deepcopy(expected)
            actual.update({'status': 'pass', 'replayValid': True, 'traceComplete': True,
                           'expectedExecutionHash': '0' * 64, 'actualExecutionHash': '0' * 64})
            self.assertTrue(describe_online(actual, expected)['timestampReplay']['qualifiedTimestampReplay'])
            actual['metrics']['score'] += 1
            self.assertFalse(describe_online(actual, expected)['timestampReplay']['qualifiedTimestampReplay'])

        def test_replay_primary_and_terminal_phase_must_match(self):
            expected = self.online()
            expected.update({'levelId': 49, 'seed': 9101, 'stopPhase': 'input'})
            for key, value in [('primaryReached', False), ('stopPhase', 'logic'), ('levelId', 55), ('seed', 9102)]:
                actual = copy.deepcopy(expected)
                actual.update({'status': 'pass', 'replayValid': True, 'traceComplete': True,
                               'expectedExecutionHash': '0' * 64, 'actualExecutionHash': '0' * 64})
                actual[key] = value
                self.assertFalse(describe_online(actual, expected)['timestampReplay']['qualifiedTimestampReplay'], key)

        def test_automatic_lock_is_not_automatically_invalid(self):
            result = self.online()
            result['trace'] = [{'step': 1, 'preview': ['I', 'O', 'T'], 'spawnAtMs': 0, 'completed': True,
                'actions': [], 'lineClears': [], 'lockSource': 'automatic',
                'lockedPiece': {'shape': [[1, 1, 1, 1]]}, 'cellConservation': {'expected': 4, 'actual': 4, 'valid': True}}]
            result['metrics']['piecesPlaced'] = 1
            self.assertTrue(online_trace_checks(result)['validRecordedEvidence'])

        def test_cadence_gate(self):
            result = self.online()
            action = {'atMs': 100, 'accepted': True}
            result['trace'] = [{'step': 1, 'preview': ['I', 'O', 'T'], 'spawnAtMs': 0, 'actions': [action]}]
            result['commands'] = [action]
            self.assertFalse(online_trace_checks(result)['validRecordedEvidence'])

        def test_frozen_round_portability_and_tampering(self):
            with tempfile.TemporaryDirectory() as temporary:
                root = Path(temporary) / 'original'
                root.mkdir()
                for name in ('analyze.py', 'analysis-shared.py', 'run.py', 'freeze.mjs'):
                    (root / name).write_bytes((ROOT / name).read_bytes())
                def write(name, value):
                    path = root / name
                    path.parent.mkdir(parents=True, exist_ok=True)
                    path.write_text(json.dumps(value) + '\n')
                def ref(name):
                    return {'path': name, 'sha256': sha((root / name).read_bytes())}
                sources = {'src/a.js': b'fixture source', 'src/\U00010000.js': b'UTF16 before E000', 'src/\ue000.js': b'last'}
                manifest = {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sources.items()}
                source_hash = hashlib.sha256()
                with zipfile.ZipFile(root / 'source-snapshot.zip', 'w') as archive:
                    for name in sorted(sources, key=lambda value: value.encode('utf-16-be')):
                        archive.writestr(name, sources[name]); source_hash.update((name + '\0').encode()); source_hash.update(sources[name])
                write('source-manifest.json', manifest)
                (root / 'source.patch').write_text('')
                write('environment.json', {'fixture': True})
                write('baseline-evidence.json', {'sourceHash': 'earlier', 'tasks': []})
                online_options = {'command': 'online', 'outputDir': '/frozen/artifacts/campaign/online/one',
                    'levelId': 49, 'seed': 9101, 'reactionMs': 150, 'actionIntervalMs': 100,
                    'wallBudgetMs': 240000, 'setupStrategy': 'none', 'timingPolicy': 'fixed-cadence'}
                online_task = {'id': 'one', 'stage': 'online', 'levelId': 49, 'seed': 9101, 'output': 'online/one',
                    'expectedOptions': online_options, 'command': ['node', 'scripts/odyssey-mastery.mjs', 'online',
                        '--level', '49', '--seed', '9101', '--reaction-ms', '150', '--action-ms', '100',
                        '--wall-ms', '240000', '--setup-strategy', 'none', '--timing-policy', 'fixed-cadence',
                        '--output', online_options['outputDir']]}
                replay_options = {'command': 'replay-online', 'outputDir': '/frozen/artifacts/campaign/replay/one',
                                  'witnessPath': '/frozen/artifacts/campaign/online/one/witness.json', 'wallBudgetMs': 120000}
                replay_task = {'id': 'replay-one', 'stage': 'replay-online', 'levelId': 49, 'seed': 9101,
                    'output': 'replay/one', 'witness': 'online/one/witness.json', 'dependsOn': 'one',
                    'expectedOptions': replay_options, 'command': ['node', 'scripts/odyssey-mastery.mjs', 'replay-online',
                        '--witness', replay_options['witnessPath'], '--wall-ms', '120000', '--output', replay_options['outputDir']]}
                runtime = {'node': 'fixture', 'platform': 'linux', 'arch': 'x64'}
                reg = {'executionReady': True, 'runnerSha256': ref('run.py')['sha256'],
                    'freezeScriptSha256': ref('freeze.mjs')['sha256'], 'environment': ref('environment.json'),
                    'baselineEvidence': ref('baseline-evidence.json'), 'plannedCounts': {'online': 1, 'replay-online': 1},
                    'sourceFreeze': {'commit': 'fixture', 'sourceHash': source_hash.hexdigest(), 'runtime': runtime,
                        'analyzerSha256': ref('analyze.py')['sha256'], 'sharedAnalyzer': ref('analysis-shared.py'),
                        'sourceManifest': ref('source-manifest.json'), 'sourceSnapshot': ref('source-snapshot.zip'),
                        'sourcePatch': ref('source.patch')}, 'tasks': [online_task, replay_task]}
                write('registration.json', reg)
                (root / 'registration.sha256').write_text(sha((root / 'registration.json').read_bytes()) + '\n')
                witness = self.online()
                witness.update({'schemaVersion': 1, 'kind': 'online-mastery-witness', 'levelId': 49, 'seed': 9101,
                    'config': {key: value for key, value in online_options.items() if key not in ('command', 'outputDir')},
                    'primaryReached': False, 'outcome': 'censored', 'reason': 'piece-budget', 'stoppedAtSeconds': 1,
                    'quality': {'masteryConditionsMet': False, 'tierThreeConditionsMet': False, 'censored': False}})
                witness['metrics']['score'] = 0
                write('online/one/witness.json', witness)
                replay = copy.deepcopy(witness)
                replay.update({'kind': 'online-mastery-replay', 'status': 'pass', 'replayValid': True, 'traceComplete': True,
                               'expectedExecutionHash': '0' * 64, 'actualExecutionHash': '0' * 64})
                write('replay/one/replay.json', replay)
                witness_bytes = (root / 'online/one/witness.json').read_bytes()
                (root / 'replay/one/input-witness.json').write_bytes(witness_bytes)
                revision = {'head': 'fixture', 'sourceHash': source_hash.hexdigest(), 'runtime': runtime}
                for task in [online_task, replay_task]:
                    folder = task['output']
                    config = {'schemaVersion': 1, 'options': task['expectedOptions'], 'revision': revision,
                              'candidateSha256': None, 'witnessSha256': sha(witness_bytes) if task['stage'] == 'replay-online' else None}
                    write(folder + '/config.json', config); write(folder + '/source-manifest.json', manifest)
                    (root / folder / 'source.patch').write_text('')
                    filename = RESULT_NAMES[task['stage']]
                    data = (root / folder / filename).read_bytes()
                    write(folder + '/summary.json', {'status': 'completed', 'sourceStable': True, 'command': task['stage'],
                        'revision': revision, 'candidateSha256': None, 'witnessSha256': config['witnessSha256'],
                        'result': {'path': filename, 'bytes': len(data), 'sha256': sha(data)}})
                first = analyze(root)
                self.assertEqual(first['taskStatuses'], {'completed': 2})
                self.assertTrue(first['tasks'][0]['observation']['independentTimestampReplayQualified'])
                self.assertFalse(first['tasks'][0]['observation']['realTimePlanningQualified'])
                original_registration = (root / 'registration.json').read_bytes()
                original_checksum = (root / 'registration.sha256').read_bytes()
                for field, value in [('dependsOn', 'unknown'), ('seed', 9102), ('witness', 'online/other/witness.json')]:
                    changed = copy.deepcopy(reg)
                    changed['tasks'][1][field] = value
                    write('registration.json', changed)
                    (root / 'registration.sha256').write_text(sha((root / 'registration.json').read_bytes()) + '\n')
                    with self.assertRaises(ValueError, msg=field):
                        analyze(root)
                (root / 'registration.json').write_bytes(original_registration)
                (root / 'registration.sha256').write_bytes(original_checksum)
                moved = Path(temporary) / 'relocated'
                shutil.copytree(root, moved)
                self.assertEqual(first, analyze(moved))
                (root / 'execution.json').write_text(json.dumps([{'id': 'one', 'exitCode': 1}]))
                contradicted = analyze(root)
                self.assertEqual(contradicted['tasks'][0]['status'], 'execution-contradiction')
                self.assertIn('observation', contradicted['tasks'][0])
                self.assertFalse(contradicted['tasks'][0]['observation']['independentTimestampReplayQualified'])
                (root / 'execution.json').unlink()
                (moved / 'replay/one/replay.json').write_text('{}\n')
                broken = analyze(moved)
                self.assertEqual(broken['taskStatuses'], {'completed': 1, 'verification-error': 1})
                self.assertFalse(broken['tasks'][0]['observation']['independentTimestampReplayQualified'])
                (root / 'analysis-shared.py').write_text('changed')
                with self.assertRaisesRegex(ValueError, 'Shared analyzer changed'):
                    analyze(root)

    outcome = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
    return outcome.wasSuccessful()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        raise SystemExit(0 if self_test() else 1)
    result = analyze(args.root)
    output = args.output or args.root / 'analysis.json'
    output.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'plannedTasks': result['plannedTasks'], 'taskStatuses': result['taskStatuses'], 'groups': result['groups']}, indent=2))


if __name__ == '__main__':
    main()
