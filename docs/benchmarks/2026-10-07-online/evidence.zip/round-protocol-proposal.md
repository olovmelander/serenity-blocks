# Proposed round registration and reusable analysis

`round-protocol-proposal.json` is deliberately **not execution-ready**. It proposes a small first stage: one steady-cadence online run on development seed 9101 for each of orbs 49, 55 and 59, plus separately labeled prepared-geometry diagnostics. Root owns the final source freeze, tool options, exact commands and resource limits. No new cohort outcomes informed this proposal. All inputs for the retrospective findings are in `failure-audit/`.

The first online mode may pause virtual gameplay during bounded planning, as long as the records explicitly say that computation is uncharged and real-time planning remains unqualified. Measure each planner call's wall and process-CPU time; record total nodes, per-call nodes, retries and abandoned plans. A per-call cap alone does not bound infinite replanning, so require total-node and decision-count limits too. The suggested budgets in the JSON are placeholders for root to accept or change before execution; they are not validated difficulty settings.

If the first stage supplies sound traces and useful adaptation, freeze an expansion to all 18 orb/seed/cadence development pairs. Record the expansion decision and the results that informed it. Preserve every earlier version; a changed policy starts a new round. For exact local recovery, reconstruct the 13 selected failure prefixes and classify original-target recovery separately from survival through a different legal placement. Full online runs can diverge long before the old failure: they should be compared by actual progress and terminal outcomes, not labeled as recovering the old tuck.

## Reusable freezer contract

Before any new round task starts, the freezer should write and checksum:

- The exact commit, Node/runtime/hardware/worker context, all executed commands, task identities and input references.
- A complete `{path: {bytes, sha256}}` source manifest and snapshot. Compute the source digest in the same full-path UTF-16 ordering as the CLI: relative path, NUL, then bytes. Verify snapshot members and digests independently before running.
- Registration, analyzer and runner hashes, followed by an immutable registration checksum. Retain prior baseline source/results and the selected input hashes.
- Exact task semantics: authored-start versus prepared board versus prefix recovery; whether gravity, lock delay, deadlines and reaction/action intervals run; whether planner latency is charged; all budgets and finish rules.

Each invocation should retain pre-outcome `config.json`, source manifest, source patch, input copies and checksums, progress or trace logs, final result, and a stable-source summary containing exact result bytes/hash. Retain failure records and partial traces. A successful process exit or `summary.status=completed` is tool completion, not goal completion.

Do not derive a new hash by mixing old and current source silently. If only benchmark code changes, still create a new source freeze and state whether production rules/physics are identical to the archived baseline. Archive extraction must not change analysis: compare original absolute config paths to the registered commands, and resolve artifact reads through the current extraction root.

## Analyzer contract

Use a standard-library analyzer independent of Node execution. It should verify all source snapshot members, the full combined digest, registration/analyzer/runner hashes, every invocation's exact options/revision, result bytes and inputs before qualifying any outcome. Keep one row for every planned task, including skipped, missing, incomplete, failed, invalid and capped tasks. Preserve a map of every consumed input hash.

For each result, report independent dimensions:

| Dimension | Required evidence and interpretation |
| --- | --- |
| Tool/provenance | Source stable, intended options, expected inputs, result checksum; separate from gameplay success. |
| Trace integrity | Real four-cell locks, cell conservation, no overlap/injection, command/pose continuity, actual board hashes. Python checks recorded arithmetic; production replay exercises legality. |
| Online execution | Current-piece identity and observed pose at decision/action time; accepted/rejected/stale commands; gravity locks; replans and fallbacks. An ordinary gravity lock need not invalidate an online run. |
| Primary | Actual production acquisition and timestamp; distinguish real loss from resource/policy censor. |
| Finish and quality | Authored ordinary finish or actual manual/showcase top-out; post-primary censor; exact three-star conjunction; optional bonuses separately. |
| Compute | Planning wall/CPU distribution, nodes, decisions, abandoned work, overruns; declared charged/uncharged model. Uncharged results never receive real-time-planning qualification. |
| Comparison | Orb/seed/cadence pair, baseline scope, first trajectory divergence, exact-prefix/target match when claimed. Different paths compare outcomes, not identical placements. |
| Geometry | Prepared-board witness, legal assembly from actual start, production replay and timed qualification are successive distinct milestones. |

A full fixed-cadence mastery witness requires valid conserved production execution, actual primary victory, an allowed live finish (`primary-goal`, `manual-showcase-finish`, or `showcase-top-out`), uncensored quality, and all exact three-star conditions. **Real-time planning** is an additional qualification requiring an implemented and validated charged-latency policy; matching previews or a favorable median compute time cannot supply it. Keep trace completion separate: a valid authored terminal event may legitimately end before a longer candidate's remaining commands.

For paired tables, report raw statuses, changes in primary/quality metrics, reached piece counts and censor reasons for all 18 keys. Do not compute a human win rate, treat the prior 13 interrupted scripts as player losses, pool prepared boards with authored attempts, or exclude new failures because the old policy never reached that point. These are three previously used development seeds, not fresh confirmation.

## Suggested analyzer fixtures before freeze

Verify that the analyzer rejects changed source/result/input bytes and mismatched options; reproduces identical JSON after moving the extracted archive; refuses mastery for raw quality on an interrupted or quality-censored trace; retains primary wins with incomplete quality separately; refuses real-time-planning qualification when compute is uncharged; distinguishes an exact-target prefix recovery from an alternate legal placement; accepts a valid ordinary gravity lock under online semantics; and retains missing/skipped tasks in the planned denominator. These fixtures need no expensive search or new seed outcomes.
