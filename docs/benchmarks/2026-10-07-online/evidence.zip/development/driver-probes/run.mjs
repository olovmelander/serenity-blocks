import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { runOnlineMastery, replayOnlineMastery } from '../../../../scripts/odyssey-benchmark/mastery-online.mjs';
const output = dirname(fileURLToPath(import.meta.url));
const root = resolve(output, '../../../..');
mkdirSync(output, { recursive: true });
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex');
const sources = ['mastery-online.mjs', 'mastery-replay.mjs', 'mastery-search.mjs'];
const manifest = {
  kind: 'online-driver-development-fixtures',
  createdAt: new Date().toISOString(),
  head: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim(),
  sources: Object.fromEntries(sources.map((name) => [name, hash(readFileSync(resolve(root, 'scripts/odyssey-benchmark', name)))])),
  scope: 'Seed9101 injected controller fixtures only. These are driver checks, not registered mastery outcomes or candidate selection.',
  provenance: 'Full traces retained by repeating the four tiny development conditions after focused tests. The earlier stdout-only probes had the same execution counts; original CPU timing was not retained.',
  originalStdoutOnly: {
    threeDrops: { commands: 3, spawnedTraceEntries: 4, stopSeconds: 0.4500000000000002, replay: 'pass' },
    gravityIntervals: [600, 1000, 1500].map((interval) => ({ interval, gravityReplans: 8, decisions: 10, rejectedInputs: 0, automaticLocks: 0 })),
  },
  runs: [],
};
const specs = [
  { id: 'three-drops', options: { maxPieces: 3 }, planner: () => ({ actions: [{ type: 'hardDrop' }], diagnostics: { nodes: 1 } }) },
  ...[600, 1000, 1500].map((interval) => ({
    id: `gravity-${interval}`, options: { maxPieces: 2, actionIntervalMs: interval },
    planner: (observation) => ({ actions: observation.currentPiece.x > 0 ? [{ type: 'move', dir: -1 }, { type: 'hardDrop' }] : [{ type: 'hardDrop' }], diagnostics: { nodes: 1 } }),
  })),
];
for (const spec of specs) {
  const witness = await runOnlineMastery({ levelId: 55, seed: 9101, ...spec.options }, { planner: spec.planner });
  const replay = await replayOnlineMastery(witness);
  const witnessBytes = JSON.stringify(witness, null, 2) + '\n';
  const replayBytes = JSON.stringify(replay, null, 2) + '\n';
  writeFileSync(resolve(output, `${spec.id}.witness.json`), witnessBytes);
  writeFileSync(resolve(output, `${spec.id}.replay.json`), replayBytes);
  manifest.runs.push({ id: spec.id, config: witness.config, commands: witness.commands.length, counters: witness.counters, replayStatus: replay.status, witnessSha256: hash(witnessBytes), replaySha256: hash(replayBytes) });
}
writeFileSync(resolve(output, 'manifest.json'), JSON.stringify(manifest, null, 2) + '\n');
console.log(JSON.stringify(manifest.runs.map(({ id, replayStatus, commands, counters }) => ({ id, replayStatus, commands, counters }))));
