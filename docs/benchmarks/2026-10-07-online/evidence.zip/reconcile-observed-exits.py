#!/usr/bin/env python3
"""Use preserved outer-runner exit observations; keep the conservative first journal."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
sha = lambda data: hashlib.sha256(data).hexdigest()
original = json.loads((root / 'execution-reconstructed.json').read_text())
expected_ids = {record['id'] for record in original['records'] if record['status'] == 'completed-output-recovered'}
raw = (root / 'run.log').read_bytes()
observations = {}
for number, line in enumerate(raw.decode().splitlines(), 1):
    try:
        record = json.loads(line)
    except ValueError:
        continue
    if isinstance(record, dict) and record.get('id') in expected_ids and 'exitCode' in record:
        assert record['id'] not in observations
        observations[record['id']] = {'record': record, 'line': number, 'lineSha256': sha(line.encode())}
assert set(observations) == expected_ids and len(observations) == 23
assert all(value['record']['exitCode'] == 0 for value in observations.values())
assert (root / 'execution.json').exists(), 'Wait for the coordinator to finish'
for name in ['execution-parents.json', 'execution-replays.json', 'execution.json']:
    path = root / name
    before = path.read_bytes()
    backup = root / (path.stem + '-before-exit-reconciliation.json')
    with backup.open('xb') as file:
        file.write(before)
    records = json.loads(before)
    for record in records:
        if record['id'] in observations:
            observation = observations[record['id']]
            assert record['output'] == observation['record']['output']
            record['exitCode'] = observation['record']['exitCode']
            record['exitCodeObserved'] = True
            record['exitObservation'] = {'path': 'run.log', 'line': observation['line'], 'lineSha256': observation['lineSha256']}
            record['basis'] = 'Preserved outer runner JSON explicitly recorded exitCode 0; stable-source result/summary checked independently.'
    path.write_text(json.dumps(records, indent=2, sort_keys=True) + '\n')
result = {'runLogSha256': sha(raw), 'recoveredExplicitExitObservations': observations,
          'initialConservativeJournalPreserved': 'execution-reconstructed.json',
          'interruptedExitCodesRemainUnknown': True,
          'explanation': 'The first reconstruction consumed task logs/summaries but not the outer run.log. Its23 unknown exit-code fields are now reconciled from explicit preserved runner observations.'}
with (root / 'exit-observation-reconciliation.json').open('x') as file:
    file.write(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps({'recoveredObservedExits': len(observations), 'interruptedExitCodesStillUnknown': 3}))
