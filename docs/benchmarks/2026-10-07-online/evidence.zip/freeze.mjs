/** Manual source freeze only. Does not launch any campaign task. */
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { captureSourceRevision, parseOptions } from '../../scripts/odyssey-mastery.mjs';

const root = dirname(fileURLToPath(import.meta.url));
const repositoryRoot = resolve(root, '../..');
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const read = (path) => JSON.parse(readFileSync(path, 'utf8'));
const write = (name, value) => writeFileSync(resolve(root, name), `${JSON.stringify(value, null, 2)}\n`, { flag: 'wx' });
const artifactRef = (name) => ({ path: name, sha256: sha(readFileSync(resolve(root, name))) });
if (process.argv.includes('--help')) {
    process.stdout.write('Manual freeze: node artifacts/odyssey-online-mastery-2026-10-07/freeze.mjs --source-ready\n');
    process.exit(0);
}
if (!process.argv.includes('--source-ready')) throw new Error('Wait for source-owner confirmation, then pass --source-ready');
if (existsSync(resolve(root, 'registration.json'))) throw new Error('Registration already exists; never overwrite a frozen round');
execFileSync('git', ['diff', '--quiet', 'HEAD', '--', 'src', 'scripts', 'tests', 'package.json', 'package-lock.json'], { cwd: repositoryRoot });
const untracked = execFileSync('git', ['ls-files', '--others', '--exclude-standard', '--', 'src', 'scripts', 'tests'],
    { cwd: repositoryRoot, encoding: 'utf8' }).trim();
if (untracked) throw new Error(`Commit source/tests before freezing: ${untracked}`);
for (const name of ['analyze.py', 'analysis-shared.py', 'run.py', 'environment.json']) {
    if (!existsSync(resolve(root, name))) throw new Error(`Missing freeze input: ${name}`);
}
const tasks = [];
const searchFlags = ['--max-pieces', '192', '--beam-width', '8', '--max-nodes', '240000',
    '--nodes-per-plan', '2400', '--unknown-tail-depth', '1'];
const onlineFlags = ['--max-pieces', '192', '--beam-width', '8', '--max-nodes', '720000',
    '--nodes-per-plan', '1200', '--unknown-tail-depth', '1'];
for (const seed of [9101, 9102, 9103]) {
    for (const levelId of [49, 55, 59]) {
        const key = `orb-${levelId}-seed-${seed}`;
        const id = `structural-${key}`;
        const output = `search/${id}`;
        tasks.push({ id, stage: 'search', levelId, seed, witnessScope: 'authored-start-untimed', output,
            command: ['node', 'scripts/odyssey-mastery.mjs', 'search', '--level', String(levelId), '--seed', String(seed),
                ...searchFlags, '--setup-strategy', 'structural-v1', '--wall-ms', '240000', '--output', resolve(root, output)] });
        const replayOutput = `replay/untimed-${id}`;
        const candidate = `${output}/candidate.json`;
        tasks.push({ id: `untimed-${id}`, stage: 'replay', levelId, seed, candidate, dependsOn: id,
            witnessScope: 'independent-untimed-replay', output: replayOutput,
            command: ['node', 'scripts/odyssey-mastery.mjs', 'replay', '--candidate', resolve(root, candidate),
                '--mode', 'untimed', '--reaction-ms', '150', '--action-ms', '100', '--max-seconds', '1800',
                '--wall-ms', '120000', '--output', resolve(root, replayOutput)] });
        for (const [cadence, reactionMs, actionIntervalMs] of [['steady', 150, 100], ['deliberate', 300, 180]]) {
            const onlineId = `online-${cadence}-${key}`;
            const onlineOutput = `online/${onlineId}`;
            const baselineTaskId = `timed-${cadence}-${key}`;
            tasks.push({ id: onlineId, stage: 'online', levelId, seed, cadence, baselineTaskId,
                witnessScope: 'authored-start-online-trajectory', output: onlineOutput,
                command: ['node', 'scripts/odyssey-mastery.mjs', 'online', '--level', String(levelId), '--seed', String(seed),
                    ...onlineFlags, '--setup-strategy', 'none', '--timing-policy', 'fixed-cadence',
                    '--max-decisions', '2048', '--replans-per-piece', '64', '--reaction-ms', String(reactionMs),
                    '--action-ms', String(actionIntervalMs), '--max-seconds', '1800', '--wall-ms', '240000',
                    '--output', resolve(root, onlineOutput)] });
            const timestampOutput = `replay-online/${onlineId}`;
            const witness = `${onlineOutput}/witness.json`;
            tasks.push({ id: `replay-${onlineId}`, stage: 'replay-online', levelId, seed, cadence, baselineTaskId,
                witness, dependsOn: onlineId, witnessScope: 'independent-timestamp-replay', output: timestampOutput,
                command: ['node', 'scripts/odyssey-mastery.mjs', 'replay-online', '--witness', resolve(root, witness),
                    '--wall-ms', '120000', '--output', resolve(root, timestampOutput)] });
        }
    }
}
for (const task of tasks) task.expectedOptions = parseOptions(task.command.slice(2));
if (tasks.length !== 54) throw new Error('Expected exactly 54 tasks');

// Preserve a small, checksummed projection of the already-published baseline for
// portable descriptive comparisons. Original raw input hashes remain attached.
const baselineRoot = resolve(root, '../odyssey-targeted-mastery-2026-10-07');
const baselineRegistration = read(resolve(baselineRoot, 'registration.json'));
if (sha(readFileSync(resolve(baselineRoot, 'registration.json')))
    !== readFileSync(resolve(baselineRoot, 'registration.sha256'), 'utf8').trim().split(/\s+/)[0]) {
    throw new Error('Baseline registration checksum differs');
}
const baselineHashes = {};
const baselineRead = (name) => {
    const bytes = readFileSync(resolve(baselineRoot, name));
    baselineHashes[name] = sha(bytes);
    return JSON.parse(bytes.toString('utf8'));
};
const baselineTasks = [];
for (const task of baselineRegistration.tasks) {
    if (task.stage !== 'search' && !task.id.startsWith('timed-')) continue;
    const config = baselineRead(`${task.output}/config.json`);
    const summary = baselineRead(`${task.output}/summary.json`);
    const filename = task.stage === 'search' ? 'candidate.json' : 'replay.json';
    const bytes = readFileSync(resolve(baselineRoot, task.output, filename));
    baselineHashes[`${task.output}/${filename}`] = sha(bytes);
    if (summary.result.sha256 !== sha(bytes) || summary.result.bytes !== bytes.length || summary.sourceStable !== true
        || JSON.stringify(summary.revision) !== JSON.stringify(config.revision)
        || config.revision.head !== baselineRegistration.sourceFreeze.commit
        || config.revision.sourceHash !== baselineRegistration.sourceFreeze.sourceHash) throw new Error('Baseline provenance mismatch');
    const result = JSON.parse(bytes.toString('utf8'));
    baselineTasks.push({ id: task.id, stage: task.stage, levelId: result.levelId, seed: result.seed,
        mode: result.mode || null, cadence: result.cadence || null, metrics: result.metrics,
        termination: result.termination || null, outcome: result.outcome || null, reason: result.reason || null,
        primaryReached: result.primaryReached ?? result.quality?.primaryReachedUntimed ?? false,
        replayValid: result.replayValid ?? null, traceValid: result.traceValid ?? null,
        traceComplete: result.traceComplete ?? null, piecesReplayed: result.piecesReplayed ?? result.piecesPlaced,
        failure: result.failure || null, quality: result.quality,
        trace: result.trace.map((entry) => ({ step: entry.step, shapeKey: entry.shapeKey,
            boardHashBefore: entry.boardHashBefore, boardHashAfter: entry.boardHashAfter || null,
            completed: entry.completed, metricsAfter: entry.metricsAfter || null,
            lockedPiece: entry.lockedPiece ? Object.fromEntries(['x', 'y', 'rotation', 'shapeKey'].map((key) => [key, entry.lockedPiece[key]])) : null })) });
}
write('baseline-evidence.json', { kind: 'Pre-outcome projection of prior development evidence',
    registrationSha256: sha(readFileSync(resolve(baselineRoot, 'registration.json'))),
    sourceCommit: baselineRegistration.sourceFreeze.commit, sourceHash: baselineRegistration.sourceFreeze.sourceHash,
    inputHashes: baselineHashes, tasks: baselineTasks,
    limits: 'Cross-source descriptive comparison only. New planner clock/spin/history handling may change outcomes. '
        + 'The prior planner received an unused seed option; new option allowlists harden that boundary without establishing prior hidden-queue/RNG use. '
        + 'No exact-prefix recovery experiment is registered.' });

const source = captureSourceRevision();
write('source-manifest.json', source.files);
writeFileSync(resolve(root, 'source.patch'), source.patch, { flag: 'wx' });
const independentDigest = execFileSync('python3', ['-c', `
import hashlib,json,pathlib,sys,zipfile
root,repo=map(pathlib.Path,sys.argv[1:])
manifest=json.loads((root/'source-manifest.json').read_text())
digest=hashlib.sha256()
with zipfile.ZipFile(root/'source-snapshot.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name in sorted(manifest,key=lambda value:value.encode('utf-16-be')):
        data=(repo/name).read_bytes()
        assert manifest[name]=={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
        digest.update((name+'\\0').encode());digest.update(data)
        info=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
        archive.writestr(info,data,compresslevel=9)
print(digest.hexdigest())
`, root, repositoryRoot], { encoding: 'utf8' }).trim();
if (independentDigest !== source.revision.sourceHash) throw new Error('Python source digest differs from the CLI');
const registration = {
    schemaVersion: 1, executionReady: true, frozenAt: new Date().toISOString(), repositoryRoot,
    purpose: 'Bounded structural construction and fixed-cadence online development; no human calibration or confirmation.',
    sourceFreeze: { commit: source.revision.head, sourceHash: source.revision.sourceHash, runtime: source.revision.runtime,
        sourceManifest: artifactRef('source-manifest.json'), sourceSnapshot: artifactRef('source-snapshot.zip'),
        sourcePatch: artifactRef('source.patch'), analyzerSha256: sha(readFileSync(resolve(root, 'analyze.py'))),
        sharedAnalyzer: artifactRef('analysis-shared.py') },
    runnerSha256: sha(readFileSync(resolve(root, 'run.py'))), freezeScriptSha256: sha(readFileSync(fileURLToPath(import.meta.url))),
    environment: artifactRef('environment.json'), baselineEvidence: artifactRef('baseline-evidence.json'),
    workers: 3, developmentSeeds: [9101, 9102, 9103], reservedConfirmationSeedsStart: 11001,
    plannedCounts: { search: 9, replay: 9, online: 18, 'replay-online': 18 },
    timingPolicy: { mode: 'fixed-cadence', plannerWallTimeChargedToSimulation: false,
        realTimePlanningQualified: false, clockDuringPlanning: 'paused',
        interpretation: 'Gravity/input execution at declared cadence; online real-time compute feasibility is unverified.' },
    selectionRule: 'Execute all 54 registered tasks; retain missing/failed parents and explicitly skip only replays lacking a usable input artifact. No replacement seeds.',
    comparisons: 'All pairs are descriptive, cross-source and previously used development seeds; no win-rate inference, exact-prefix rescue claim or authored retune gate.',
    scopes: { structural: 'Authored-start untimed construction with structural-v1 setup preference.',
        online: 'Authored-start adaptive execution with setup none, separate from structural preference.',
        replay: 'Independent untimed replay of every nonempty structural trace.',
        timestampReplay: 'Independent replay of each retained online witness.' },
    tasks,
};
write('registration.json', registration);
writeFileSync(resolve(root, 'registration.sha256'), `${sha(readFileSync(resolve(root, 'registration.json')))}  registration.json\n`, { flag: 'wx' });
process.stdout.write(`${JSON.stringify({ commit: source.revision.head, sourceHash: source.revision.sourceHash, tasks: tasks.length })}\n`);
