#!/usr/bin/env python3
"""Independent raw-trace audit. Does not import the campaign analyzer or run a planner.

Run only after the registered campaign completes. The only production code executed
is authored-board initialization from the verified frozen source snapshot. Score and
geometry are cross-checked against the separately executed replays, not re-simulated
by this auditor. This does not establish human or real-time planning feasibility.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import subprocess
import tempfile
import zipfile

FILENAMES = {'search': 'candidate.json', 'replay': 'replay.json',
             'online': 'witness.json', 'replay-online': 'replay.json'}
COUNTER_KEYS = ('piecesPlaced', 'lines', 'singles', 'doubles', 'triples', 'tetrises',
                'cascades', 'combos', 'maxCombo', 'maxCascadeDepth')
PROJECTION_KEYS = ('levelId', 'seed', 'initialBoardHash', 'commands', 'trace', 'outcome',
                   'reason', 'qualityCensored', 'primaryReachedAtPiece', 'primaryReached',
                   'goalReachedAtSeconds', 'stoppedAtSeconds', 'stopPhase',
                   'physicsDrainedThroughSeconds', 'metrics', 'quality')
BUDGET_REASONS = {'piece-budget', 'simulation-budget', 'wall-budget', 'node-budget', 'decision-budget'}
PIECES = {'I', 'J', 'L', 'O', 'S', 'T', 'Z'}
EPSILON = 1e-6
EXPECTED_COUNTS = {
    'original': {'search': 9, 'replay': 9, 'online': 18, 'replay-online': 18},
    'recovery': {'online': 3, 'replay-online': 3},
}


def substantive_options(options):
    """Only output/input paths may change for an explicitly linked retry."""
    return {key: value for key, value in options.items() if key not in ('outputDir', 'witnessPath')}


def progress_projection(value):
    """Remove execution-resource observations, preserving every simulation field."""
    if isinstance(value, dict):
        return {key: progress_projection(item) for key, item in value.items()
                if key not in ('elapsedWallMs', 'plannerWallMs', 'plannerCpuMicros', 'wallMs',
                               'totalWallMs', 'cpuUserMicros', 'cpuSystemMicros')}
    if isinstance(value, list):
        return [progress_projection(item) for item in value]
    return value


def digest(data):
    return hashlib.sha256(data).hexdigest()


def pose(piece):
    return {key: piece.get(key, 0 if key == 'rotation' else None)
            for key in ('shapeKey', 'x', 'y', 'rotation')} if piece else None


def command_valid(command):
    kind = command.get('type')
    return kind in ('softDrop', 'hardDrop') or (kind == 'move' and command.get('dir') in (-1, 1)) \
        or (kind == 'rotate' and command.get('dir') in ('left', 'right', 'flip'))


def bonus_met(bonus, metrics, top_out=False):
    key = bonus['type']
    aliases = {'max-cascade-depth': 'maxCascadeDepth', 'tetris-count': 'tetrises',
               'cascade': 'cascades', 'combo': 'maxCombo'}
    if key in aliases:
        return metrics.get(aliases[key], 0) >= bonus['target']
    if key == 'no-singles':
        return metrics.get('singles', 0) == 0
    if key == 'no-top-out':
        return not top_out and metrics.get('deaths', 0) == 0
    if key in ('pieces', 'time'):
        return (metrics.get('piecesPlaced' if key == 'pieces' else 'time') or 0) <= bonus['target']
    raise ValueError('Unknown bonus: ' + key)


def tier_met(conditions, metrics, bonuses, timed):
    for key, target in conditions.items():
        if key == 'time' and not timed:
            continue
        metric = {'combo': 'maxCombo', 'maxDeaths': 'deaths'}.get(key, key)
        actual = sum(bonuses) if key == 'bonuses' else (metrics.get(metric) or 0)
        if key in ('time', 'maxDeaths'):
            if actual > target:
                return False
        elif actual < target:
            return False
    return True


def calculate_score(lines, level, ordinal, perfect):
    base = {1: 250, 2: 500, 3: 1000, 4: 2000}.get(lines, 200 * lines * lines)
    subtotal = base + 200 * max(0, ordinal - 1) ** 2
    if perfect:
        subtotal += lines * 1250 if lines <= 4 else lines * lines * 500
    return subtotal + math.floor(subtotal * 0.1 * level)


def qualify(result, stage, primary, tier_three):
    """Raw metric predicates are separate from a complete, independently replayed win."""
    if stage == 'search':
        return bool(result.get('traceValid') and result.get('quality', {}).get('qualified')
                    and primary and tier_three)
    return bool(result.get('replayValid') and result.get('traceComplete')
                and result.get('outcome') == 'win' and not result.get('qualityCensored')
                and not result.get('quality', {}).get('censored') and primary and tier_three)


class Audit:
    def __init__(self, root, repository, cohort='original'):
        self.root = root
        self.repository = repository
        self.errors = []
        self.input_hashes = {}
        self.lock_checks = 0
        self.command_checks = 0
        self.results = []
        self.initial = {}
        self.cohort = cohort
        self.raw_results = {}

    def check(self, condition, scope, message):
        if not condition:
            self.errors.append({'scope': scope, 'message': message})
        return bool(condition)

    def read_bytes(self, relative):
        path = self.root / relative
        data = path.read_bytes()
        self.input_hashes[str(relative)] = digest(data)
        return data

    def read(self, relative):
        return json.loads(self.read_bytes(relative))

    def freeze(self, registration):
        scope = 'registration/source'
        self.check(digest(self.read_bytes('registration.json')) ==
                   self.read_bytes('registration.sha256').decode().split()[0], scope, 'Registration digest mismatch')
        freeze = registration['sourceFreeze']
        for descriptor in (freeze['sourceManifest'], freeze['sourceSnapshot'], freeze['sourcePatch'],
                           registration['environment'], registration['baselineEvidence']):
            self.check(digest(self.read_bytes(descriptor['path'])) == descriptor['sha256'],
                       scope, 'Frozen artifact mismatch: ' + descriptor['path'])
        # No analyzer implementation is imported or consulted to interpret results.
        self.check(digest(self.read_bytes('analyze.py')) == freeze['analyzerSha256'], scope, 'Analyzer changed after freeze')
        shared = freeze['sharedAnalyzer']
        self.check(digest(self.read_bytes(shared['path'])) == shared['sha256'], scope, 'Shared analyzer changed')
        self.check(digest(self.read_bytes('run.py')) == registration['runnerSha256'], scope, 'Runner changed')
        self.manifest = self.read(freeze['sourceManifest']['path'])
        source_digest = hashlib.sha256()
        with zipfile.ZipFile(self.root / freeze['sourceSnapshot']['path']) as archive:
            self.check(set(archive.namelist()) == set(self.manifest), scope, 'Snapshot file set differs from manifest')
            for name in sorted(self.manifest, key=lambda value: value.encode('utf-16-be')):
                data = archive.read(name)
                self.check(self.manifest[name] == {'bytes': len(data), 'sha256': digest(data)}, scope,
                           'Snapshot source bytes mismatch: ' + name)
                source_digest.update((name + '\0').encode())
                source_digest.update(data)
            self.check(source_digest.hexdigest() == freeze['sourceHash'], scope, 'Combined source fingerprint mismatch')
            # Initialize only the authored boards using verified source, even if today's checkout differs.
            with tempfile.TemporaryDirectory(prefix='odyssey-independent-initial-') as directory:
                temporary = Path(directory)
                for name in self.manifest:
                    if Path(name).is_absolute() or '..' in Path(name).parts:
                        raise ValueError('Unsafe frozen source member: ' + name)
                    destination = temporary / name
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    destination.write_bytes(archive.read(name))
                modules = self.repository / 'node_modules'
                if modules.exists():
                    (temporary / 'node_modules').symlink_to(modules, target_is_directory=True)
                init_js = r'''
import { createHash } from 'node:crypto';
import { GameplayHybridEngine } from './src/core/odyssey/GameplayHybridEngine.js';
import { getLevelById } from './src/core/odyssey/data/levels.js';
const results=[];
for (const levelId of [49,55,59]) for (const seed of [9101,9102,9103]) {
 const level=getLevelById(levelId); const engine=new GameplayHybridEngine(); engine.configure(level);
 const state=engine.createGameState({rngSeed:seed}); const labels=new Map();
 const key=state.boardGrid.map((row,y)=>row.map((cell,x)=>{
  if(!cell)return '.';const id=cell.id??`cell:${x}:${y}`;
  if(!labels.has(id))labels.set(id,labels.size);return labels.get(id);
 }).join(',')).join('|');
 results.push({levelId,seed,cells:state.boardGrid.flat().filter(Boolean).length,
  columns:state.boardGrid[0].length,rows:state.boardGrid.length,
  hash:createHash('sha256').update(key).digest('hex'),
  stars:level.stars,victory:level.victory,victoryLapPolicy:level.victoryLapPolicy||'none',
  scoring:{level:state.level,linesUntilNextLevel:state.linesUntilNextLevel,
   disableLevelProgression:!!state.disableLevelProgression,comboMultiplierEnabled:!!state.comboMultiplierEnabled,
   comboMultiplier:state.comboMultiplier||1,comboCount:state.comboCount||0}});
 state.reset();engine.reset();
}
console.log('AUDIT_INITIAL_BOARDS='+JSON.stringify(results));
'''
                output = subprocess.run(['node', '--input-type=module', '-e', init_js], cwd=temporary,
                                        text=True, capture_output=True, check=True).stdout
                line = next(line for line in output.splitlines() if line.startswith('AUDIT_INITIAL_BOARDS='))
                for item in json.loads(line.split('=', 1)[1]):
                    self.initial[(item['levelId'], item['seed'])] = item

    def metrics(self, result, task, initial):
        scope = task['id']
        counts = {key: 0 for key in COUNTER_KEYS}
        previous_hash = initial['hash']
        previous_score = 0
        scoring = dict(initial['scoring'])
        timed = task['stage'] in ('online', 'replay-online')
        completed = 0
        all_actions = []
        for index, entry in enumerate(result.get('trace', []), 1):
            entry_scope = f'{scope}/piece-{index}'
            self.check(entry['step'] == index, entry_scope, 'Piece index discontinuity')
            self.check(len(entry.get('preview', [])) == 3 and set(entry['preview']) <= PIECES,
                       entry_scope, 'Preview scope is not exactly three legal pieces')
            self.check(entry.get('shapeKey') in PIECES, entry_scope, 'Invalid tetromino name')
            self.check(entry.get('boardHashBefore') == previous_hash, entry_scope, 'Board hash continuity mismatch')
            for command in entry.get('actions', []):
                self.command_checks += 1
                self.check(command_valid(command), entry_scope, 'Invalid command vocabulary')
                if task['stage'] in ('search', 'replay'):
                    self.check(command.get('accepted') or command.get('legalStop'), entry_scope, 'Rejected construction input')
                all_actions.append(command)
            if not entry.get('lockedPiece'):
                self.check(not entry.get('completed'), entry_scope, 'Completed piece has no lock')
                continue
            piece = entry['lockedPiece']
            cells = sum(bool(cell) for row in piece['shape'] for cell in row)
            self.check(cells == 4, entry_scope, 'Recorded lock is not a four-cell tetromino')
            if not entry.get('completed'):
                continue
            completed += 1
            counts['piecesPlaced'] += 1
            waves = entry.get('lineClears', [])
            counts['lines'] += sum(waves)
            for width, key in ((1, 'singles'), (2, 'doubles'), (3, 'triples'), (4, 'tetrises')):
                counts[key] += waves.count(width)
            if len(waves) >= 2:
                counts['cascades'] += 1
                counts['combos'] += len(waves) - 1
                counts['maxCombo'] = max(counts['maxCombo'], len(waves))
                counts['maxCascadeDepth'] = max(counts['maxCascadeDepth'], len(waves))
            observed = entry['metricsAfter']
            for key, value in counts.items():
                self.check(observed.get(key) == value, entry_scope, 'Cumulative metric mismatch: ' + key)
            self.check(observed['score'] >= previous_score, entry_scope, 'Score decreased')
            score_before = previous_score
            previous_score = observed['score']
            conservation = entry['cellConservation']
            expected = initial['cells'] + 4 * observed['piecesPlaced'] - initial['columns'] * observed['lines']
            self.check(conservation['expected'] == expected, entry_scope, 'Cell equation differs from authored inventory')
            self.check(conservation['actual'] == expected, entry_scope, 'Actual cell count violates conservation')
            if 'visible' in conservation:
                self.check(conservation['actual'] == conservation['visible'] + conservation['offBoard'],
                           entry_scope, 'Visible plus off-board cell count mismatch')
                self.check(conservation['valid'] and not conservation['overlap'], entry_scope, 'Replay reports overlap/invalid cells')
            line_score = 0
            multiplier = scoring['comboMultiplier'] if scoring['comboMultiplierEnabled'] else 1
            for ordinal, width in enumerate(waves, 1):
                self.check(isinstance(width, int) and width > 0, entry_scope, 'Invalid line-clear width')
                scoring['linesUntilNextLevel'] -= width
                if scoring['linesUntilNextLevel'] <= 0:
                    if not scoring['disableLevelProgression']:
                        scoring['level'] += 1
                    scoring['linesUntilNextLevel'] += 15
                raw_points = calculate_score(width, scoring['level'], ordinal, False)
                line_score += math.floor(raw_points * multiplier + 0.5)
            if waves and conservation['actual'] == 0:
                depth = sum(waves)
                bonus = calculate_score(depth, scoring['level'], len(waves), True) \
                    - calculate_score(depth, scoring['level'], len(waves), False)
                line_score += math.floor(bonus * multiplier + 0.5)
            inferred_lock_bonus = observed['score'] - score_before - line_score
            self.check((0 <= inferred_lock_bonus <= 50) if timed else inferred_lock_bonus == 50,
                       entry_scope, 'Score differs from independent clear/perfect-clear model and allowed lock bonus')
            if scoring['comboMultiplierEnabled']:
                scoring['comboCount'] = scoring['comboCount'] + 1 if waves else 0
                scoring['comboMultiplier'] = 1 + scoring['comboCount'] * 0.5
            self.lock_checks += 1
            previous_hash = entry['boardHashAfter']
        final = result.get('metrics')
        if final:
            for key, value in counts.items():
                self.check(final.get(key) == value, scope, 'Final metric differs from recorded completed locks: ' + key)
            self.check(final['score'] == previous_score, scope, 'Final score differs from last fully resolved lock')
        if task['stage'] in ('online', 'replay-online') and result.get('traceValid'):
            self.check(all_actions == result['commands'], scope, 'Flat timestamp log differs from per-piece input log')
            previous_time = -1.0
            entries = {entry['step']: entry for entry in result['trace']}
            cadence = result['config']
            for event in result['commands']:
                self.check(event['atMs'] > previous_time, scope, 'Command timestamps are not strictly increasing')
                if previous_time >= 0:
                    self.check(event['atMs'] - previous_time + EPSILON >= cadence['actionIntervalMs'],
                               scope, 'Input cadence violated')
                previous_time = event['atMs']
                entry = entries[event['step']]
                self.check(event['atMs'] + EPSILON >= entry['spawnAtMs'] + cadence['reactionMs'],
                           scope, 'Spawn reaction delay violated')
                self.check(event['atMs'] <= result['stoppedAtSeconds'] * 1000 + EPSILON,
                           scope, 'Command occurs after the recorded stop')
                if entry.get('lockAtMs') is not None:
                    self.check(event['atMs'] <= entry['lockAtMs'] + EPSILON, scope, 'Command occurs after its piece locked')
            counters = result['counters']
            self.check(counters['automaticLocks'] == sum(entry.get('lockSource') == 'automatic'
                       for entry in result['trace']), scope, 'Automatic-lock count mismatch')
            self.check(counters['rejectedInputs'] == sum(not event['accepted'] and not event['legalStop']
                       for event in result['commands']), scope, 'Rejected-input count mismatch')
            self.check(counters['groundedStops'] == sum(bool(event['legalStop']) for event in result['commands']),
                       scope, 'Grounded-stop count mismatch')
            self.check(result['plannerWallTimeChargedToSimulation'] is False
                       and result['realtimePlanningFeasibility'] == 'unverified', scope, 'Timing qualification was overstated')
        return completed

    def quality(self, result, task, initial):
        scope = task['id']
        metrics = result.get('metrics')
        if not metrics:
            return {'qualifiedMastery': False, 'unavailable': True}
        stage = task['stage']
        timed = stage in ('online', 'replay-online')
        top_out = bool(result.get('topOut')) or result.get('reason') in ('top-out', 'showcase-top-out')
        bonuses = [bonus_met(bonus, metrics, top_out) if timed or bonus['type'] != 'time' else False
                   for bonus in initial['victory'].get('bonuses', [])]
        tiers = {tier: tier_met(initial['stars'][tier], metrics, bonuses, timed)
                 for tier in ('one', 'two', 'three')}
        quality = result['quality']
        requirements = result.get('requirements', {})
        for tier in ('one', 'two', 'three'):
            self.check(requirements.get('stars', {}).get(tier, {}).get('conditions') == initial['stars'][tier],
                       scope, 'Reported star requirements differ from frozen authored conditions: ' + tier)
        primary_definition = requirements.get('primary', {})
        self.check(all(primary_definition.get(key) == value for key, value in initial['victory']['primary'].items()),
                   scope, 'Reported primary requirements differ from frozen authored conditions')
        primary = bool(quality.get('primaryReachedUntimed')) if stage == 'search' else bool(result['primaryReached'])
        reached_piece = result.get('primaryReachedAtPiece')
        self.check(primary == (reached_piece is not None), scope, 'Primary flag and acquisition piece disagree')
        if primary:
            matching = [entry for entry in result['trace'] if entry.get('completed')
                        and entry['metricsAfter']['piecesPlaced'] == reached_piece]
            self.check(len(matching) == 1, scope, 'Acquisition piece is not one completed recorded lock')
            if matching:
                acquisition = matching[0]
                self.check(acquisition['metricsAfter']['score'] >= initial['victory']['primary']['target'],
                           scope, 'Primary acquired below the authored score goal')
                if timed:
                    at = result['goalReachedAtSeconds']
                    self.check(at + EPSILON >= acquisition['resolvedAtMs'] / 1000,
                               scope, 'Primary acquired before physics resolved')
                    failure = initial['victory'].get('failure', {})
                    if failure.get('type') == 'time':
                        self.check(at <= failure['value'] + EPSILON, scope, 'Primary acquired after its deadline')
            if initial['victoryLapPolicy'] != 'showcase':
                self.check(metrics['piecesPlaced'] == reached_piece, scope, 'Ordinary orb continued after primary finish')
        if stage == 'search':
            self.check(quality['tierThreeUntimedConditionsMet'] == tiers['three'], scope, 'Search tier-three mismatch')
            self.check(quality['masteryUntimedConditionsMet'] == qualify(result, stage, primary, tiers['three']),
                       scope, 'Search mastery qualifier mismatch')
            self.check(quality['timedStars'] is None, scope, 'Untimed search awards timed stars')
            self.check(result['status'] == ('candidate' if qualify(result, stage, primary, tiers['three']) else 'inconclusive'),
                       scope, 'Search status overstates qualification')
        else:
            for tier, met in tiers.items():
                self.check(quality['tiers'][tier]['conditionsMet'] == met, scope, 'Raw tier predicate mismatch: ' + tier)
            self.check(quality['tierThreeConditionsMet'] == tiers['three'], scope, 'Tier-three aggregate mismatch')
            self.check(quality['masteryConditionsMet'] == (primary and tiers['three']),
                       scope, 'Observed mastery conjunction mismatch')
            stars = max([0] + [index for index, tier in enumerate(('one', 'two', 'three'), 1) if tiers[tier]])
            self.check(quality['timedStars'] == (stars if timed else None), scope, 'Raw star count mismatch')
            self.check(quality['censored'] == bool(result.get('qualityCensored')), scope, 'Censoring flags disagree')
            if stage in ('online', 'replay-online'):
                budget_stop = result.get('reason') in BUDGET_REASONS
                if budget_stop:
                    self.check(result['outcome'] == ('win' if primary else 'censored'), scope, 'Budget outcome misclassified')
                    self.check(result['qualityCensored'] == primary, scope, 'Post-primary budget quality censoring mismatch')
                if result.get('outcome') == 'win':
                    self.check(primary, scope, 'Win without acquired primary')
            for index, bonus in enumerate(initial['victory'].get('bonuses', [])):
                expected = bonuses[index] if timed or bonus['type'] != 'time' else None
                self.check(quality['optionalBonuses'][index]['conditionMet'] == expected,
                           scope, 'Optional bonus predicate mismatch: ' + bonus['type'])
        return {'primaryReached': primary, 'rawTierThreeConditionsMet': tiers['three'],
                'qualificationScope': {'search': 'untimed-search-candidate', 'replay': 'independent-untimed-replay',
                                       'online': 'raw-online-observation-only',
                                       'replay-online': 'independent-timed-timestamp-replay'}[stage],
                'qualityCensored': bool(result.get('qualityCensored')),
                'qualifiedMastery': qualify(result, stage, primary, tiers['three']),
                'rawStars': quality.get('timedStars'), 'allOptionalBonusesMet': all(bonuses)}

    def task(self, task, execution, registration):
        scope = task['id']
        output = task['output']
        if execution.get('status') == 'not executed':
            parent = self.executions.get(task.get('dependsOn'), {})
            self.check(self.cohort == 'original' and task['stage'] == 'replay-online'
                       and parent.get('status') == 'interrupted', scope,
                       'Unexecuted task is not an explicitly skipped interrupted-parent replay')
            self.check(not (self.root / output).exists(), scope, 'Skipped replay has an unexpected output directory')
            self.results.append({'id': scope, 'stage': task['stage'], 'invocation': 'not executed',
                                 'reason': execution.get('reason'), 'qualifiedMastery': False,
                                 'authoredLoss': False, 'observationAvailable': False})
            return
        config = self.read(output + '/config.json')
        freeze = registration['sourceFreeze']
        for container in (config,):
            self.check(container['revision']['sourceHash'] == freeze['sourceHash'], scope, 'Invocation source differs from freeze')
            self.check(container['revision']['head'] == freeze['commit'], scope, 'Invocation commit differs from freeze')
            self.check(container['revision']['runtime'] == freeze['runtime'], scope, 'Invocation runtime differs from freeze')
        self.check(config['options'] == task['expectedOptions'], scope, 'Executed configuration differs from registration')
        self.check(self.read(output + '/source-manifest.json') == self.manifest, scope, 'Invocation manifest differs')
        self.check(digest(self.read_bytes(output + '/source.patch')) == freeze['sourcePatch']['sha256'],
                   scope, 'Invocation source patch differs')
        if execution.get('status') == 'interrupted':
            self.check(self.cohort == 'original' and task['stage'] == 'online', scope, 'Unexpected interrupted assignment')
            self.check(execution.get('exitCodeObserved') is False and execution.get('exitCode') is None,
                       scope, 'Interrupted process exit is represented as observed')
            for name in ('summary.json', 'witness.json', 'failure.json'):
                self.check(not (self.root / output / name).exists(), scope, 'Interrupted attempt acquired a final output: ' + name)
            self.results.append({'id': scope, 'stage': task['stage'], 'levelId': task['levelId'],
                                 'seed': task['seed'], 'cadence': task.get('cadence'),
                                 'invocation': 'interrupted', 'reason': execution.get('reason'),
                                 'exitCodeObserved': False, 'qualifiedMastery': False,
                                 'authoredLoss': False, 'observationAvailable': False})
            return
        recovered = execution.get('status') == 'completed-output-recovered'
        self.check(execution.get('exitCode') == 0 or recovered, scope, 'Invocation did not exit successfully or retain verified output')
        summary = self.read(output + '/summary.json')
        for key, expected in (('sourceHash', freeze['sourceHash']), ('head', freeze['commit']), ('runtime', freeze['runtime'])):
            self.check(summary['revision'][key] == expected, scope, 'Summary revision differs: ' + key)
        self.check(summary['status'] == 'completed' and summary['sourceStable'] is True, scope, 'Invocation provenance invalid')
        filename = FILENAMES[task['stage']]
        data = self.read_bytes(output + '/' + filename)
        self.check(summary['result'] == {'path': filename, 'bytes': len(data), 'sha256': digest(data)},
                   scope, 'Result content digest differs from summary')
        result = json.loads(data)
        self.raw_results[scope] = result
        if recovered:
            self.check(execution.get('resultSha256') == digest(data), scope, 'Recovered output digest mismatch')
            self.check(execution.get('summarySha256') == self.input_hashes[output + '/summary.json'],
                       scope, 'Recovered summary digest mismatch')
        self.check(result.get('levelId') == task['levelId'] and result.get('seed') == task['seed'], scope, 'Result identity mismatch')
        initial = self.initial[(task['levelId'], task['seed'])]
        if 'initialBoardHash' in result:
            self.check(result['initialBoardHash'] == initial['hash'], scope, 'Authored initial board hash mismatch')
        if task['stage'] == 'search':
            self.check(result['initialBoard']['occupiedCells'] == initial['cells'], scope, 'Authored initial inventory mismatch')
            self.check(result['budgets']['setupStrategy'] == 'structural-v1', scope, 'Structural preference was not selected')
        if task['stage'] in ('online', 'replay-online'):
            self.check(result['config']['setupStrategy'] == 'none', scope, 'Online arm used structural preference')
        if task['stage'] in ('replay', 'replay-online'):
            online = task['stage'] == 'replay-online'
            parent_name = task['witness' if online else 'candidate']
            parent_data = self.read_bytes(parent_name)
            input_name = 'input-witness.json' if online else 'input-candidate.json'
            self.check(self.read_bytes(output + '/' + input_name) == parent_data, scope, 'Copied replay input differs from parent')
            self.check(config['witnessSha256' if online else 'candidateSha256'] == digest(parent_data),
                       scope, 'Replay parent digest mismatch')
            parent = json.loads(parent_data)
            if online:
                actual = {key: result.get(key) for key in PROJECTION_KEYS}
                expected = {key: parent.get(key) for key in PROJECTION_KEYS}
                self.check(actual == expected, scope, 'Timestamp execution projection differs from recorded witness')
                self.check(result.get('replayValid') is True and result.get('traceComplete') is True,
                           scope, 'Timestamp replay did not validate completely')
                # Use only Node's JSON serialization, not any application replay/analyzer code.
                script = "const c=require('node:crypto');let s='';process.stdin.on('data',x=>s+=x);process.stdin.on('end',()=>console.log(c.createHash('sha256').update(JSON.stringify(JSON.parse(s))).digest('hex')));"
                calculated = subprocess.run(['node', '-e', script], input=json.dumps(actual, separators=(',', ':')),
                                            text=True, capture_output=True, check=True).stdout.strip()
                self.check(calculated == result.get('actualExecutionHash') == result.get('expectedExecutionHash'),
                           scope, 'Independent timestamp projection digest mismatch')
            else:
                self.check(result.get('replayValid') is True and result.get('traceComplete') is True,
                           scope, 'Untimed construction replay is incomplete or invalid')
                self.check(len(result['trace']) == len(parent['trace']), scope, 'Construction replay length mismatch')
                for before, after in zip(parent['trace'], result['trace']):
                    equal = all(before.get(key) == after.get(key) for key in
                                ('step', 'shapeKey', 'preview', 'boardHashBefore', 'boardHashAfter', 'metricsAfter'))
                    self.check(equal and pose(before.get('lockedPiece')) == pose(after.get('lockedPiece')),
                               scope, 'Construction replay geometry/metrics mismatch at piece ' + str(before['step']))
        completed = self.metrics(result, task, initial)
        quality = self.quality(result, task, initial)
        self.results.append({'id': scope, 'stage': task['stage'], 'levelId': task['levelId'], 'seed': task['seed'],
                             'cadence': task.get('cadence'), 'invocation': 'completed', 'completedLocks': completed,
                             'exitCodeObserved': execution.get('exitCodeObserved', execution.get('exitCode') is not None),
                             'observationAvailable': True,
                             'metrics': result.get('metrics'), 'termination': result.get('termination'),
                             'outcome': result.get('outcome'), 'reason': result.get('reason'),
                             'traceValid': result.get('traceValid'), 'replayValid': result.get('replayValid'),
                             **quality})

    def run(self):
        registration = self.read('registration.json')
        self.registration = registration
        self.freeze(registration)
        planned = Counter(task['stage'] for task in registration['tasks'])
        self.check(dict(planned) == EXPECTED_COUNTS[self.cohort],
                   'registration', 'Unexpected registered stage counts for ' + self.cohort)
        self.check(dict(planned) == registration['plannedCounts'], 'registration', 'Declared task counts differ')
        self.check({task['seed'] for task in registration['tasks']} <= {9101, 9102, 9103},
                   'registration', 'Unexpected or confirmation seed')
        execution = self.read('execution.json')
        by_id = {record['id']: record for record in execution}
        self.executions = by_id
        self.check(len(by_id) == len(execution) == sum(EXPECTED_COUNTS[self.cohort].values()),
                   'execution', 'Execution has missing/duplicate records')
        self.check(set(by_id) == {task['id'] for task in registration['tasks']}, 'execution', 'Execution task set differs')
        for task in registration['tasks']:
            try:
                self.task(task, by_id[task['id']], registration)
            except Exception as error:
                self.errors.append({'scope': task['id'], 'message': type(error).__name__ + ': ' + str(error)})
        return {
            'schemaVersion': 1,
            'kind': 'independent-raw-result-audit',
            'cohort': self.cohort,
            'auditScriptSha256': digest(Path(__file__).read_bytes()),
            'registrationSha256': self.input_hashes['registration.json'],
            'sourceHash': registration['sourceFreeze']['sourceHash'],
            'allChecksPassed': not self.errors,
            'plannedCounts': dict(planned),
            'auditedCounts': dict(Counter(record['stage'] for record in self.results)),
            'invocationCounts': dict(Counter(record['invocation'] for record in self.results)),
            'completedLockConservationChecks': self.lock_checks,
            'recordedCommandChecks': self.command_checks,
            'initialBoardsIndependentlyReconstructed': list(self.initial.values()),
            'qualifiedMasteryCounts': dict(Counter(record['stage'] for record in self.results if record.get('qualifiedMastery'))),
            'records': self.results,
            'errors': self.errors,
            'inputHashes': dict(sorted(self.input_hashes.items())),
            'limitations': [
                'Development seeds only; no human calibration, confirmation, balance adoption or real-time CPU feasibility claim.',
                'Line/perfect-clear scoring is independently recomputed; untimed lock bonuses must equal50 and timed residual bonuses must lie0..50.',
                'Exact geometry/score are also compared against independently executed replay files; this audit does not run a third physics replay.',
                'Completed-lock conservation is checked against separately reconstructed authored inventory; intermediate boards are represented by recorded hashes.',
                'Raw tier-three metrics and primary wins remain separate from uncensored, valid, complete mastery witnesses.',
                'Online records are raw observations here; only their independently checked timestamp replays can qualify a timed witness.',
                'Matching three previews in a static trace alone cannot certify the planner information boundary.',
            ],
        }


def audit_recovery(original, recovery):
    """Audit lineage independently; an interrupted row is never overwritten by a retry."""
    scope = 'recovery-lineage'
    source = original.registration
    retried = recovery.registration
    original_tasks = {task['id']: task for task in source['tasks']}
    recovery_tasks = {task['id']: task for task in retried['tasks']}
    original_records = {record['id']: record for record in original.results}
    recovery_records = {record['id']: record for record in recovery.results}
    provenance = retried['recoveryProvenance']
    original.check(provenance['parameterChanges'] == [], scope, 'Recovery declares changed parameters')
    for key in ('commit', 'sourceHash', 'runtime', 'analyzerSha256'):
        original.check(source['sourceFreeze'][key] == retried['sourceFreeze'][key], scope,
                       'Retry source/runtime differs: ' + key)
    for key in ('originalRegistration', 'preservedPartialManifest', 'preparationScript', 'sourceCheck'):
        descriptor = provenance[key]
        original.check(digest(recovery.read_bytes(descriptor['path'])) == descriptor['sha256'],
                       scope, 'Recovery provenance artifact digest mismatch: ' + key)
    journal = original.read('execution-reconstructed.json')
    original.check(journal['originalRegistrationSha256'] == original.input_hashes['registration.json'],
                   scope, 'Interruption journal registration mismatch')
    original.check(journal['exactInterruptionCause'] is None, scope, 'Unknown interruption cause was invented')
    interrupted = {row['id'] for row in journal['records'] if row.get('status') == 'interrupted'}
    original.check(len(interrupted) == 3, scope, 'Expected three interrupted originals')
    for row in journal['records']:
        final = original.executions[row['id']]
        for key in ('status', 'output', 'resultSha256', 'summarySha256'):
            original.check(row.get(key) == final.get(key), scope, 'Original journal entry was silently replaced: ' + row['id'])
    resumed = original.read('execution-resumed-parent.json')
    original.check(resumed['id'] == journal['notYetIncludedOriginalParent']
                   and resumed['exitCode'] == 0, scope, 'Previously unstarted original was not separately completed')
    preserved = original.read('interruption-preserved-files.json')['files']
    expected_files = set()
    for task_id in interrupted:
        task = original_tasks[task_id]
        expected_files.add('logs/' + task_id + '.log')
        expected_files.update(str(path.relative_to(original.root)) for path in
                              (original.root / task['output']).iterdir() if path.is_file())
    original.check(set(preserved) == expected_files, scope, 'Preserved partial-file inventory differs')
    for name, descriptor in preserved.items():
        data = original.read_bytes(name)
        original.check({'bytes': len(data), 'sha256': digest(data)} == descriptor,
                       scope, 'Interrupted original bytes changed: ' + name)
    # Explicit outer-runner exit observations repair the initial conservative journal.
    reconciliation = original.read('exit-observation-reconciliation.json')
    exit_rows = reconciliation['recoveredExplicitExitObservations']
    original.check(len(exit_rows) == 23, scope, 'Expected23 preserved successful exit observations')
    outer_lines = original.read_bytes('run.log').splitlines()
    for task_id, descriptor in exit_rows.items():
        line = outer_lines[descriptor['line'] - 1]
        raw = json.loads(line)
        original.check(digest(line) == descriptor['lineSha256'] and raw == descriptor['record'],
                       scope, 'Outer-runner exit evidence differs: ' + task_id)
        original.check(raw['id'] == task_id and raw['exitCode'] == 0
                       and original.executions[task_id].get('exitCodeObserved') is True
                       and original.executions[task_id].get('exitCode') == 0,
                       scope, 'Explicit successful exit does not match final journal: ' + task_id)
    retry_mapping = {}
    prefixes = []
    for retry_id, task in recovery_tasks.items():
        prior = task['retryOf']
        original_id = prior['taskId']
        original.check(original_id not in retry_mapping, scope, 'Original assignment has duplicate retries')
        retry_mapping[original_id] = retry_id
        original.check(prior['originalRegistrationSha256'] == original.input_hashes['registration.json'],
                       scope, 'Retry points to another original registration')
        old = original_tasks[original_id]
        original.check(all(task.get(key) == old.get(key) for key in ('stage', 'levelId', 'seed', 'cadence')),
                       scope, 'Retry identity/cadence differs from original')
        original.check(substantive_options(task['expectedOptions']) == substantive_options(old['expectedOptions']),
                       scope, 'Retry changed substantive options: ' + retry_id)
        if task['stage'] == 'online':
            original.check(original_id in interrupted, scope, 'Retry was selected from a completed original')
            original.check(prior['originalOutput'] == old['output'], scope, 'Retry original-output linkage differs')
            a = [json.loads(line) for line in original.read_bytes(old['output'] + '/progress.jsonl').splitlines()]
            b = [json.loads(line) for line in recovery.read_bytes(task['output'] + '/progress.jsonl').splitlines()]
            projected_a = [progress_projection(item) for item in a]
            projected_b = [progress_projection(item) for item in b]
            equal = len(a) <= len(b) and projected_a == projected_b[:len(a)]
            original.check(equal, scope, 'Interrupted progress projection differs from retry prefix: ' + original_id)
            prefixes.append({'originalId': original_id, 'retryId': retry_id,
                             'originalRecordedProgressRows': len(a), 'retryRecordedProgressRows': len(b),
                             'exactSimulationPrefix': equal,
                             'qualification': 'Recorded progress fields only; CPU/wall excluded; no original final result or unrecorded command history inferred.'})
        else:
            original.check(old['dependsOn'] in interrupted, scope, 'Recovery replay replaces a completed original replay')
            parent_retry = recovery_tasks[task['dependsOn']]
            original.check(parent_retry['retryOf']['taskId'] == old['dependsOn'], scope, 'Recovery replay is paired with wrong parent')
    missing_originals = {row['id'] for row in original.results if not row.get('observationAvailable')}
    original.check(set(retry_mapping) == missing_originals, scope, 'Recovery does not exactly cover unavailable original observations')
    coverage = []
    complete = Counter()
    for task_id, task in original_tasks.items():
        old = original_records[task_id]
        retry_id = retry_mapping.get(task_id)
        new = recovery_records.get(retry_id)
        available = old.get('observationAvailable') or bool(new and new.get('observationAvailable'))
        if available:
            complete[task['stage']] += 1
        coverage.append({'originalTaskId': task_id, 'stage': task['stage'], 'originalInvocation': old['invocation'],
                         'originalObservationAvailable': old.get('observationAvailable', False),
                         'separateRecoveryTaskId': retry_id,
                         'recoveryInvocation': new['invocation'] if new else None,
                         'completeObservationAvailable': available})
    original.check(dict(complete) == EXPECTED_COUNTS['original'], scope, 'Complete observation coverage is not54')
    return {'originalRegisteredInvocations': len(original_tasks), 'separatelyRegisteredRecoveryInvocations': len(recovery_tasks),
            'completeObservationCounts': dict(complete), 'interruptedOriginalCount': len(interrupted),
            'skippedOriginalReplayCount': sum(row['invocation'] == 'not executed' for row in original.results),
            'preservedInterruptedFiles': len(preserved), 'reconciledObservedExitCount': len(exit_rows),
            'progressPrefixComparisons': prefixes, 'assignments': coverage,
            'interpretation': 'Original54 and separately registered recovery6 remain distinct. Infrastructure interruptions are not authored losses; retries supply missing observations, not replacement original results or fresh confirmation.'}


def self_test():
    metrics = {'score': 500000, 'cascades': 35, 'maxCombo': 18, 'maxCascadeDepth': 18, 'tetrises': 0}
    assert tier_met({'score': 500000, 'cascades': 35, 'combo': 18}, metrics, [False], False)
    assert not bonus_met({'type': 'tetris-count', 'target': 20}, metrics)
    result = {'replayValid': True, 'traceComplete': True, 'outcome': 'win', 'qualityCensored': True,
              'quality': {'censored': True}}
    assert not qualify(result, 'replay-online', True, True)
    result['qualityCensored'] = False
    result['quality']['censored'] = False
    assert qualify(result, 'replay-online', True, True)
    assert not qualify(result, 'replay-online', False, True)
    assert sum(calculate_score(1, 7, wave, False) for wave in range(1, 9)) == 51000
    assert calculate_score(4, 7, 1, False) == 3400
    assert calculate_score(4, 7, 1, True) - calculate_score(4, 7, 1, False) == 8500
    assert command_valid({'type': 'rotate', 'dir': 'flip'})
    assert not command_valid({'type': 'move', 'dir': 2})
    assert substantive_options({'outputDir': 'one', 'witnessPath': 'input', 'seed': 9103}) == {'seed': 9103}
    assert substantive_options({'seed': 9102}) != substantive_options({'seed': 9103})
    assert progress_projection({'elapsedWallMs': 2, 'metrics': {'score': 50}, 'nodes': 42}) \
        == {'metrics': {'score': 50}, 'nodes': 42}
    print('Independent audit self-tests passed; no campaign outcomes read.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--repository', type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument('--output', type=Path)
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return
    audit = Audit(args.root.resolve(), args.repository.resolve())
    original = audit.run()
    recovery_audit = Audit(args.root.resolve() / 'recovery', args.repository.resolve(), 'recovery')
    recovery = recovery_audit.run()
    coverage = audit_recovery(audit, recovery_audit)
    for instance, report in ((audit, original), (recovery_audit, recovery)):
        report['allChecksPassed'] = not instance.errors
        report['inputHashes'] = dict(sorted(instance.input_hashes.items()))
    result = {'schemaVersion': 2, 'kind': 'independent-original-and-recovery-raw-result-audit',
              'auditedAt': datetime.now(timezone.utc).isoformat(),
              'auditScriptSha256': digest(Path(__file__).read_bytes()),
              'timingDisclosure': 'Independent auditor developed during execution and after root-observed outcomes. Recovery adaptation followed reported interruption; outcome review began after both executions completed. Original auditor snapshots preserved.',
              'allChecksPassed': original['allChecksPassed'] and recovery['allChecksPassed'],
              'sourceHash': original['sourceHash'],
              'cohorts': {'original': original, 'recovery': recovery}, 'coverage': coverage,
              'completedLockConservationChecks': audit.lock_checks + recovery_audit.lock_checks,
              'recordedCommandChecks': audit.command_checks + recovery_audit.command_checks,
              'errors': [{'cohort': cohort, **item} for cohort, report in (('original', original), ('recovery', recovery))
                         for item in report['errors']]}
    target = args.output or args.root / 'independent-result-audit.json'
    target.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({key: result[key] for key in ('allChecksPassed',
                     'completedLockConservationChecks', 'recordedCommandChecks')}))
    print(json.dumps({'completeObservationCounts': coverage['completeObservationCounts'],
                      'errors': len(result['errors'])}))
    if result['errors']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
