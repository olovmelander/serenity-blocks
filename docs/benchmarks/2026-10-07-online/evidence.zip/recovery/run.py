#!/usr/bin/env python3
"""Execute a manually frozen campaign with at most three subprocesses; retain failures."""
import concurrent.futures
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent


def load(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def invoke(task, repo):
    log_path = ROOT / 'logs' / (task['id'] + '.log')
    with log_path.open('x') as log:
        result = subprocess.run(task['command'], cwd=repo, stdout=log, stderr=subprocess.STDOUT)
    return {'id': task['id'], 'exitCode': result.returncode,
            'log': str(log_path.relative_to(ROOT)), 'output': task['output']}


def main():
    registration = load(ROOT / 'registration.json')
    assert registration['executionReady'] is True
    assert sha(ROOT / 'registration.json') == (ROOT / 'registration.sha256').read_text().split()[0]
    assert sha(Path(__file__)) == registration['runnerSha256']
    assert registration['workers'] == 3
    assert not (ROOT / 'execution.json').exists(), 'Do not overwrite prior execution'
    (ROOT / 'logs').mkdir(exist_ok=True)
    records = []
    for stages, label in [({'search', 'online'}, 'parents'), ({'replay', 'replay-online'}, 'replays')]:
        eligible = []
        for task in registration['tasks']:
            if task['stage'] not in stages:
                continue
            input_name = task.get('candidate', task.get('witness'))
            if input_name:
                input_path = ROOT / input_name
                reason = None
                if not input_path.exists():
                    reason = 'Parent did not retain the required input artifact'
                else:
                    try:
                        value = load(input_path)
                        if task['stage'] == 'replay' and not value.get('trace'):
                            reason = 'Structural search retained no nonempty trace'
                    except (ValueError, OSError) as error:
                        reason = 'Unreadable parent input artifact: ' + str(error)
                if reason:
                    records.append({'id': task['id'], 'status': 'not executed', 'reason': reason, 'output': task['output']})
                    continue
            eligible.append(task)
        with concurrent.futures.ThreadPoolExecutor(max_workers=registration['workers']) as pool:
            futures = {pool.submit(invoke, task, registration['repositoryRoot']): task for task in eligible}
            for future in concurrent.futures.as_completed(futures):
                task = futures[future]
                try:
                    record = future.result()
                except Exception as error:
                    record = {'id': task['id'], 'status': 'runner error', 'error': str(error), 'output': task['output']}
                records.append(record)
                print(json.dumps(record), flush=True)
        ordered = sorted(records, key=lambda record: next(i for i, task in enumerate(registration['tasks']) if task['id'] == record['id']))
        (ROOT / ('execution-' + label + '.json')).write_text(json.dumps(ordered, indent=2) + '\n')
    (ROOT / 'execution.json').write_text(json.dumps(ordered, indent=2) + '\n')


if __name__ == '__main__':
    main()
