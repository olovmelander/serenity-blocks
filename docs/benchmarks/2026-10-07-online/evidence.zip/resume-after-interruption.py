#!/usr/bin/env python3
"""Run remaining originals and separately registered retries through frozen invoke functions."""
import concurrent.futures
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text())


def write(path, data):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')
    os.replace(temporary, path)


def runner(root, name):
    registration = load(root / 'registration.json')
    assert sha(root / 'registration.json') == (root / 'registration.sha256').read_text().split()[0]
    assert sha(root / 'run.py') == registration['runnerSha256']
    spec = importlib.util.spec_from_file_location(name, root / 'run.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    (root / 'logs').mkdir(exist_ok=True)
    return registration, module


def verify_preserved():
    for name, value in load(ROOT / 'interruption-preserved-files.json')['files'].items():
        path = ROOT / name
        assert path.stat().st_size == value['bytes'] and sha(path) == value['sha256'], name


def main():
    original, original_runner = runner(ROOT, 'original_frozen_runner')
    recovery_root = ROOT / 'recovery'
    recovery, recovery_runner = runner(recovery_root, 'recovery_frozen_runner')
    assert not (ROOT / 'execution.json').exists() and not (recovery_root / 'execution.json').exists()
    verify_preserved()
    original_records = load(ROOT / 'execution-reconstructed.json')['records']
    original_records.append(load(ROOT / 'execution-resumed-parent.json'))
    assert len(original_records) == 27 and len({item['id'] for item in original_records}) == 27
    interrupted = {item['id'] for item in original_records if item.get('status') == 'interrupted'}
    assert len(interrupted) == 3
    original_replays = []
    for task in original['tasks']:
        if task['stage'] not in ('replay', 'replay-online'):
            continue
        if task['dependsOn'] in interrupted:
            original_records.append({'id': task['id'], 'output': task['output'], 'status': 'not executed',
                'reason': 'Original parent was externally interrupted and retained no final input artifact; separately registered retry does not replace this assignment.',
                'exitCodeObserved': False})
        else:
            input_name = task.get('candidate', task.get('witness'))
            assert (ROOT / input_name).is_file()
            original_replays.append(task)
    assert len(original_replays) == 24
    recovery_records = []
    recovery_parents = [task for task in recovery['tasks'] if task['stage'] == 'online']
    recovery_replays = [task for task in recovery['tasks'] if task['stage'] == 'replay-online']
    assert len(recovery_parents) == len(recovery_replays) == 3
    for root, tasks in [(ROOT, original_replays), (recovery_root, recovery_parents + recovery_replays)]:
        for task in tasks:
            assert not (root / task['output']).exists()
            assert not (root / 'logs' / (task['id'] + '.log')).exists()
    with (ROOT / 'resume-execution-plan.json').open('x') as file:
        file.write(json.dumps({'startedAt': datetime.now(timezone.utc).isoformat(), 'workers': 3,
            'orchestratorSha256': sha(Path(__file__)), 'originalRegistrationSha256': sha(ROOT / 'registration.json'),
            'recoveryRegistrationSha256': sha(recovery_root / 'registration.json'),
            'originalReplays': [task['id'] for task in original_replays],
            'recoveryTasks': [task['id'] for task in recovery['tasks']],
            'executionMethod': 'Unchanged frozen run.py invoke functions; one shared three-worker executor.'}, indent=2) + '\n')
    write(ROOT / 'execution-parents.json', original_records[:27])
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        queued = {}
        for task in recovery_parents:
            queued[pool.submit(recovery_runner.invoke, task, recovery['repositoryRoot'])] = ('recovery', task)
        for task in original_replays:
            queued[pool.submit(original_runner.invoke, task, original['repositoryRoot'])] = ('original', task)
        for future in concurrent.futures.as_completed(queued):
            cohort, task = queued[future]
            try:
                record = future.result()
                record['exitCodeObserved'] = True
            except Exception as error:
                record = {'id': task['id'], 'output': task['output'], 'status': 'runner error', 'error': str(error)}
            record['resumedByCoordinator'] = True
            (original_records if cohort == 'original' else recovery_records).append(record)
            write(ROOT / 'execution-partial.json', original_records)
            write(recovery_root / 'execution-partial.json', recovery_records)
            print(json.dumps({'cohort': cohort, **record}), flush=True)
        verify_preserved()
        replay_futures = {}
        for task in recovery_replays:
            if not (recovery_root / task['witness']).exists():
                recovery_records.append({'id': task['id'], 'output': task['output'], 'status': 'not executed',
                                         'reason': 'Recovery parent did not retain a witness'})
            else:
                replay_futures[pool.submit(recovery_runner.invoke, task, recovery['repositoryRoot'])] = task
        for future in concurrent.futures.as_completed(replay_futures):
            task = replay_futures[future]
            try:
                record = future.result(); record['exitCodeObserved'] = True
            except Exception as error:
                record = {'id': task['id'], 'output': task['output'], 'status': 'runner error', 'error': str(error)}
            record['resumedByCoordinator'] = True
            recovery_records.append(record)
            write(recovery_root / 'execution-partial.json', recovery_records)
            print(json.dumps({'cohort': 'recovery', **record}), flush=True)
    verify_preserved()
    for root, registration, records in [(ROOT, original, original_records), (recovery_root, recovery, recovery_records)]:
        by_id = {record['id']: record for record in records}
        assert len(records) == len(by_id) == len(registration['tasks'])
        ordered = [by_id[task['id']] for task in registration['tasks']]
        write(root / 'execution-replays.json', ordered)
        write(root / 'execution.json', ordered)
    print(json.dumps({'status': 'completed', 'originalTasksAccounted': len(original_records),
                      'recoveryTasksAccounted': len(recovery_records), 'preservedPartialFilesUnchanged': True}), flush=True)


if __name__ == '__main__':
    main()
