# Fixed-script failures and proposed online validation

This is a retrospective audit of the frozen targeted-mastery campaign at `0ecb8839c6542eae1cc1c6e5c7bba1af1c5749a3`, source hash `b76c97feb21a3fc04c55ce5fad7b1923e309824c374c523e6be3416d3c0d9c4a`. It contains no new search or gameplay runs. Reproduce from the repository root:

```sh
python artifacts/odyssey-online-mastery-2026-10-07/failure-audit/audit.py
```

Use `--baseline <directory>` if the previous archive is extracted elsewhere. The driver checks the original registration/analyzer fingerprint, each invocation's source revision and checksummed result, and exact replay-candidate bytes. It writes `analysis.json` with all input hashes, all 13 failure details, the five complete partial controls, and separately qualified wall-time observations from the nine earlier searches. Source snapshot verification remains in the prior campaign's frozen analyzer and independent result audit.

## What failed

All 13 failed pieces begin on exactly the candidate board with matching previews; all earlier completed boards also agree. These failures are caused by executing a no-gravity command sequence while gravity advances the current piece, rather than by earlier board drift.

| Orb | Automatic lock | Rejected horizontal move | Rejected rotation | Valid complete partial scripts |
| --- | ---: | ---: | ---: | ---: |
| 49 | 6 | 0 | 0 | 0 |
| 55 | 0 | 0 | 1 | 5 |
| 59 | 1 | 5 | 0 | 0 |

Every automatic lock follows **2–6 grounded soft-drop no-ops**, with another **300–500 ms observed between the first such no-op and the lock**. The piece has descended earlier than the script expects; the script spends lock-delay time on redundant down commands and never reaches its intended later tuck, horizontal move or hard drop. All seven automatic locks produce a different pose from the candidate target. This suggests observing the current pose and replacing stale descent counts with a newly reachable path; it does not establish that the old target remains reachable.

The six rejected commands occur **1–18 rows below** their untimed expected before-pose. Five are horizontal moves in orb 59; previous rotations can also produce different wall kicks and x coordinates. The sixth is orb 55 seed 9103 at deliberate cadence: its last right rotation is attempted at `y=63` instead of `y=62`. A fixed command can therefore become invalid even after a long correct prefix (130 completed pieces in that example).

The five complete controls are all orb 55: seeds 9101–9103 at 150/100 ms reaction/action timing and 9101–9102 at 300/180 ms. They execute all 192 recorded pieces but remain below primary. **All 18 timed attempts are primary-censored.** `qualityCensored=false` denotes the absence of a post-primary quality censor; no timed attempt acquired primary. Neither invalid interrupted traces nor exhausted partial traces are player-loss observations.

## Meaningful paired development protocol

The following are recommendations for the next registration, not a registration or new result. Keep seeds 9101–9103 as development only; reserve 11001+ for later separately frozen confirmation.

1. **Failure-prefix recovery fixtures.** Reconstruct each of the 13 authentic timed prefixes using its original script and cadence. At the failed piece's spawn, enable observation-based adaptation with only the current piece, board and three previews. Preserve gravity, lock delay, scoring, reaction time and action interval. Report separately: exact original target recovered; another legal placement survived; automatic lock; rejected action; top-out; or budget exhaustion. An alternative surviving placement is useful adaptation, but is not proof that the original tucked placement was recovered. Reconstructing from the level start avoids injecting an easier board or resetting piece age/lock timers. These selected regression fixtures are not a success-rate sample.
2. **All 18 end-to-end pairs.** Run all three orbs × three seeds × two original cadences from their authored starts. Compare descriptively with the 18 frozen fixed scripts, including the five valid complete partial controls. Keep validity, completed pieces, actual primary acquisition, real terminal outcome, quality censoring, exact joint three-star conditions, optional bonuses and resource limits separate. Report each pair and every failure; do not select only runs that pass the old interruption point. Once the online policy chooses a different earlier placement, it is a different trajectory and cannot be called a rescue of the specific old failed tuck.
3. **Freeze bounded decision resources.** Register maximum pieces, total nodes, per-decision nodes, number of replans/decisions, wall budget, simulated-time limit, any fallback and the exact primary/showcase stopping rule. Count all abandoned/stale plans and retries against their budgets. A gravity-driven lock is ordinary gameplay in an online policy, while a stale fixed-script replay may be invalidated by that same event; do not compare those classification labels as if they were identical capability metrics.

Adapting successfully to current gravity is an execution milestone. It does not itself solve mastery geometry. A subsequent independent inventory review tightens orb 49's older generous 240-cell bound: its drained pre-lock board has at most `4×10 + 20×9 = 220` cells; one tetromino raises that to at most **224**. Thus a depth-eight terminal chain can contain at most four Quads, needs at least eight prior Quads, and requires at least **130 pieces** overall. Instant-lock scoring still excludes the relaxed 9+3 allocation. This is a necessary bound, not a legal construction. Orb 55 needs at least 155 pieces for its three-star conjunction and 305 for three stars plus every bonus; orb 59 needs at least 140. A 192-piece budget removes some piece-supply exclusions, not geometric, timing or scoring exclusions. One depth-18 chain still adds only one cascade sequence. Preserve the distinction between prepared geometry, legal construction from an authored start, timed execution and human feasibility.

## Planning cost and gameplay time

The prior search's median elapsed wall time between completed-lock progress records ranges from approximately **169 to 432 ms per lock** across the nine runs. Those deltas include planning, engine execution, logging and contention among three workers. They are not isolated planner CPU measurements, but they show why an unlimited synchronous planner cannot silently be treated as instantaneous gameplay input.

For each new decision, record observation time/pose, actual wall duration, process CPU duration, nodes expanded, planned command, action-ready time, action execution time, and whether the piece or pose changed during computation. Record total/median/nearest-rank p90/max planning latency and deadline misses separately from simulated completion time. Fix worker count and disclose hardware/runtime and concurrency, since host contention affects wall latency.

A defensible charged-latency model advances normal gravity, lock timers and deadlines for the planner's measured wall duration before its proposed action can occur. Earliest input is the maximum of the spawn reaction gate, previous-action interval gate and planning-completion time; reaction and compute can overlap only if the implementation explicitly models that overlap. Round to the existing fixed simulation tick consistently. If a piece locks while a plan is computing, cancel that piece's stale commands and observe the new piece without transferring privileged queue information. Bounded fallback/replanning behavior must be declared in advance.

If the first development implementation pauses the virtual clock during planning, describe its result as **gravity-aware execution with computational feasibility unqualified**. A fixed artificial planning delay is a latency scenario, not proof that the solver actually meets that delay. Report observed wall/CPU cost and follow with a charged-latency run before claiming online real-time execution. Never retroactively subtract planning delay, change cadence, alter the starting board or ignore scoring differences to make a trace succeed.

No validated human win-rate target, policy-adoption gate or authored gameplay retune follows from these development comparisons. Human playtesting remains necessary after a legally constructed and appropriately timed witness exists.
