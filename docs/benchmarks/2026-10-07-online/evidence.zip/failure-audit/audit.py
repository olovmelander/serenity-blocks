#!/usr/bin/env python3
"""Describe already-recorded fixed replay failures; run no search, physics or replay."""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parent


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', type=Path, default=ROOT.parents[1] / 'odyssey-targeted-mastery-2026-10-07')
    args = parser.parse_args()
    baseline = args.baseline
    hashes = {}

    def read(relative):
        data = (baseline / relative).read_bytes()
        hashes[relative] = sha(data)
        return data

    def load(relative):
        return json.loads(read(relative))

    registration = load('registration.json')
    assert hashes['registration.json'] == read('registration.sha256').decode().split()[0]
    freeze = registration['sourceFreeze']
    assert sha(read('analyze.py')) == freeze['analyzerSha256']
    cases = []
    compute = []
    controls = []
    for task in registration['tasks']:
        output = task['output']
        config = load(output + '/config.json')
        summary = load(output + '/summary.json')
        assert config['revision']['sourceHash'] == freeze['sourceHash']
        assert config['revision']['head'] == freeze['commit']
        assert summary['revision'] == config['revision'] and summary['sourceStable'] is True
        filename = 'candidate.json' if task['stage'] == 'search' else 'replay.json'
        raw = read(output + '/' + filename)
        assert summary['result'] == {'path': filename, 'bytes': len(raw), 'sha256': sha(raw)}
        result = json.loads(raw)
        if task['stage'] == 'search':
            progress = [json.loads(line) for line in read(output + '/progress.jsonl').splitlines() if line]
            assert len(progress) == result['piecesPlaced']
            deltas = [progress[0]['elapsedMs']] + [b['elapsedMs'] - a['elapsedMs'] for a, b in zip(progress, progress[1:])]
            ordered = sorted(deltas)
            compute.append({'id': task['id'], 'pieces': result['piecesPlaced'], 'nodes': result['compute']['nodes'],
                            'elapsedWallMs': result['compute']['elapsedMs'],
                            'progressWallDeltaMs': {'minimum': min(deltas), 'median': statistics.median(deltas),
                                'p90NearestRank': ordered[math.ceil(.9 * len(ordered)) - 1], 'maximum': max(deltas),
                                'countAbove100Ms': sum(value > 100 for value in deltas),
                                'countAbove180Ms': sum(value > 180 for value in deltas)},
                            'scope': 'Gross elapsed wall time between completed-lock progress observations, including planning, execution, logging and worker contention; not separately measured planner CPU time.'})
            continue
        if not result['timed']:
            continue
        candidate_raw = read(task['candidate'])
        assert sha(candidate_raw) == config['candidateSha256'] == summary['candidateSha256']
        assert read(output + '/input-candidate.json') == candidate_raw
        candidate = json.loads(candidate_raw)
        assert result['outcome'] == 'censored' and result['primaryReached'] is False
        assert result['qualityCensored'] is False and result['quality']['censored'] is False
        if not result['failure']:
            assert result['replayValid'] and result['traceComplete'] and result['reason'] == 'candidate-exhausted'
            controls.append({'id': task['id'], 'orb': result['levelId'], 'seed': result['seed'],
                             'cadence': result['cadence'], 'piecesReplayed': result['piecesReplayed'],
                             'depth': result['maximumDepth'], 'score': result['metrics']['score'],
                             'seconds': result['metrics']['time'], 'primaryCensored': True})
            continue
        assert result['reason'] == 'execution-interrupted' and not result['replayValid'] and not result['traceComplete']
        step = result['failure']['step']
        actual = next(entry for entry in result['trace'] if entry['step'] == step)
        expected = candidate['trace'][step - 1]
        assert actual['boardHashBefore'] == expected['boardHashBefore']
        assert actual['preview'] == expected['preview'] and actual['shapeKey'] == expected['shapeKey']
        prefix = result['trace'][:step - 1]
        assert all(entry['completed'] and entry['boardHashAfter'] == candidate['trace'][i]['boardHashAfter']
                   for i, entry in enumerate(prefix))
        actions = actual['actions']
        grounded = [entry for entry in actions if entry.get('legalStop')]
        divergences = []
        for i, action in enumerate(actions):
            previous = expected['actions'][i]['beforePose']
            pose = action['beforePose']
            delta = {key: pose[key] - previous[key] for key in ('x', 'y', 'rotation')}
            if any(delta.values()):
                divergences.append({'actionNumber': i + 1, 'type': action['type'], 'actualBeforePose': pose,
                                    'untimedBeforePose': previous, 'delta': delta})
        last = actions[-1]
        last_expected = expected['actions'][len(actions) - 1]
        rejected = [action for action in actions if not action['accepted'] and not action.get('legalStop')]
        lock = actual.get('lockedPiece')
        target = expected.get('lockedPiece')
        case = {'id': task['id'], 'orb': result['levelId'], 'seed': result['seed'], 'cadence': result['cadence'],
                'failure': result['failure'], 'failureSeconds': result['metrics']['time'],
                'piecesReplayedIncludingAnyAutomaticLock': result['piecesReplayed'],
                'matchingCompletedPrefixPieces': len(prefix), 'matchingFailureStartBoard': True,
                'failureStartBoardHash': actual['boardHashBefore'], 'shape': actual['shapeKey'],
                'preview': actual['preview'], 'attemptedActions': len(actions), 'plannedActions': len(expected['plannedActions']),
                'automaticLocks': result['automaticLocks'], 'groundedSoftDropNoops': len(grounded),
                'observedMsFromFirstGroundedNoopToLock': actual['lockAtMs'] - grounded[0]['atMs'] if lock and grounded else None,
                'lockPieceAgeMs': actual['lockAtMs'] - actual['spawnAtMs'] if lock else None,
                'firstPoseDivergence': divergences[0] if divergences else None,
                'lastAttemptedCommand': {key: last[key] for key in ('type', 'dir', 'accepted', 'legalStop') if key in last},
                'lastActualBeforePose': last['beforePose'], 'lastUntimedBeforePose': last_expected['beforePose'],
                'lastYDriftRows': last['beforePose']['y'] - last_expected['beforePose']['y'],
                'rejectedCommandTypes': [entry['type'] for entry in rejected],
                'remainingUntimedCommands': expected['plannedActions'][len(actions):],
                'actualLockPose': {key: lock[key] for key in ('x', 'y', 'rotation', 'shapeKey')} if lock else None,
                'candidateTargetPose': {key: target[key] for key in ('x', 'y', 'rotation', 'shapeKey')},
                'sameLockPoseAsCandidate': all(lock[key] == target[key] for key in ('x', 'y', 'rotation', 'shapeKey')) if lock else None,
                'primaryCensored': True, 'postPrimaryQualityCensored': False}
        cases.append(case)
    auto = [case for case in cases if case['failure']['reason'] == 'automatic-lock']
    assert len(cases) == 13 and len(auto) == 7 and len(controls) == 5
    assert all(case['groundedSoftDropNoops'] >= 2 and case['sameLockPoseAsCandidate'] is False for case in auto)
    grouped = defaultdict(Counter)
    for case in cases:
        grouped[str(case['orb'])][case['failure']['reason']] += 1
    output = {'kind': 'Retrospective fixed-script failure audit; no new gameplay observations',
              'baselineCommit': freeze['commit'], 'baselineSourceHash': freeze['sourceHash'],
              'developmentSeeds': [9101, 9102, 9103],
              'counts': {'timedReplays': 18, 'interrupted': len(cases), 'validCompletePartialControls': len(controls),
                         'primaryCensored': 18, 'postPrimaryQualityCensored': 0,
                         'failuresByReason': dict(Counter(case['failure']['reason'] for case in cases)),
                         'rejectedCommandTypes': dict(Counter(kind for case in cases for kind in case['rejectedCommandTypes'])),
                         'failuresByOrb': dict(grouped)},
              'failureCases': cases, 'validCompletePartialControls': controls, 'priorSearchCompute': compute,
              'interpretation': [
                  'Every failed piece begins from the same board and previews as its untimed candidate; every earlier completed board agrees.',
                  'All seven automatic locks occur while the fixed script repeats grounded softDrop no-ops, before its later target rotation/move/hardDrop.',
                  'All six rejected commands occur below their untimed expected row; successful earlier wall kicks can also change x.',
                  'This identifies stale-command opportunities, not proof that the original target remains reachable under gravity.',
                  'Valid complete partial controls exhaust their 192-piece scripts before primary; they are not primary wins or full-mastery controls.',
                  'Wall progress deltas are not isolated planner CPU cost and must not be silently charged as exact planning latency.',
                  'No new cohort or human inference; unchanged development evidence does not become confirmation by reanalysis.'
              ], 'auditSourceSha256': sha(Path(__file__).read_bytes()), 'inputHashes': dict(sorted(hashes.items()))}
    (ROOT / 'analysis.json').write_text(json.dumps(output, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'counts': output['counts'], 'failureCases': [
        {key: case[key] for key in ('id', 'failure', 'matchingCompletedPrefixPieces', 'attemptedActions', 'plannedActions',
                                    'groundedSoftDropNoops', 'lastYDriftRows', 'rejectedCommandTypes')}
        for case in cases]}, indent=2))


if __name__ == '__main__':
    main()
