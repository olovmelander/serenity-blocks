#!/usr/bin/env python3
"""Independent raw-trace audit. Does not import the campaign analyzer or run a planner.

Run only after the registered campaign completes. The only production code executed
is authored-board initialization from the verified frozen source snapshot. Score and
geometry are cross-checked against the separately executed replays, not re-simulated
by this auditor. This does not establish human or real-time planning feasibility.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile
import zipfile

FILENAMES = {'search': 'candidate.json', 'replay': 'replay.json',
             'online': 'witness.json', 'replay-online': 'replay.json'}
COUNTER_KEYS = ('piecesPlaced', 'lines', 'singles', 'doubles', 'triples', 'tetrises',
                'cascades', 'combos', 'maxCombo', 'maxCascadeDepth')
PROJECTION_KEYS = ('levelId', 'seed', 'initialBoardHash', 'commands', 'trace', 'outcome',
                   'reason', 'qualityCensored', 'primaryReachedAtPiece', 'primaryReached',
                   'goalReachedAtSeconds', 'stoppedAtSeconds', 'stopPhase',
                   'physicsDrainedThroughSeconds', 'metrics', 'quality')
BUDGET_REASONS = {'piece-budget', 'simulation-budget', 'wall-budget', 'node-budget', 'decision-budget'}
PIECES = {'I', 'J', 'L', 'O', 'S', 'T', 'Z'}
EPSILON = 1e-6


def digest(data):
    return hashlib.sha256(data).hexdigest()


def pose(piece):
    return {key: piece.get(key, 0 if key == 'rotation' else None)
            for key in ('shapeKey', 'x', 'y', 'rotation')} if piece else None


def command_valid(command):
    kind = command.get('type')
    return kind in ('softDrop', 'hardDrop') or (kind == 'move' and command.get('dir') in (-1, 1)) \
        or (kind == 'rotate' and command.get('dir') in ('left', 'right', 'flip'))


def bonus_met(bonus, metrics, top_out=False):
    key = bonus['type']
    aliases = {'max-cascade-depth': 'maxCascadeDepth', 'tetris-count': 'tetrises',
               'cascade': 'cascades', 'combo': 'maxCombo'}
    if key in aliases:
        return metrics.get(aliases[key], 0) >= bonus['target']
    if key == 'no-singles':
        return metrics.get('singles', 0) == 0
    if key == 'no-top-out':
        return not top_out and metrics.get('deaths', 0) == 0
    if key in ('pieces', 'time'):
        return (metrics.get('piecesPlaced' if key == 'pieces' else 'time') or 0) <= bonus['target']
    raise ValueError('Unknown bonus: ' + key)


def tier_met(conditions, metrics, bonuses, timed):
    for key, target in conditions.items():
        if key == 'time' and not timed:
            continue
        metric = {'combo': 'maxCombo', 'maxDeaths': 'deaths'}.get(key, key)
        actual = sum(bonuses) if key == 'bonuses' else (metrics.get(metric) or 0)
        if key in ('time', 'maxDeaths'):
            if actual > target:
                return False
        elif actual < target:
            return False
    return True


def qualify(result, stage, primary, tier_three):
    """Raw metric predicates are separate from a complete, independently replayed win."""
    if stage == 'search':
        return bool(result.get('traceValid') and result.get('quality', {}).get('qualified')
                    and primary and tier_three)
    return bool(result.get('replayValid') and result.get('traceComplete')
                and result.get('outcome') == 'win' and not result.get('qualityCensored')
                and not result.get('quality', {}).get('censored') and primary and tier_three)


class Audit:
    def __init__(self, root, repository):
        self.root = root
        self.repository = repository
        self.errors = []
        self.input_hashes = {}
        self.lock_checks = 0
        self.command_checks = 0
        self.results = []
        self.initial = {}

    def check(self, condition, scope, message):
        if not condition:
            self.errors.append({'scope': scope, 'message': message})
        return bool(condition)

    def read_bytes(self, relative):
        path = self.root / relative
        data = path.read_bytes()
        self.input_hashes[str(relative)] = digest(data)
        return data

    def read(self, relative):
        return json.loads(self.read_bytes(relative))

    def freeze(self, registration):
        scope = 'registration/source'
        self.check(digest(self.read_bytes('registration.json')) ==
                   self.read_bytes('registration.sha256').decode().split()[0], scope, 'Registration digest mismatch')
        freeze = registration['sourceFreeze']
        for descriptor in (freeze['sourceManifest'], freeze['sourceSnapshot'], freeze['sourcePatch'],
                           registration['environment'], registration['baselineEvidence']):
            self.check(digest(self.read_bytes(descriptor['path'])) == descriptor['sha256'],
                       scope, 'Frozen artifact mismatch: ' + descriptor['path'])
        # No analyzer implementation is imported or consulted to interpret results.
        self.check(digest(self.read_bytes('analyze.py')) == freeze['analyzerSha256'], scope, 'Analyzer changed after freeze')
        shared = freeze['sharedAnalyzer']
        self.check(digest(self.read_bytes(shared['path'])) == shared['sha256'], scope, 'Shared analyzer changed')
        self.check(digest(self.read_bytes('run.py')) == registration['runnerSha256'], scope, 'Runner changed')
        self.manifest = self.read(freeze['sourceManifest']['path'])
        source_digest = hashlib.sha256()
        with zipfile.ZipFile(self.root / freeze['sourceSnapshot']['path']) as archive:
            self.check(set(archive.namelist()) == set(self.manifest), scope, 'Snapshot file set differs from manifest')
            for name in sorted(self.manifest, key=lambda value: value.encode('utf-16-be')):
                data = archive.read(name)
                self.check(self.manifest[name] == {'bytes': len(data), 'sha256': digest(data)}, scope,
                           'Snapshot source bytes mismatch: ' + name)
                source_digest.update((name + '\0').encode())
                source_digest.update(data)
            self.check(source_digest.hexdigest() == freeze['sourceHash'], scope, 'Combined source fingerprint mismatch')
            # Initialize only the authored boards using verified source, even if today's checkout differs.
            with tempfile.TemporaryDirectory(prefix='odyssey-independent-initial-') as directory:
                temporary = Path(directory)
                for name in self.manifest:
                    if Path(name).is_absolute() or '..' in Path(name).parts:
                        raise ValueError('Unsafe frozen source member: ' + name)
                    destination = temporary / name
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    destination.write_bytes(archive.read(name))
                modules = self.repository / 'node_modules'
                if modules.exists():
                    (temporary / 'node_modules').symlink_to(modules, target_is_directory=True)
                init_js = r'''
import { createHash } from 'node:crypto';
import { GameplayHybridEngine } from './src/core/odyssey/GameplayHybridEngine.js';
import { getLevelById } from './src/core/odyssey/data/levels.js';
const results=[];
for (const levelId of [49,55,59]) for (const seed of [9101,9102,9103]) {
 const level=getLevelById(levelId); const engine=new GameplayHybridEngine(); engine.configure(level);
 const state=engine.createGameState({rngSeed:seed}); const labels=new Map();
 const key=state.boardGrid.map((row,y)=>row.map((cell,x)=>{
  if(!cell)return '.';const id=cell.id??`cell:${x}:${y}`;
  if(!labels.has(id))labels.set(id,labels.size);return labels.get(id);
 }).join(',')).join('|');
 results.push({levelId,seed,cells:state.boardGrid.flat().filter(Boolean).length,
  columns:state.boardGrid[0].length,rows:state.boardGrid.length,
  hash:createHash('sha256').update(key).digest('hex'),
  stars:level.stars,victory:level.victory,victoryLapPolicy:level.victoryLapPolicy||'none'});
 state.reset();engine.reset();
}
console.log('AUDIT_INITIAL_BOARDS='+JSON.stringify(results));
'''
                output = subprocess.run(['node', '--input-type=module', '-e', init_js], cwd=temporary,
                                        text=True, capture_output=True, check=True).stdout
                line = next(line for line in output.splitlines() if line.startswith('AUDIT_INITIAL_BOARDS='))
                for item in json.loads(line.split('=', 1)[1]):
                    self.initial[(item['levelId'], item['seed'])] = item

    def metrics(self, result, task, initial):
        scope = task['id']
        counts = {key: 0 for key in COUNTER_KEYS}
        previous_hash = initial['hash']
        previous_score = 0
        completed = 0
        all_actions = []
        for index, entry in enumerate(result.get('trace', []), 1):
            entry_scope = f'{scope}/piece-{index}'
            self.check(entry['step'] == index, entry_scope, 'Piece index discontinuity')
            self.check(len(entry.get('preview', [])) == 3 and set(entry['preview']) <= PIECES,
                       entry_scope, 'Preview scope is not exactly three legal pieces')
            self.check(entry.get('shapeKey') in PIECES, entry_scope, 'Invalid tetromino name')
            self.check(entry.get('boardHashBefore') == previous_hash, entry_scope, 'Board hash continuity mismatch')
            for command in entry.get('actions', []):
                self.command_checks += 1
                self.check(command_valid(command), entry_scope, 'Invalid command vocabulary')
                if task['stage'] in ('search', 'replay'):
                    self.check(command.get('accepted') or command.get('legalStop'), entry_scope, 'Rejected construction input')
                all_actions.append(command)
            if not entry.get('lockedPiece'):
                self.check(not entry.get('completed'), entry_scope, 'Completed piece has no lock')
                continue
            piece = entry['lockedPiece']
            cells = sum(bool(cell) for row in piece['shape'] for cell in row)
            self.check(cells == 4, entry_scope, 'Recorded lock is not a four-cell tetromino')
            if not entry.get('completed'):
                continue
            completed += 1
            counts['piecesPlaced'] += 1
            waves = entry.get('lineClears', [])
            counts['lines'] += sum(waves)
            for width, key in ((1, 'singles'), (2, 'doubles'), (3, 'triples'), (4, 'tetrises')):
                counts[key] += waves.count(width)
            if len(waves) >= 2:
                counts['cascades'] += 1
                counts['combos'] += len(waves) - 1
                counts['maxCombo'] = max(counts['maxCombo'], len(waves))
                counts['maxCascadeDepth'] = max(counts['maxCascadeDepth'], len(waves))
            observed = entry['metricsAfter']
            for key, value in counts.items():
                self.check(observed.get(key) == value, entry_scope, 'Cumulative metric mismatch: ' + key)
            self.check(observed['score'] >= previous_score, entry_scope, 'Score decreased')
            previous_score = observed['score']
            conservation = entry['cellConservation']
            expected = initial['cells'] + 4 * observed['piecesPlaced'] - initial['columns'] * observed['lines']
            self.check(conservation['expected'] == expected, entry_scope, 'Cell equation differs from authored inventory')
            self.check(conservation['actual'] == expected, entry_scope, 'Actual cell count violates conservation')
            if 'visible' in conservation:
                self.check(conservation['actual'] == conservation['visible'] + conservation['offBoard'],
                           entry_scope, 'Visible plus off-board cell count mismatch')
                self.check(conservation['valid'] and not conservation['overlap'], entry_scope, 'Replay reports overlap/invalid cells')
            self.lock_checks += 1
            previous_hash = entry['boardHashAfter']
        final = result.get('metrics')
        if final:
            for key, value in counts.items():
                self.check(final.get(key) == value, scope, 'Final metric differs from recorded completed locks: ' + key)
            self.check(final['score'] == previous_score, scope, 'Final score differs from last fully resolved lock')
        if task['stage'] in ('online', 'replay-online') and result.get('traceValid'):
            self.check(all_actions == result['commands'], scope, 'Flat timestamp log differs from per-piece input log')
            previous_time = -1.0
            entries = {entry['step']: entry for entry in result['trace']}
            cadence = result['config']
            for event in result['commands']:
                self.check(event['atMs'] > previous_time, scope, 'Command timestamps are not strictly increasing')
                if previous_time >= 0:
                    self.check(event['atMs'] - previous_time + EPSILON >= cadence['actionIntervalMs'],
                               scope, 'Input cadence violated')
                previous_time = event['atMs']
                entry = entries[event['step']]
                self.check(event['atMs'] + EPSILON >= entry['spawnAtMs'] + cadence['reactionMs'],
                           scope, 'Spawn reaction delay violated')
                self.check(event['atMs'] <= result['stoppedAtSeconds'] * 1000 + EPSILON,
                           scope, 'Command occurs after the recorded stop')
                if entry.get('lockAtMs') is not None:
                    self.check(event['atMs'] <= entry['lockAtMs'] + EPSILON, scope, 'Command occurs after its piece locked')
            counters = result['counters']
            self.check(counters['automaticLocks'] == sum(entry.get('lockSource') == 'automatic'
                       for entry in result['trace']), scope, 'Automatic-lock count mismatch')
            self.check(counters['rejectedInputs'] == sum(not event['accepted'] and not event['legalStop']
                       for event in result['commands']), scope, 'Rejected-input count mismatch')
            self.check(counters['groundedStops'] == sum(bool(event['legalStop']) for event in result['commands']),
                       scope, 'Grounded-stop count mismatch')
            self.check(result['plannerWallTimeChargedToSimulation'] is False
                       and result['realtimePlanningFeasibility'] == 'unverified', scope, 'Timing qualification was overstated')
        return completed

    def quality(self, result, task, initial):
        scope = task['id']
        metrics = result.get('metrics')
        if not metrics:
            return {'qualifiedMastery': False, 'unavailable': True}
        stage = task['stage']
        timed = stage in ('online', 'replay-online')
        top_out = bool(result.get('topOut')) or result.get('reason') in ('top-out', 'showcase-top-out')
        bonuses = [bonus_met(bonus, metrics, top_out) if timed or bonus['type'] != 'time' else False
                   for bonus in initial['victory'].get('bonuses', [])]
        tiers = {tier: tier_met(initial['stars'][tier], metrics, bonuses, timed)
                 for tier in ('one', 'two', 'three')}
        quality = result['quality']
        requirements = result.get('requirements', {})
        for tier in ('one', 'two', 'three'):
            self.check(requirements.get('stars', {}).get(tier, {}).get('conditions') == initial['stars'][tier],
                       scope, 'Reported star requirements differ from frozen authored conditions: ' + tier)
        primary_definition = requirements.get('primary', {})
        self.check(all(primary_definition.get(key) == value for key, value in initial['victory']['primary'].items()),
                   scope, 'Reported primary requirements differ from frozen authored conditions')
        primary = bool(quality.get('primaryReachedUntimed')) if stage == 'search' else bool(result['primaryReached'])
        reached_piece = result.get('primaryReachedAtPiece')
        self.check(primary == (reached_piece is not None), scope, 'Primary flag and acquisition piece disagree')
        if primary:
            matching = [entry for entry in result['trace'] if entry.get('completed')
                        and entry['metricsAfter']['piecesPlaced'] == reached_piece]
            self.check(len(matching) == 1, scope, 'Acquisition piece is not one completed recorded lock')
            if matching:
                acquisition = matching[0]
                self.check(acquisition['metricsAfter']['score'] >= initial['victory']['primary']['target'],
                           scope, 'Primary acquired below the authored score goal')
                if timed:
                    at = result['goalReachedAtSeconds']
                    self.check(at + EPSILON >= acquisition['resolvedAtMs'] / 1000,
                               scope, 'Primary acquired before physics resolved')
                    failure = initial['victory'].get('failure', {})
                    if failure.get('type') == 'time':
                        self.check(at <= failure['value'] + EPSILON, scope, 'Primary acquired after its deadline')
            if initial['victoryLapPolicy'] != 'showcase':
                self.check(metrics['piecesPlaced'] == reached_piece, scope, 'Ordinary orb continued after primary finish')
        if stage == 'search':
            self.check(quality['tierThreeUntimedConditionsMet'] == tiers['three'], scope, 'Search tier-three mismatch')
            self.check(quality['masteryUntimedConditionsMet'] == qualify(result, stage, primary, tiers['three']),
                       scope, 'Search mastery qualifier mismatch')
            self.check(quality['timedStars'] is None, scope, 'Untimed search awards timed stars')
            self.check(result['status'] == ('candidate' if qualify(result, stage, primary, tiers['three']) else 'inconclusive'),
                       scope, 'Search status overstates qualification')
        else:
            for tier, met in tiers.items():
                self.check(quality['tiers'][tier]['conditionsMet'] == met, scope, 'Raw tier predicate mismatch: ' + tier)
            self.check(quality['tierThreeConditionsMet'] == tiers['three'], scope, 'Tier-three aggregate mismatch')
            self.check(quality['masteryConditionsMet'] == (primary and tiers['three']),
                       scope, 'Observed mastery conjunction mismatch')
            stars = max([0] + [index for index, tier in enumerate(('one', 'two', 'three'), 1) if tiers[tier]])
            self.check(quality['timedStars'] == (stars if timed else None), scope, 'Raw star count mismatch')
            self.check(quality['censored'] == bool(result.get('qualityCensored')), scope, 'Censoring flags disagree')
            if stage in ('online', 'replay-online'):
                budget_stop = result.get('reason') in BUDGET_REASONS
                if budget_stop:
                    self.check(result['outcome'] == ('win' if primary else 'censored'), scope, 'Budget outcome misclassified')
                    self.check(result['qualityCensored'] == primary, scope, 'Post-primary budget quality censoring mismatch')
                if result.get('outcome') == 'win':
                    self.check(primary, scope, 'Win without acquired primary')
            for index, bonus in enumerate(initial['victory'].get('bonuses', [])):
                expected = bonuses[index] if timed or bonus['type'] != 'time' else None
                self.check(quality['optionalBonuses'][index]['conditionMet'] == expected,
                           scope, 'Optional bonus predicate mismatch: ' + bonus['type'])
        return {'primaryReached': primary, 'rawTierThreeConditionsMet': tiers['three'],
                'qualificationScope': {'search': 'untimed-search-candidate', 'replay': 'independent-untimed-replay',
                                       'online': 'raw-online-observation-only',
                                       'replay-online': 'independent-timed-timestamp-replay'}[stage],
                'qualityCensored': bool(result.get('qualityCensored')),
                'qualifiedMastery': qualify(result, stage, primary, tiers['three']),
                'rawStars': quality.get('timedStars'), 'allOptionalBonusesMet': all(bonuses)}

    def task(self, task, execution, registration):
        scope = task['id']
        output = task['output']
        if execution.get('status') == 'not executed':
            self.results.append({'id': scope, 'stage': task['stage'], 'invocation': 'not executed',
                                 'reason': execution.get('reason'), 'qualifiedMastery': False})
            return
        self.check(execution.get('exitCode') == 0, scope, 'Invocation did not exit successfully')
        config = self.read(output + '/config.json')
        summary = self.read(output + '/summary.json')
        freeze = registration['sourceFreeze']
        for container in (config, summary):
            self.check(container['revision']['sourceHash'] == freeze['sourceHash'], scope, 'Invocation source differs from freeze')
            self.check(container['revision']['head'] == freeze['commit'], scope, 'Invocation commit differs from freeze')
            self.check(container['revision']['runtime'] == freeze['runtime'], scope, 'Invocation runtime differs from freeze')
        self.check(config['options'] == task['expectedOptions'], scope, 'Executed configuration differs from registration')
        self.check(summary['status'] == 'completed' and summary['sourceStable'] is True, scope, 'Invocation provenance invalid')
        self.check(self.read(output + '/source-manifest.json') == self.manifest, scope, 'Invocation manifest differs')
        self.check(digest(self.read_bytes(output + '/source.patch')) == freeze['sourcePatch']['sha256'],
                   scope, 'Invocation source patch differs')
        filename = FILENAMES[task['stage']]
        data = self.read_bytes(output + '/' + filename)
        self.check(summary['result'] == {'path': filename, 'bytes': len(data), 'sha256': digest(data)},
                   scope, 'Result content digest differs from summary')
        result = json.loads(data)
        self.check(result.get('levelId') == task['levelId'] and result.get('seed') == task['seed'], scope, 'Result identity mismatch')
        initial = self.initial[(task['levelId'], task['seed'])]
        if 'initialBoardHash' in result:
            self.check(result['initialBoardHash'] == initial['hash'], scope, 'Authored initial board hash mismatch')
        if task['stage'] == 'search':
            self.check(result['initialBoard']['occupiedCells'] == initial['cells'], scope, 'Authored initial inventory mismatch')
            self.check(result['budgets']['setupStrategy'] == 'structural-v1', scope, 'Structural preference was not selected')
        if task['stage'] in ('online', 'replay-online'):
            self.check(result['config']['setupStrategy'] == 'none', scope, 'Online arm used structural preference')
        if task['stage'] in ('replay', 'replay-online'):
            online = task['stage'] == 'replay-online'
            parent_name = task['witness' if online else 'candidate']
            parent_data = self.read_bytes(parent_name)
            input_name = 'input-witness.json' if online else 'input-candidate.json'
            self.check(self.read_bytes(output + '/' + input_name) == parent_data, scope, 'Copied replay input differs from parent')
            self.check(config['witnessSha256' if online else 'candidateSha256'] == digest(parent_data),
                       scope, 'Replay parent digest mismatch')
            parent = json.loads(parent_data)
            if online:
                actual = {key: result.get(key) for key in PROJECTION_KEYS}
                expected = {key: parent.get(key) for key in PROJECTION_KEYS}
                self.check(actual == expected, scope, 'Timestamp execution projection differs from recorded witness')
                self.check(result.get('replayValid') is True and result.get('traceComplete') is True,
                           scope, 'Timestamp replay did not validate completely')
                # Use only Node's JSON serialization, not any application replay/analyzer code.
                script = "const c=require('node:crypto');let s='';process.stdin.on('data',x=>s+=x);process.stdin.on('end',()=>console.log(c.createHash('sha256').update(JSON.stringify(JSON.parse(s))).digest('hex')));"
                calculated = subprocess.run(['node', '-e', script], input=json.dumps(actual, separators=(',', ':')),
                                            text=True, capture_output=True, check=True).stdout.strip()
                self.check(calculated == result.get('actualExecutionHash') == result.get('expectedExecutionHash'),
                           scope, 'Independent timestamp projection digest mismatch')
            else:
                self.check(result.get('replayValid') is True and result.get('traceComplete') is True,
                           scope, 'Untimed construction replay is incomplete or invalid')
                self.check(len(result['trace']) == len(parent['trace']), scope, 'Construction replay length mismatch')
                for before, after in zip(parent['trace'], result['trace']):
                    equal = all(before.get(key) == after.get(key) for key in
                                ('step', 'shapeKey', 'preview', 'boardHashBefore', 'boardHashAfter', 'metricsAfter'))
                    self.check(equal and pose(before.get('lockedPiece')) == pose(after.get('lockedPiece')),
                               scope, 'Construction replay geometry/metrics mismatch at piece ' + str(before['step']))
        completed = self.metrics(result, task, initial)
        quality = self.quality(result, task, initial)
        self.results.append({'id': scope, 'stage': task['stage'], 'levelId': task['levelId'], 'seed': task['seed'],
                             'cadence': task.get('cadence'), 'invocation': 'completed', 'completedLocks': completed,
                             'metrics': result.get('metrics'), 'termination': result.get('termination'),
                             'outcome': result.get('outcome'), 'reason': result.get('reason'),
                             'traceValid': result.get('traceValid'), 'replayValid': result.get('replayValid'),
                             **quality})

    def run(self):
        registration = self.read('registration.json')
        self.freeze(registration)
        planned = Counter(task['stage'] for task in registration['tasks'])
        self.check(dict(planned) == {'search': 9, 'replay': 9, 'online': 18, 'replay-online': 18},
                   'registration', 'Expected four stage counts totaling 54')
        self.check(dict(planned) == registration['plannedCounts'], 'registration', 'Declared task counts differ')
        self.check({task['seed'] for task in registration['tasks']} == {9101, 9102, 9103},
                   'registration', 'Unexpected or confirmation seed')
        execution = self.read('execution.json')
        by_id = {record['id']: record for record in execution}
        self.check(len(by_id) == len(execution) == 54, 'execution', 'Execution has missing/duplicate records')
        self.check(set(by_id) == {task['id'] for task in registration['tasks']}, 'execution', 'Execution task set differs')
        for task in registration['tasks']:
            try:
                self.task(task, by_id[task['id']], registration)
            except Exception as error:
                self.errors.append({'scope': task['id'], 'message': type(error).__name__ + ': ' + str(error)})
        return {
            'schemaVersion': 1,
            'kind': 'independent-raw-result-audit',
            'auditScriptSha256': digest(Path(__file__).read_bytes()),
            'registrationSha256': self.input_hashes['registration.json'],
            'sourceHash': registration['sourceFreeze']['sourceHash'],
            'allChecksPassed': not self.errors,
            'plannedCounts': dict(planned),
            'auditedCounts': dict(Counter(record['stage'] for record in self.results)),
            'completedLockConservationChecks': self.lock_checks,
            'recordedCommandChecks': self.command_checks,
            'initialBoardsIndependentlyReconstructed': list(self.initial.values()),
            'qualifiedMasteryCounts': dict(Counter(record['stage'] for record in self.results if record.get('qualifiedMastery'))),
            'records': self.results,
            'errors': self.errors,
            'inputHashes': dict(sorted(self.input_hashes.items())),
            'limitations': [
                'Development seeds only; no human calibration, confirmation, balance adoption or real-time CPU feasibility claim.',
                'Geometry/score are compared against independently executed replay files; this audit does not run a third physics replay.',
                'Completed-lock conservation is checked against separately reconstructed authored inventory; intermediate boards are represented by recorded hashes.',
                'Raw tier-three metrics and primary wins remain separate from uncensored, valid, complete mastery witnesses.',
                'Online records are raw observations here; only their independently checked timestamp replays can qualify a timed witness.',
                'Matching three previews in a static trace alone cannot certify the planner information boundary.',
            ],
        }


def self_test():
    metrics = {'score': 500000, 'cascades': 35, 'maxCombo': 18, 'maxCascadeDepth': 18, 'tetrises': 0}
    assert tier_met({'score': 500000, 'cascades': 35, 'combo': 18}, metrics, [False], False)
    assert not bonus_met({'type': 'tetris-count', 'target': 20}, metrics)
    result = {'replayValid': True, 'traceComplete': True, 'outcome': 'win', 'qualityCensored': True,
              'quality': {'censored': True}}
    assert not qualify(result, 'replay-online', True, True)
    result['qualityCensored'] = False
    result['quality']['censored'] = False
    assert qualify(result, 'replay-online', True, True)
    assert not qualify(result, 'replay-online', False, True)
    assert command_valid({'type': 'rotate', 'dir': 'flip'})
    assert not command_valid({'type': 'move', 'dir': 2})
    print('Independent audit self-tests passed; no campaign outcomes read.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--repository', type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument('--output', type=Path)
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return
    audit = Audit(args.root.resolve(), args.repository.resolve())
    result = audit.run()
    target = args.output or args.root / 'independent-result-audit.json'
    target.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({key: result[key] for key in ('allChecksPassed', 'auditedCounts',
                     'completedLockConservationChecks', 'recordedCommandChecks', 'qualifiedMasteryCounts')}))
    if result['errors']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
