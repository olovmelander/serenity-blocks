"""Reproduce descriptive diagnostics. No human-rate or inferential balance claims."""
import collections
import json
import math
from pathlib import Path
import statistics
import sys

ROOT = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent


def load_run(name, expected):
    folder = ROOT / name
    config = json.loads((folder / 'config.json').read_text())
    records = [json.loads(line) for line in (folder / 'raw.jsonl').read_text().splitlines() if line]
    assert len(records) == expected, (name, len(records), expected)
    keys = [key(row) for row in records]
    assert len(set(keys)) == expected, f'Duplicate attempts in {name}'
    expected_keys = {(level, profile, cadence, seed, scenario)
                     for level in config['levelIds'] for profile in config['profileIds']
                     for cadence in config['cadenceIds']
                     for seed in range(config['seedStart'], config['seedStart'] + config['samples'])
                     for scenario in config['scenarioIds']}
    assert set(keys) == expected_keys, f'Missing or unexpected attempts in {name}'
    return config, records


def key(row):
    return (row['levelId'], row['profileId'], row['cadenceId'], row['seed'], row['scenarioId'])


def distribution(values):
    values = sorted(values)
    if not values:
        return {'n': 0, 'median': None, 'p90': None}
    return {'n': len(values), 'median': statistics.median(values),
            'p90': values[math.ceil(0.9 * len(values)) - 1]}


def describe(rows):
    terminal = [r for r in rows if r['outcome'] in ('win', 'loss')]
    wins = [r for r in rows if r['outcome'] == 'win']
    return {
        'attempts': len(rows),
        'outcomes': dict(collections.Counter(r['outcome'] for r in rows)),
        'lossReasons': dict(collections.Counter(r['reason'] for r in rows if r['outcome'] == 'loss')),
        'qualityCensored': sum(bool(r.get('qualityCensored')) for r in rows),
        'winStars': dict(collections.Counter(r['stars'] for r in wins)),
        'terminalSeconds': distribution([r['elapsedSeconds'] for r in terminal]),
        'winSeconds': distribution([r['goalReachedAtSeconds'] for r in wins]),
        'rejectedInputs': sum(r.get('actions', {}).get('rejected', 0) for r in rows),
        'failedInputs': sum(r.get('telemetry', {}).get('failedActions', 0) for r in rows),
        'automaticLocks': sum(r.get('telemetry', {}).get('locks', {}).get('automatic', 0) for r in rows),
    }


before_config, before = load_run('orb6-before', 120)
after_config, after = load_run('orb6-after', 120)
for field in ('levelIds', 'profileIds', 'cadenceIds', 'seedStart', 'samples', 'maxSimSeconds',
              'maxPieces', 'wallBudgetMs', 'scenarios', 'effectiveLevels', 'lapWindowSeconds'):
    assert before_config[field] == after_config[field], f'Conditions differ: {field}'
assert before_config['revision']['runtime'] == after_config['revision']['runtime']
old = {key(row): row for row in before}
new = {key(row): row for row in after}
assert old.keys() == new.keys()
strata = []
for profile in before_config['profileIds']:
    for cadence in before_config['cadenceIds']:
        selected = [k for k in old if k[1:3] == (profile, cadence)]
        pairs = [(old[k], new[k]) for k in selected]
        def seeds(predicate):
            return [a['seed'] for a, b in pairs if predicate(a, b)]
        both_win = [(a, b) for a, b in pairs if a['outcome'] == b['outcome'] == 'win']
        strata.append({
            'profile': profile, 'cadence': cadence,
            'before': describe([a for a, b in pairs]), 'after': describe([b for a, b in pairs]),
            'gainedWins': seeds(lambda a, b: a['outcome'] == 'loss' and b['outcome'] == 'win'),
            'lostWins': seeds(lambda a, b: a['outcome'] == 'win' and b['outcome'] != 'win'),
            'lowerStarsAmongBothWins': [a['seed'] for a, b in both_win if b['stars'] < a['stars']],
            'higherStarsAmongBothWins': [a['seed'] for a, b in both_win if b['stars'] > a['stars']],
            'pairedWinDurationDeltaSeconds': distribution([b['elapsedSeconds'] - a['elapsedSeconds'] for a, b in both_win]),
        })
summary = {
    'interpretation': 'Descriptive matched diagnostic cohorts; p90 is nearest-rank; no human difficulty, statistical efficacy or population non-inferiority claim.',
    'orb6': {'beforeRevision': before_config['revision'], 'afterRevision': after_config['revision'],
             'before': describe(before), 'after': describe(after), 'strata': strata},
}
for name, expected in [('ch6-rhythm', 80), ('duel-production', 24)]:
    config, rows = load_run(name, expected)
    if name == 'duel-production':
        assert all(r.get('humanPlanningPreviewLimit') == 3
                   and r.get('opponentKnowledgePolicy') == 'production-full-real-bag'
                   and r.get('opponentPlanningPreviewLimit') is None
                   and r.get('opponentPreviewCount') is None for r in rows)
    summary[name] = {'status': 'completed', 'revision': config['revision'],
                     'orbs': [{'levelId': level, **describe([r for r in rows if r['levelId'] == level])}
                              for level in config['levelIds']]}
(ROOT / 'analysis.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
