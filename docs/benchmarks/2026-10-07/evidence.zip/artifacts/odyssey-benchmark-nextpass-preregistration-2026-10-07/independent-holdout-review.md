# Independent Orb 59 holdout review

**Recommendation: adopt only Orb 59's primary acquisition deadline of 210 seconds.**
The fresh holdout passes the registered primary effect, mechanism, coverage, corrected
test and expert win-preservation gates. Keep the 160,000 score target, all authored
bonus/star requirements, board, scoring, progression and manual showcase behavior.
This is evidence about the declared synthetic policies, not a human completion estimate
or a qualified assessment of higher-star fairness.

The nomination was frozen at 14:09:41.236 UTC before holdout outcomes were opened.
Its SHA-256 remains `35ae3dbcdb883bf95eb9042769d16f49eb81b4e5b912eff554ace1d945225fe7`.
This confirmation uses only seeds 5001-5100; the 20-seed screen is not pooled into it.

## Fresh paired results

| Steady policy | Baseline wins / 100 | 210-second wins / 100 | Favorable / adverse pairs | Paired gain |
| --- | ---: | ---: | ---: | ---: |
| Cascade, registered primary | 9 | 59 | 50 / 0 | +50 percentage points |
| Expert, separate preservation | 27 | 88 | 61 / 0 | +61 percentage points |

All 400 expected records are unique and terminal: 183 wins, 217 losses, no missing or
unexpected keys, no errors, no primary censors and no quality caps. Each policy has
100/100 resolved pairs, exceeding the registered 95% requirement. There is no unresolved
outcome bound to widen: the primary all-planned gain bounds are exactly [+0.50, +0.50].

All 50 favorable Cascade pairs were baseline deadline losses. Their candidate attempts
settled the 160,000 goal between 183.58 and 209.22 seconds, within the extended deadline.
The mechanism is additional primary acquisition time, rather than optional quality time.
All 183 recorded wins have a canonical goal score of at least 160,000 and an in-deadline
goal timestamp.

All 61 favorable Expert pairs were also baseline deadline losses. Of these, 57 acquired
the goal after 180 seconds; four acquired it earlier in the candidate configuration.
The same adaptive policy changes its hurry cost during the final 15 seconds of the
configured deadline (`profiles.mjs:469`), so paired trajectories need not remain identical
before the baseline deadline. Expert observations are preservation evidence, not an
additional primary significance sample.

## Registered test and gates

The primary exact one-sided paired binomial test has 50 favorable and zero adverse
discordances. Its upper tail is `1 / 2^50 = 8.881784197001252e-16`. The fixed Holm family
still contains three decisions; the unselected Orb 51 and Orb 4 hypotheses each retain
`p=1`. Orb 59 is first and passes `0.05/3 = 0.016666666666666666`; its Holm-adjusted
p-value is `2.6645352591003757e-15`. The second comparison fails and Holm stops.
No significance claim is made for Expert preservation, stars or robustness strata.

| Registered gate | Result |
| --- | --- |
| Zero errors; at least 95% resolved paired coverage | Pass: zero errors, 100% coverage |
| Relevant canonical mechanics and settled primary boundary | Pass |
| Primary paired gain at least 10 percentage points | Pass: +50 points |
| Baseline deadline-loss conversion mechanism | Pass: all 50 primary improvements, with late in-deadline candidate goals |
| Fixed-family Holm rejection | Pass |
| Expert observed win decline no greater than five points | Pass: +61 points, no lost baseline wins |
| Observed complete matched-win star degradation | None: nine Cascade and 27 Expert pairs retain one star |
| Qualified higher-star fairness | Inconclusive; no claim or requirement change |

The helper's known-value exact-tail, quantile and Holm stopping checks pass. A separate
manual raw-record audit reproduces the paired counts, deadline conversions, canonical
win boundaries and star denominators.

## Quality qualifications

All winning attempts earn one star. Both profiles have zero observed two-star and
three-star attainment under both configurations. The matched complete-win comparisons
have zero change in either higher-star rate, but this is not formal non-inferiority and
does not qualify the higher-star guard: validated construction reaches depth three,
below the relevant authored targets.

The authored fields remain distinct: two stars require score 200,000, 20 cascades and
combo 10; three require score 260,000, 25 cascades, explicit cascade depth seven and
combo 12. Current physics supplies the cascade wave count to `triggerCombo`, so the
combo targets also demand deeper chains in the current evaluator. Do not rename the
explicit depth-seven requirement to ten or twelve, and do not lower any requirement
because these policies lack validated construction at those targets.

The benchmark stops showcase quality at the scenario deadline. The live mode keeps a
completed showcase available until manual finish or top-out, including after its timer
reaches zero. Consequently, the primary acquisition comparison applies to the live
deadline; these benchmark star outcomes do not establish live higher-star availability
or justify adding an automatic showcase cutoff.

## Frozen scope and exclusions

The measured configuration matches the nomination exactly: Orb 59, Cascade/Expert,
steady cadence, baseline/210-second scenarios, seeds 5001-5100, six workers, 240,000 ms
wall budget, 1,800 simulated seconds, 3,000 pieces, `lapWindowSeconds:null`, and three
visible previews. The two effective level configurations differ only in
`victory.failure.value`, 180 versus 210.

The recorded measurement uses HEAD `d14b1c2364fdc0916e65ab930b164ab4213f0767`, benchmark
SHA-256 `4950a5b552e84c8a0778e589d6d3c80ecb3de4ce5c214b65e3370a8fa7d57631`, and application
SHA-256 `259ef02511db27892ca3812be676b45518b261d5cbc910b8daad4369b930f407`, with Node
24.14.0 on Windows x64. All saved snapshot file fingerprints pass. Replacing only the
current adopted `levels.js` with its saved pre-adoption bytes reconstructs the recorded
application hash exactly. The parent also completed a successful historical-source
resume that added zero attempts before adoption.

After measurement, resume verification, passing review and UI validation, the parent
applied the live Orb 59 deadline override. The current application hash
`c71cd90b4900de20d5dd52b906f06c68c39e28ba13cdf3fb1417c8825d0512ed` is therefore a separate
post-holdout revision, not the historical run hash. The saved production scope check
compares all 59 composed levels and attributes only the deadline change.

The 240-second variant remains excluded because 210 was the smallest qualifying screen
candidate. It was not tested in this holdout and is not recommended. Orb 51 gravity and
Orb 4 duel pacing remain excluded after failing their registered screen gates; keep their
authored rules. This evidence does not support wider campaign tuning, pooled cadence
claims, or claims about human enjoyment or completion rates.

Machine-readable evidence:

- [Independent completed analysis](independent-holdout-analysis.json)
- [Manual gate and source audit](independent-holdout-gate-audit.json)
- [Frozen nomination](nominations.json)
- [Primary/live-runtime fidelity audit](../odyssey-benchmark-orb59-holdout-2026-10-07/primary-runtime-fidelity.md)
- [Post-holdout production scope check](../odyssey-benchmark-orb59-holdout-2026-10-07/production-scope-verification.json)

The independent analysis wrote only these registration artifacts; run data, nomination,
benchmark source and production source were not modified by this review.
