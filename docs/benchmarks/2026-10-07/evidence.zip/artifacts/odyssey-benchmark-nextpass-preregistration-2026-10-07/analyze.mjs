/**
 * Independent reader for the frozen Odyssey experiment. It never writes run data.
 * Usage: node analyze.mjs coverage <run-dir>
 *        node analyze.mjs screen <run-dir> --completed
 *        node analyze.mjs holdout <run-dir> --completed --nominations <json>
 *        node analyze.mjs verify-math
 * Redirect completed analysis output into this preregistration artifact directory.
 */
import { readFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const ownDirectory = dirname(fileURLToPath(import.meta.url));
const readJson = (path) => JSON.parse(readFileSync(path, 'utf8'));
const terminal = (attempt) => ['win', 'loss'].includes(attempt?.outcome);
const win = (attempt) => attempt?.outcome === 'win';
const identity = (attempt) => [attempt.levelId, attempt.profileId, attempt.scenarioId, attempt.cadenceId, attempt.seed].join(':');
const qualityComplete = (attempt) => win(attempt) && !attempt.lapCensored && !attempt.qualityCensored;
const sum = (items, getter) => items.reduce((total, item) => total + Number(getter(item) || 0), 0);

export function median(values) {
    const sorted = values.filter(Number.isFinite).sort((a, b) => a - b);
    if (!sorted.length) return null;
    const middle = Math.floor(sorted.length / 2);
    return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
}

export function p90(values) {
    const sorted = values.filter(Number.isFinite).sort((a, b) => a - b);
    return sorted.length ? sorted[Math.ceil(0.9 * sorted.length) - 1] : null;
}

/** Exact upper Binomial(n,0.5) tail; holdout n is at most 100. */
export function pairedBinomial(favorable, unfavorable) {
    const n = favorable + unfavorable;
    if (![favorable, unfavorable].every((value) => Number.isInteger(value) && value >= 0)) {
        throw new TypeError('Discordance counts must be nonnegative integers');
    }
    if (!n) return 1;
    let mass = 2 ** (-n);
    let tail = favorable === 0 ? mass : 0;
    for (let k = 1; k <= n; k++) {
        mass *= (n - k + 1) / k;
        if (k >= favorable) tail += mass;
    }
    return Math.min(1, tail);
}

export function holmThree(tests) {
    if (tests.length !== 3) throw new Error('The registered family contains exactly three tests');
    const sorted = tests.map((test) => ({ ...test })).sort((a, b) => a.pValue - b.pValue || a.id.localeCompare(b.id));
    let stopped = false;
    return sorted.map((test, index) => {
        const threshold = 0.05 / (3 - index);
        const rejected = !stopped && test.pValue <= threshold;
        if (!rejected) stopped = true;
        return { ...test, rank: index + 1, threshold, rejected };
    });
}

function loadRun(directory, completed) {
    const config = readJson(resolve(directory, 'config.json'));
    const capabilities = readJson(resolve(directory, 'capabilities.json'));
    const lines = readFileSync(resolve(directory, 'raw.jsonl'), 'utf8').split(/\r?\n/);
    const attempts = [];
    let ignoredPartialTail = false;
    lines.forEach((line, index) => {
        if (!line.trim()) return;
        try { attempts.push(JSON.parse(line)); }
        catch (error) {
            if (!completed && index === lines.length - 1) ignoredPartialTail = true;
            else throw new Error('Invalid raw JSONL line ' + (index + 1) + ': ' + error.message);
        }
    });
    const cells = new Map();
    const expected = new Set();
    for (const { level, scenarioId } of config.effectiveLevels) {
        for (const profileId of config.profileIds) {
            for (const cadenceId of config.cadenceIds) {
                const label = [level.id, profileId, scenarioId, cadenceId].join(':');
                if (cells.has(label)) throw new Error('Duplicate configured cell ' + label);
                cells.set(label, { levelId: level.id, profileId, scenarioId, cadenceId, attempts: [] });
                for (let index = 0; index < config.samples; index++) {
                    expected.add(identity({ levelId: level.id, profileId, scenarioId, cadenceId, seed: config.seedStart + index }));
                }
            }
        }
    }
    const seen = new Set();
    const duplicateKeys = [];
    const unexpectedKeys = [];
    for (const attempt of attempts) {
        const key = identity(attempt);
        if (seen.has(key)) duplicateKeys.push(key);
        seen.add(key);
        if (!expected.has(key)) unexpectedKeys.push(key);
        cells.get([attempt.levelId, attempt.profileId, attempt.scenarioId, attempt.cadenceId].join(':'))?.attempts.push(attempt);
    }
    const missingKeys = [...expected].filter((key) => !seen.has(key));
    const coverage = {
        expected: expected.size, received: attempts.length, unique: seen.size,
        completed: !missingKeys.length && !duplicateKeys.length && !unexpectedKeys.length && !ignoredPartialTail,
        duplicateKeys, unexpectedKeys, missingCount: missingKeys.length, ignoredPartialTail,
        errors: attempts.filter((attempt) => attempt.outcome === 'error').length,
        unresolved: attempts.filter((attempt) => !terminal(attempt)).length,
        cells: [...cells.values()].map((cell) => ({
            levelId: cell.levelId, profileId: cell.profileId, scenarioId: cell.scenarioId, cadenceId: cell.cadenceId,
            received: cell.attempts.length, planned: config.samples,
            terminal: cell.attempts.filter(terminal).length,
            errors: cell.attempts.filter((attempt) => attempt.outcome === 'error').length,
        })),
    };
    if (expected.size !== config.plannedAttempts) throw new Error('Configured planned-attempt count is inconsistent');
    if (completed && !coverage.completed) throw new Error('Refusing decisions on incomplete, duplicated or unexpected raw data');
    return { config, capabilities, attempts, cells, coverage };
}

function checkFreeze(config, registration) {
    const issues = [];
    const frozen = registration.implementationSnapshot;
    for (const key of ['benchmarkHash', 'applicationHash']) {
        if (config.revision?.[key] !== frozen[key]) issues.push('Frozen ' + key + ' differs');
    }
    if (config.revision?.head !== frozen.gitHead) issues.push('Frozen HEAD differs');
    for (const key of ['maxSimSeconds', 'maxPieces', 'wallBudgetMs', 'lapWindowSeconds']) {
        if (config[key] !== registration.execution[key]) issues.push('Registered ' + key + ' differs');
    }
    if (config.visiblePreviews !== registration.execution.visibleUpcomingPieces) issues.push('Preview knowledge differs');
    return issues;
}

function distribution(values) {
    const measured = values.filter(Number.isFinite);
    return { n: measured.length, median: median(measured), p90: p90(measured) };
}

function uncreditedShare(attempts) {
    const players = attempts.flatMap((attempt) => attempt.duel?.telemetry?.players || []);
    const deaths = sum(players, (player) => player.deaths);
    return deaths ? sum(players, (player) => player.uncreditedDeaths) / deaths : null;
}

function executionSummary(attempts) {
    const failedMoves = sum(attempts, (attempt) => ['moveLeft', 'moveRight', 'rotateLeft', 'rotateRight', 'rotateFlip']
        .reduce((total, key) => total + Number(attempt.actions?.byAction?.[key]?.failed || 0), 0));
    const automatic = sum(attempts, (attempt) => attempt.telemetry?.locks?.automatic);
    const pieces = sum(attempts, (attempt) => attempt.pieces);
    return {
        pieces, failedMovesAndRotations: failedMoves, automaticLocks: automatic,
        failedMovesPerPiece: pieces ? failedMoves / pieces : null,
        automaticLocksPerPiece: pieces ? automatic / pieces : null,
        replans: sum(attempts, (attempt) => attempt.telemetry?.policy?.replans),
        fallbackDrops: sum(attempts, (attempt) => attempt.telemetry?.policy?.fallbackDrops),
    };
}

function qualityEvidence(level, profileId, capabilities) {
    const profile = capabilities.profiles?.find((entry) => entry.profileId === profileId);
    const tiers = ['two', 'three'].map((tier) => {
        const stars = level.stars[tier] || {};
        const requiredCascadeDepth = stars.maxCascadeDepth || 0;
        const requiredCombo = stars.combo || 0;
        const demonstrated = (target) => target < 5 || (profile?.construction?.targets || [])
            .some((entry) => entry.targetDepth >= target && entry.status === 'pass');
        const cascadeConstructionQualified = demonstrated(requiredCascadeDepth);
        // Current physics passes cascadeCount through triggerCombo into maxCombo.
        // Keep the authored combo requirement separate from maxCascadeDepth.
        const comboCapabilityQualified = demonstrated(requiredCombo);
        return {
            tier, requiredCascadeDepth, requiredCombo, cascadeConstructionQualified,
            comboCapabilityQualified,
            constructionQualified: cascadeConstructionQualified && comboCapabilityQualified,
        };
    });
    return {
        relevantMechanicsPassed: capabilities.mechanics?.status === 'pass' && profile?.status === 'pass',
        validatedConstructionDepth: profile?.construction?.validatedMaxCascadeDepth ?? null,
        comboMetricSemantics: 'Current triggerCombo(cascadeCount) is recorded as maxCombo; this does not rename the authored maxCascadeDepth requirement.',
        tiers,
        qualityQualified: tiers.every((tier) => tier.constructionQualified),
    };
}

function cellSummary(cell, run) {
    const attempts = cell.attempts;
    const level = run.config.effectiveLevels.find((entry) => entry.level.id === cell.levelId
        && entry.scenarioId === cell.scenarioId).level;
    const outcomes = Object.fromEntries(['win', 'loss', 'censored', 'error']
        .map((outcome) => [outcome, attempts.filter((attempt) => attempt.outcome === outcome).length]));
    const reasons = {};
    const consistencyIssues = [];
    for (const attempt of attempts) {
        reasons[attempt.reason] = (reasons[attempt.reason] || 0) + 1;
        const duel = attempt.duel?.telemetry;
        if (!duel) continue;
        const elapsed = duel.activeSeconds + duel.resolutionSeconds + duel.intermissionSeconds;
        if (Math.abs(elapsed - attempt.elapsedSeconds) > 1e-6) {
            consistencyIssues.push({ seed: attempt.seed, issue: 'Duel time phases do not sum to elapsedSeconds' });
        }
        duel.players.forEach((player, index) => {
            if (player.creditedDeaths + player.uncreditedDeaths !== player.deaths) {
                consistencyIssues.push({ seed: attempt.seed, player: index, issue: 'Death credit totals differ' });
            }
            for (const key of ['attacksSent', 'attackLinesSent', 'cleanLinesSent',
                'attacksReceived', 'attackLinesReceived', 'cleanLinesReceived', 'frags', 'deaths']) {
                if (sum(duel.rounds, (round) => round.players[index][key]) !== player[key]) {
                    consistencyIssues.push({ seed: attempt.seed, player: index, issue: 'Round deltas differ for ' + key });
                }
            }
        });
    }
    return {
        levelId: cell.levelId, profileId: cell.profileId, scenarioId: cell.scenarioId, cadenceId: cell.cadenceId,
        role: level.role, primary: level.victory.primary, failure: level.victory.failure,
        outcomes, reasons,
        primaryTerminalCoverage: attempts.filter(terminal).length / run.config.samples,
        stars: Object.fromEntries([1, 2, 3].map((star) => [star, attempts.filter((attempt) => win(attempt) && attempt.stars === star).length])),
        qualityCensored: attempts.filter((attempt) => attempt.lapCensored || attempt.qualityCensored).length,
        qualityEvidence: qualityEvidence(level, cell.profileId, run.capabilities),
        goalTimes: distribution(attempts.filter((attempt) => attempt.goalReached).map((attempt) => attempt.goalReachedAtSeconds)),
        elapsedSeconds: distribution(attempts.filter(terminal).map((attempt) => attempt.elapsedSeconds)),
        metrics: Object.fromEntries(['lines', 'score', 'cascades', 'maxCascadeDepth', 'maxCombo', 'tetrises']
            .map((key) => [key, distribution(attempts.filter((attempt) => attempt.outcome !== 'error').map((attempt) => attempt.metrics[key]))])),
        execution: executionSummary(attempts),
        uncreditedDeathShare: uncreditedShare(attempts),
        consistencyIssues,
    };
}

function compare(run, decision, scenarioId, profileId, cadenceId) {
    const get = (scenario) => run.cells.get([decision.levelId, profileId, scenario, cadenceId].join(':'))?.attempts || [];
    const baseline = get('baseline');
    const candidate = get(scenarioId);
    const a = new Map(baseline.map((attempt) => [attempt.seed, attempt]));
    const b = new Map(candidate.map((attempt) => [attempt.seed, attempt]));
    const pairs = Array.from({ length: run.config.samples }, (_, index) => {
        const seed = run.config.seedStart + index;
        return { seed, a: a.get(seed), b: b.get(seed) };
    });
    const resolved = pairs.filter((pair) => terminal(pair.a) && terminal(pair.b));
    const bothWin = resolved.filter((pair) => win(pair.a) && win(pair.b));
    const completeQuality = bothWin.filter((pair) => qualityComplete(pair.a) && qualityComplete(pair.b));
    const improved = resolved.filter((pair) => !win(pair.a) && win(pair.b));
    const harmed = resolved.filter((pair) => win(pair.a) && !win(pair.b));
    const durationA = bothWin.map((pair) => pair.a.elapsedSeconds);
    const durationB = bothWin.map((pair) => pair.b.elapsedSeconds);
    const faster = bothWin.filter((pair) => pair.b.elapsedSeconds < pair.a.elapsedSeconds - 1e-7).length;
    const slower = bothWin.filter((pair) => pair.b.elapsedSeconds > pair.a.elapsedSeconds + 1e-7).length;
    const rateDifference = (getter, population) => population.length
        ? (sum(population, (pair) => getter(pair.b)) - sum(population, (pair) => getter(pair.a))) / population.length : null;
    const baselineUncredited = uncreditedShare(resolved.map((pair) => pair.a));
    const candidateUncredited = uncreditedShare(resolved.map((pair) => pair.b));
    const level = run.config.effectiveLevels.find((entry) => entry.level.id === decision.levelId && entry.scenarioId === 'baseline').level;
    return {
        decisionId: decision.id, levelId: decision.levelId, profileId, cadenceId, scenarioId,
        plannedPairs: pairs.length, resolvedPairs: resolved.length,
        coverage: resolved.length / pairs.length,
        errors: sum(pairs, (pair) => Number(pair.a?.outcome === 'error') + Number(pair.b?.outcome === 'error')),
        improvedSeeds: improved.map((pair) => pair.seed), harmedSeeds: harmed.map((pair) => pair.seed),
        deadlineConversions: improved.filter((pair) => pair.a.reason === 'deadline').length,
        netAdditionalWins: improved.length - harmed.length,
        winRateDifference: resolved.length ? (improved.length - harmed.length) / resolved.length : null,
        allPlannedGainBounds: [
            (improved.length - harmed.length - (pairs.length - resolved.length)) / pairs.length,
            (improved.length - harmed.length + (pairs.length - resolved.length)) / pairs.length,
        ],
        completeQualityPairs: completeQuality.length,
        qualityCensoredPairs: bothWin.length - completeQuality.length,
        atLeastTwoStarRateDifference: rateDifference((attempt) => Number(attempt.stars >= 2), completeQuality),
        threeStarRateDifference: rateDifference((attempt) => Number(attempt.stars >= 3), completeQuality),
        qualityEvidence: qualityEvidence(level, profileId, run.capabilities),
        duration: {
            bothWinPairs: bothWin.length, baseline: distribution(durationA), candidate: distribution(durationB),
            medianRatio: durationA.length ? median(durationB) / median(durationA) : null,
            p90Ratio: durationA.length ? p90(durationB) / p90(durationA) : null,
            fasterPairs: faster, slowerPairs: slower, tiedPairs: bothWin.length - faster - slower,
        },
        uncreditedDeathShare: {
            baseline: baselineUncredited, candidate: candidateUncredited,
            increase: baselineUncredited !== null && candidateUncredited !== null ? candidateUncredited - baselineUncredited : null,
        },
        execution: { baseline: executionSummary(baseline), candidate: executionSummary(candidate) },
        pairedWinPValue: pairedBinomial(improved.length, harmed.length),
        pairedDurationPValue: pairedBinomial(faster, slower),
        traceSeedsRequired: [...new Set([
            ...improved.map((pair) => pair.seed), ...harmed.map((pair) => pair.seed),
            ...pairs.slice(0, 5).map((pair) => pair.seed),
        ])].sort((left, right) => left - right),
    };
}

function screenChecks(comparison, decision, registration) {
    const eligible = comparison.errors === 0 && comparison.coverage >= registration.eligibility.minimumPairedTerminalCoverage
        && comparison.qualityEvidence.relevantMechanicsPassed;
    if (decision.levelId === 4) {
        return {
            eligible,
            durationEffectPass: comparison.duration.medianRatio !== null && comparison.duration.medianRatio <= 0.85
                && comparison.duration.p90Ratio <= 0.90,
            winPreservationPass: comparison.winRateDifference !== null && comparison.winRateDifference >= -0.05,
            uncreditedSharePass: comparison.uncreditedDeathShare.increase !== null && comparison.uncreditedDeathShare.increase <= 0.05,
        };
    }
    const counts = comparison.execution;
    const baselineBurden = counts.baseline.failedMovesAndRotations + counts.baseline.automaticLocks;
    return {
        eligible,
        primaryGainPass: comparison.netAdditionalWins >= decision.screen.minimumNetAdditionalPrimaryWins,
        deadlineConversionPass: decision.levelId !== 59 || comparison.deadlineConversions >= decision.screen.minimumNetAdditionalPrimaryWins,
        baselineExecutionBurdenPresent: decision.levelId !== 51 || baselineBurden > 0,
        gravityRejectedIfZeroBurden: decision.levelId === 51 && baselineBurden === 0,
        traceMechanismStatus: decision.levelId === 51 ? 'Requires independent review of the registered paired traces; counts alone do not prove causation.' : 'not-applicable',
    };
}

function completedAnalysis(run, registration, stage, nominations) {
    const freezeIssues = checkFreeze(run.config, registration);
    if (freezeIssues.length) throw new Error('Incompatible frozen run: ' + freezeIssues.join('; '));
    if (stage === 'screen') {
        const scope = registration.scope.focusedScreen;
        if (run.config.seedStart !== scope.seedStart || run.config.samples !== scope.samplesPerCell
            || run.config.plannedAttempts !== scope.expectedAttempts
            || JSON.stringify([...run.config.cadenceIds].sort()) !== JSON.stringify([...scope.cadenceIds].sort())
            || JSON.stringify([...run.config.profileIds].sort()) !== JSON.stringify([...scope.profileIds].sort())) {
            throw new Error('Run differs from the registered focused screen');
        }
    } else if (run.config.seedStart !== registration.scope.holdout.seedStart || run.config.samples !== 100) {
        throw new Error('Run differs from the reserved holdout seed range');
    }
    const decisions = registration.decisions.map((decision) => {
        const variants = stage === 'holdout'
            ? [nominations.decisions?.find((entry) => entry.id === decision.id)?.selectedScenario].filter(Boolean)
            : decision.priority;
        const comparisons = variants.map((scenarioId) => {
            if (!decision.priority.includes(scenarioId)) throw new Error('Unregistered candidate ' + scenarioId);
            const primary = compare(run, decision, scenarioId, 'cascade', 'steady');
            const expert = compare(run, decision, scenarioId, 'expert', 'steady');
            return {
                scenarioId, primary, expertPreservation: expert,
                quantitativeScreenChecks: stage === 'screen' ? screenChecks(primary, decision, registration) : null,
                expertWinPreservationPass: expert.winRateDifference !== null && expert.winRateDifference >= -0.05,
                qualityStatus: primary.qualityEvidence.qualityQualified && expert.qualityEvidence.qualityQualified
                    ? 'construction-qualified; inspect complete quality guards' : 'inconclusive-construction-at-authored-target',
            };
        });
        return { id: decision.id, priority: decision.priority, comparisons };
    });
    const tests = stage === 'holdout' ? holmThree(decisions.map((decision) => {
        const comparison = decision.comparisons[0]?.primary;
        return {
            id: decision.id,
            pValue: comparison ? (comparison.levelId === 4 ? comparison.pairedDurationPValue : comparison.pairedWinPValue) : 1,
        };
    })) : null;
    return {
        stage, revision: run.config.revision, coverage: run.coverage,
        cells: [...run.cells.values()].map((cell) => cellSummary(cell, run)),
        decisions, correctedPrimaryTests: tests,
        interpretation: stage === 'screen'
            ? 'Screening only. No holdout adoption decision or significance claim. Orb51 additionally requires reviewed traces; unvalidated deep quality remains inconclusive.'
            : 'Corrected tests alone do not authorize adoption: mechanism, effect, coverage, complete quality, preservation and duel-ladder scope guards still apply.',
    };
}

function verifyMath() {
    const close = (actual, expected) => {
        if (Math.abs(actual - expected) > 1e-12) throw new Error('Math verification failed: ' + actual + ' vs ' + expected);
    };
    close(pairedBinomial(5, 0), 1 / 32);
    close(pairedBinomial(0, 5), 1);
    close(pairedBinomial(0, 0), 1);
    close(pairedBinomial(6, 4), 386 / 1024);
    close(median([1, 2, 3, 4]), 2.5);
    close(p90(Array.from({ length: 20 }, (_, index) => index + 1)), 18);
    const passing = holmThree([{ id: 'a', pValue: 0.01 }, { id: 'b', pValue: 0.024 }, { id: 'c', pValue: 0.04 }]);
    const stopping = holmThree([{ id: 'a', pValue: 0.017 }, { id: 'b', pValue: 0.02 }, { id: 'c', pValue: 0.021 }]);
    if (!passing.every((test) => test.rejected) || stopping.some((test) => test.rejected)) {
        throw new Error('Holm stopping verification failed');
    }
    return { status: 'verified', checks: ['exact-binomial-tails', 'no-discordance', 'median', 'nearest-rank-p90', 'Holm-sequence-and-stop'] };
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
    const [stage, directory, ...flags] = process.argv.slice(2);
    if (stage === 'verify-math') process.stdout.write(JSON.stringify(verifyMath(), null, 2) + '\n');
    else {
        if (!['coverage', 'screen', 'holdout'].includes(stage) || !directory) throw new Error('Use coverage|screen|holdout <run-dir>');
        const completed = flags.includes('--completed');
        if (stage !== 'coverage' && !completed) throw new Error('Outcome analysis requires explicit --completed acknowledgement');
        const run = loadRun(resolve(directory), completed);
        const registration = readJson(resolve(ownDirectory, 'preregistration.json'));
        if (stage === 'coverage') {
            process.stdout.write(JSON.stringify({ status: 'coverage-only-no-decisions', revision: run.config.revision,
                freezeIssues: checkFreeze(run.config, registration), ...run.coverage }, null, 2) + '\n');
        } else {
            const index = flags.indexOf('--nominations');
            if (stage === 'holdout' && index < 0) throw new Error('Holdout requires frozen --nominations JSON');
            const nominations = index >= 0 ? readJson(resolve(flags[index + 1])) : null;
            process.stdout.write(JSON.stringify(completedAnalysis(run, registration, stage, nominations), null, 2) + '\n');
        }
    }
}
