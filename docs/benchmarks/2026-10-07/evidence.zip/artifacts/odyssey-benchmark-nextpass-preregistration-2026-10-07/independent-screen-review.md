# Independent completed-screen review

The frozen screen contains all **440 unique expected attempts**: 380 wins, 60 gameplay
losses, no primary censors and no runtime errors. Registered hashes, seeds, strata,
budgets and preview policy match. Duel phase times, death credits and cumulative
round counters are internally consistent.

## Frozen nomination

**Nominate only `orb59-deadline210` for the fresh-seed primary holdout.**

| Registered decision | Cascade/steady result | Gate application |
| --- | --- | --- |
| Orb 59, 210 s | 1/20 baseline wins →8/20; seven deadline-loss conversions, no harmed pairs | Passes the registered four-net-win screen gate. Expert improves 9/20→18/20. |
| Orb 59, 240 s | 1/20→19/20; eighteen conversions, no harmed pairs | Excluded: 210 already qualifies, so smallest-qualifying priority controls selection. |
| Orb 51, 75 ms | 14/20→17/20; five improved and two harmed pairs, net +3 | Fails the registered +4 gate. |
| Orb 51, 100 ms | 14/20→16/20; four improved and two harmed pairs, net +2 | Fails the registered +4 gate. |
| Orb 4, 850 ms | Median/p90 matched-win duration reductions 0.47%/1.96% | Fails the registered 15%/10% gates. |
| Orb 4, 700 ms | Median/p90 reductions 1.34%/6.91% | Fails the registered 15%/10% gates. |

The orb-51 variants reduce measured rejected movements and automatic locks, but those
diagnostics cannot override failed quantitative eligibility. No orb-51 trace exercise
or rejected-duel fidelity run is needed for these decisions.

Selection was frozen at **2026-10-07T14:09:41.236Z**, before opening or starting holdout
observations, in [nominations.json](nominations.json). The fixed Holm family retains
orb-51 and duel-4 tests with p=1. No production adoption follows from a screen nomination.

## Star preservation and capability qualifications

For every compared variant, the complete matched both-win pairs show zero change in
cumulative at-least-two-star and three-star attainment for cascade and expert. Duel
cells are 20/20 three-star wins under every scenario. Orb-51 wins are two-star wins.

Orb 59 has only **one** complete baseline/candidate matched win for cascade and nine
for expert at 210 s. Each is one star under both scenarios. This passes the observed
five-point degradation guard but provides little information about higher-star quality
and is not a statistical non-inferiority claim.

The authored orb-59 two-star requirements include combo 10 and no explicit
`maxCascadeDepth` threshold; three stars require `maxCascadeDepth:7` plus combo 12.
These are separately labeled in the corrected independent analyzer. Current core
physics sends `cascadeCount` through `triggerCombo`, and HybridEngine records that
argument as `maxCombo`; this current runtime mapping does not rename the authored
stage-depth requirement as 12. Both policies' construction demonstrations peak at
three stages and do not qualify the authored higher-combo/deeper-cascade quality
claims. Those conclusions remain inconclusive; all star requirements remain intact.

The unchanged controls retain their authored boss role. Orb 46 has 19/20 cascade and
20/20 expert primary wins. Orb 55 has 20/20 primary wins for each policy, with no
three-star observation; its deep quality goals remain strategy-unqualified.

Two expert orb-55 quality laps still exhaust the 240000 ms wall budget: seed 2019 at
477.68 simulated seconds and seed 2020 at 342.03 seconds, both after valid primary
completion. Their wins remain valid; their final quality is censored. They cannot
establish full-window quality or justify lowering the finale's requirements.

## Holdout scope

Use only orb 59, cascade/expert, steady cadence, baseline/210 s, and seeds 5001–5100:
**400 attempts**, with 1800 simulated seconds, 3000 pieces, 240000 wall milliseconds
and full showcase policy. Cascade/steady is the primary exact paired-binomial test;
expert preservation remains separate. Require the registered effect, coverage and
Holm gates, and retain quality qualifications. Do not pool screen and holdout samples
into a confirmation test or switch to 240 after inspecting the holdout.

The complete independent numbers are in
[independent-screen-analysis.json](independent-screen-analysis.json). Raw measurement
data were only read; no benchmark or production source changed.
