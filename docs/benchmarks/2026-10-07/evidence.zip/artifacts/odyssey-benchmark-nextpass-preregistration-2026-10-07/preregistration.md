# Odyssey next-pass preregistration — 2026-10-07

Registered before reviewing the focused 20-seed outcomes. The initial three-seed campaign
and implementation smoke checks informed the scopes; they are not the confirmation sample.
This is an offline synthetic-policy experiment. It changes no production settings and
does not estimate human skill, enjoyment or completion probability.

The machine-readable rules are in [preregistration.json](preregistration.json).

## Planned samples

| Run | Orbs | Policies | Cadences | Seeds | Attempts |
| --- | --- | --- | --- | --- | --- |
| Focused screen | 4, 46, 51, 55, 59 | cascade, expert | steady | 2001–2020 | 440 |
| Execution robustness | 1, 51, 59 | expert | native, steady, deliberate | 3001–3005 | 105 |
| Quad quality | 1 | quad | native | 4001–4020 | 20 |
| Conditional holdout | Nominated decisions | cascade primary; expert preservation | steady | 5001–5100 | 100 per cell |

Every screen runs all scenarios supported by its selected orbs. Orb 4 has baseline,
850 ms and 700 ms; orb 51 has baseline, 75 ms and 100 ms; orb 59 has baseline, 210 s
and 240 s. Orbs 1, 46 and 55 have baseline only. Total screening scope: **565 attempts**.
The Quad profile's native reaction/action timing equals steady, but its cell label remains
native and its observations are not pooled into the primary comparisons.

Budgets are 1800 simulated seconds, 3000 pieces and 240000 wall milliseconds, with six
workers and `lapWindowSeconds:null`. Showcase play uses the full authored deadline;
untimed showcases use the recorded harness budget. Three-star attainment can finish a
showcase early. Exactly three upcoming pieces are available to each planning view.

Pair the same orb, policy, cadence, seed, implementation, budgets and lap policy. Only
the declared scenario configuration differs. Native/deliberate robustness is descriptive;
cadences and repeated-policy seeds are never pooled into a larger independent sample.
The actual run configuration is authoritative, and any changed budgets require a new
recorded run.

### Pre-screen implementation amendment — 13:30:59 UTC

The common wall budget was raised from 120000 to **240000 ms for every focused,
cadence, Quad and holdout attempt before the screens started**. The frozen 33-attempt
diagnostic pilot contained 23 wins, ten losses, no primary censors/errors and one
quality censor. Expert orb 55 exhausted 120000 wall milliseconds at 448.7 of the
authored 480 simulated seconds; the larger compute budget protects full-window
quality observation.

That pilot also identified an orb-59 cascade kick/replan stall after 144.78 seconds.
The profile agent is correcting this with a bounded three-retry **real hard-drop**
fallback before measurement. The final implementation hash is pending that fallback
and report lint freeze. Final policy capabilities and implementation metadata must
be recorded before screening. The pilot is diagnostic only and contributes no
observations to candidate estimates or holdout tests. Criteria, priorities, strata,
seeds, simulated-time/piece budgets and full-window policy are unchanged.

## Eligibility and candidate selection

- Require zero runtime errors and at least 95% resolved paired coverage: 19/20 screen
  pairs and 95/100 holdout pairs. Censors and errors are not gameplay losses. Report
  unresolved-outcome bounds; unresolved pairs must not reverse the observed advantage.
- Relevant mechanics must pass capability validation. Quality claims involving depth
  five or more require construction evidence at the actual target depth. A failed or
  unvalidated strategy leaves that quality claim inconclusive.
- Use canonical settled primary evaluation and bonus/star results. Preserve primary
  success when an optional showcase quality lap is censored; exclude such laps from
  complete star comparisons.
- The screen only nominates a candidate. Freeze the smallest qualifying variant before
  opening the 100 fresh-seed holdout. A failed holdout does not authorize choosing the
  larger variant using those same outcomes; a new choice needs a new preregistration
  and independent seeds.

| Decision | Preserved authored content | Screen nomination and priority |
| --- | --- | --- |
| Orb 59, optional encore | 160000 score; 200000/260000 star scores and cascade/combo/depth requirements; board, scoring and progression | At least four net additional primary wins on the 20 cascade/steady pairs, converting baseline deadline losses. Prefer 210 s; consider 240 s only if 210 remains deadline-limited and does not qualify. Extra quality time alone does not qualify. |
| Orb 51, late panic sprint test | 66 lines/150 s; 120/93 s stars; scoring level 13 and progression/acceleration; board and bag | At least four net additional primary wins on the 20 cascade/steady pairs, plus an actual execution mechanism. Prefer 75 ms; consider 100 ms only if 75 is insufficient. Faster expert/native wins alone do not qualify. |
| Orb 4, gentle first duel test | Seven credited frags; tier-1 Cinder; same gravity on both wells; at most three/one deaths for two/three stars | Require at least 15% shorter median and 10% shorter p90 on matched both-win durations, with preservation gates below. Prefer 850 ms; consider 700 ms only if 850 is insufficient. Faster defeats or self-destructions do not qualify. |

For orb 51, baseline must show actual failed movement/rotation or automatic-lock burden,
and traces must link the reduced execution failure to the improvement. **If both baseline
failed actions and automatic locks remain zero, reject the gravity change even if outcomes
differ.** Legal grounded soft-drop `false` returns are not failed inputs. Replay both
scenarios on every changed-outcome screen pair and the fixed first five screen seeds,
using the identical implementation/config, and save the input/lock traces.

## Fresh-seed confirmation

Primary comparisons are **cascade/steady**. Expert/steady preservation is separate.
For orbs 51 and 59, require a paired primary-win gain of at least 10 percentage points
on resolved holdout pairs and rejection by the corrected paired test below. Also report
all-planned-seed bounds rather than presenting a conditional rate as universal.

For duel pacing, require at least 80 matched both-win holdout pairs. On that fixed
population, require median(candidate)/median(baseline) ≤0.85 and p90(candidate)/p90(baseline)
≤0.90, plus rejection by the corrected duration test. Median averages the two central
values for even N; p90 uses nearest rank `ceil(0.90*N)-1` after ascending sort.

Preservation guards allow no more than a five-percentage-point observed decline in
primary wins, two-star rates or three-star rates, and no more than a five-point increase
in duel uncredited-death share. Wins use resolved pairs. Star comparisons use matched
both-win pairs with complete canonical quality evaluation and qualified relevant
strategy evidence. Uncredited-death share is uncredited eliminations divided by all
eliminations within each cell; zero-death cells are reported as undefined. These are
descriptive guardrails, **not formal statistical non-inferiority claims**.

Inspect real human/opponent attack counts and rows, credited/uncredited deaths, round
active/resolution/intermission time and completed/partial rounds. An orb-4 finding alone
cannot support changing the whole duel ladder: verify all eight unchanged tiers and
death-based quality before any global pacing adoption.

## Exact paired tests and Holm correction

For primary completion, define:

- `b`: baseline loses and candidate wins;
- `c`: baseline wins and candidate loses;
- `n = b+c`.

Both-win and both-loss pairs are ties for this test. Unresolved pairs are excluded from
the test and retained in the coverage/bounds report. Under the equality null, favorable
discordances have probability 0.5. The one-sided exact paired binomial p-value is:

`p = sum(k=b..n) choose(n,k) / 2^n`; set `p=1` when `n=0`.

The completion effect is `(b-c)/N_terminal_paired`. If `u` pairs are unresolved, report
the all-planned-seed gain bounds `[(b-c-u)/N_planned, (b-c+u)/N_planned]` as well.

For duel pacing, apply the same upper-binomial tail to unique matched both-win seeds:
`b` counts shorter candidate durations and `c` counts longer durations. Differences of
at most `1e-7` seconds are ties. This tests the chance of a shorter successful match;
it is not a test of the median or p90 themselves, which remain separate effect gates.

The fixed primary family contains three decisions:

1. Orb 59 completion.
2. Orb 51 completion.
3. Orb 4 matched-win duration.

Choose at most one screened candidate per decision. Give any unselected decision `p=1`.
Sort the three p-values ascending, breaking ties by decision id. Apply Holm sequentially:
compare the first with `0.05/3`, the second with `0.05/2`, and the third with `0.05`.
Stop at the first failed comparison; later hypotheses are not rejected. A decision
qualifies only if its test is rejected **and** its mechanism, effect, coverage and
preservation gates pass. Robustness, quality, controls and attack summaries are
descriptive and carry no additional significance claims.

## Boss controls and campaign roles

Keep orb 46 unchanged: 90000 score in 150 s, with 120/93 s star thresholds. It is a
brutal hybrid boss, not an arrival target.

Keep orb 55 unchanged: 250000 score in 480 s on its authored 100-row Infinity board.
Two stars require 350000 score, 25 cascades and depth six; three require 500000 score,
35 cascades, depth ten and combo 18. Use the full showcase window. Quality above
demonstrated construction depth stays inconclusive; do not lower these requirements.

Preserve gentle first tests, brutal late tests/bosses, optional encore challenge, and
the easier arrival/release beats around them. Do not flatten all orb success rates.
These synthetic observations cannot establish the subjective experience of that arc.

## Implementation record

Git HEAD at registration: `d14b1c2364fdc0916e65ab930b164ab4213f0767`.

Benchmark SHA-256 recorded at initial registration:
`c12d1ea32c8b9d70ec708ecccd65c4f1540c36e60a7049c7b6f323ab07c520a6`.

Final screening revision recorded from
`artifacts/odyssey-benchmark-focused-screen-2026-10-07/config.json` at 13:34:34 UTC:

- Benchmark SHA-256: `4950a5b552e84c8a0778e589d6d3c80ecb3de4ce5c214b65e3370a8fa7d57631`.
- Application SHA-256: `259ef02511db27892ca3812be676b45518b261d5cbc910b8daad4369b930f407`.
- Node: `v24.14.0` on Windows x64.
- Parent verification: 79 focused tests pass; scoped lint has zero errors.

The bounded fallback and report fixes are frozen. The initial registration hash is
retained for chronology and must not be substituted for the final measurement version.
No criteria changed, and no focused outcome analysis preceded this metadata update.

Hash order matches the CLI: CLI file, runtime, virtual clock, profiles, capabilities,
report and scenarios. Actual run metadata must be retained; implementation changes
cannot be pooled silently with this snapshot.

## Independent analysis reader

`analyze.mjs` lives only in this artifact directory and never writes run data. During
measurement, `coverage <run-dir>` reports counts and missing/duplicate keys without
candidate decisions. Outcome comparisons require `screen <run-dir> --completed` and
all configured unique keys. `holdout <run-dir> --completed --nominations <json>` applies
the fixed paired tests to a previously frozen nomination manifest of the form
`{"decisions":[{"id":"orb59-deadline","selectedScenario":"orb59-deadline210"}]}`.
Unselected decisions receive p=1 in the three-test family.

The reader checks registered hashes/budgets, uses its own paired counts and nearest-rank
quantiles, reports boss controls and flags inconsistent duel time/counter totals.
It does not import the campaign report or gameplay modules. Its exact-tail, median,
p90 and Holm stopping calculations were verified on known values independently of any
screen outcomes. Input traces and construction evidence still require substantive review;
numeric comparison output alone is not a nomination or production adoption.
