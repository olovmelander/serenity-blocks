This artifact-only driver compares orb 4's authored tier-1 opponent with the nominated gravity variant. It executes the exact production `PuzzleBotController.plan` with the opponent's real full bag, while the benchmark human retains three previews.

Fixed conditions: seeds 2001–2005; cascade and expert policies; steady cadence; 240,000 ms wall, 1,800 s simulation and 3,000-piece budgets. Each selected variant is paired with baseline on the same seed and policy. No benchmark or game module is edited.

Prepare a plan without simulation:

```powershell
node artifacts/odyssey-benchmark-opponent-fidelity-2026-10-07/compare-authored-opponent.mjs --variants duel-fall700
```

After nomination, add `--run` to execute. Select `duel-fall700`, `duel-fall850`, or both. `--workers` accepts 1–6; default 4. The default output is the artifact's `run` folder; an existing run is never overwritten or mixed.

Raw `opponentPreviewCount: null` means the opponent has no planning limit. `runtimeOpponentPreviewCount` preserves the benchmark's original three-preview metadata, and `opponentVisiblePreviewCount: 3` describes the visible HUD tiles. Actual queue lengths and occurrences of an I only beyond the third preview are recorded independently. Driver, benchmark, application and runtime provenance are captured and checked again at completion.
