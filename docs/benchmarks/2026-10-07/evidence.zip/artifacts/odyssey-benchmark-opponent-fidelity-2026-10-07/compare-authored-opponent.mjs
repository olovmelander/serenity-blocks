/** Artifact-only authored-opponent comparison. No production or benchmark module is modified. */
import { fork, execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import {
    appendFileSync, existsSync, mkdirSync, readFileSync, writeFileSync,
} from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const driverPath = fileURLToPath(import.meta.url);
const repoRoot = resolve(dirname(driverPath), '../..');
const scenarioIdsAllowed = ['duel-fall700', 'duel-fall850'];
const humanProfiles = ['cascade', 'expert'];
const seeds = [2001, 2002, 2003, 2004, 2005];
const budgets = { wallBudgetMs: 240000, maxSimSeconds: 1800, maxPieces: 3000 };

function provenance() {
    const benchmarkFiles = [
        'scripts/odyssey-benchmark.mjs',
        ...['runtime', 'virtual-clock', 'profiles', 'capabilities', 'report', 'scenarios']
            .map((name) => `scripts/odyssey-benchmark/${name}.mjs`),
    ];
    const benchmark = createHash('sha256');
    benchmarkFiles.forEach((file) => benchmark.update(readFileSync(resolve(repoRoot, file))));
    const sourceFiles = execFileSync('git', [
        'ls-files', '-z', '--cached', '--others', '--exclude-standard', '--',
        'src', 'package.json', 'package-lock.json',
    ], { cwd: repoRoot, encoding: 'utf8' }).split('\0')
        .filter((file) => /\.(?:[cm]?[jt]s|json)$/.test(file)).sort();
    const application = createHash('sha256');
    sourceFiles.forEach((file) => {
        application.update(`${file}\0`);
        const path = resolve(repoRoot, file);
        application.update(existsSync(path) ? readFileSync(path) : '<deleted>');
    });
    return {
        head: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: repoRoot, encoding: 'utf8' }).trim(),
        benchmarkHash: benchmark.digest('hex'),
        applicationHash: application.digest('hex'),
        driverHash: createHash('sha256').update(readFileSync(driverPath)).digest('hex'),
        runtime: { node: process.version, platform: process.platform, arch: process.arch },
    };
}

function observeQueue(observation, controller, match = null) {
    const queue = controller.playerState.nextPieces;
    const keys = queue.map((piece) => (typeof piece === 'string' ? piece : piece.shapeKey || piece.type));
    observation.calls++;
    observation.minimumQueue = Math.min(observation.minimumQueue, queue.length);
    observation.maximumQueue = Math.max(observation.maximumQueue, queue.length);
    observation.queueLengthCounts[queue.length] = (observation.queueLengthCounts[queue.length] || 0) + 1;
    if (!keys.slice(0, 3).includes('I') && keys.slice(3).includes('I')) observation.iOnlyBeyondThird++;
    if (observation.firstQueues.length < 5) {
        observation.firstQueues.push({ round: match?.round ?? null, queueLength: queue.length, shapes: keys });
    }
}

function newObservation() {
    return {
        calls: 0, minimumQueue: Infinity, maximumQueue: 0,
        queueLengthCounts: {}, iOnlyBeyondThird: 0, firstQueues: [],
    };
}

async function runObservedAttempt(task, expectedProvenance) {
    const [{ runAttempt }, { OdysseyBotMatch }, { PuzzleBotController }, { BenchmarkBot }] = await Promise.all([
        import('../../scripts/odyssey-benchmark/runtime.mjs'),
        import('../../src/core/odyssey/OdysseyBotMatch.js'),
        import('../../src/core/ai/puzzle-bot-controller.js'),
        import('../../scripts/odyssey-benchmark/profiles.mjs'),
    ]);
    const opponent = newObservation();
    const human = newObservation();
    const originalPrepare = OdysseyBotMatch.prototype.prepareBot;
    const originalHumanPlan = BenchmarkBot.prototype.plan;
    const productionPlan = PuzzleBotController.prototype.plan;
    let restored = false;
    let actualStateIdentity = true;
    let actualBagIdentity = true;
    OdysseyBotMatch.prototype.prepareBot = function prepareObservedOpponent(...args) {
        // Runtime restricts the opponent before calling prepareBot. Replacing its
        // instance method here removes only that planning-view wrapper.
        this.bot.plan = function observeExactProductionPlan(...planArgs) {
            actualStateIdentity &&= this.playerState === thisMatch.players[1];
            const actualBag = this.playerState.nextPieces;
            observeQueue(opponent, this, thisMatch);
            try { return productionPlan.apply(this, planArgs); }
            finally { actualBagIdentity &&= this.playerState.nextPieces === actualBag; }
        };
        const thisMatch = this;
        restored = true;
        return originalPrepare.apply(this, args);
    };
    BenchmarkBot.prototype.plan = function observeRestrictedHuman(...args) {
        // createBenchmarkBot's existing view wrapper calls this with exactly
        // the three visible previews; the policy and actual seven-bag stay intact.
        observeQueue(human, this);
        return originalHumanPlan.apply(this, args);
    };
    try {
        const attempt = await runAttempt(task);
        const passed = restored && actualStateIdentity && actualBagIdentity
            && opponent.calls > 0 && opponent.minimumQueue >= 10
            && human.calls > 0 && human.maximumQueue <= 3;
        for (const observation of [opponent, human]) {
            if (!Number.isFinite(observation.minimumQueue)) observation.minimumQueue = null;
        }
        return {
            ...attempt,
            runtimeOpponentPreviewCount: attempt.opponentPreviewCount,
            opponentPreviewCount: null,
            opponentVisiblePreviewCount: 3,
            opponentPlanningPreviewLimit: null,
            opponentKnowledgePolicy: 'production-full-real-bag',
            humanPlanningPreviewLimit: 3,
            fidelity: {
                status: passed ? 'pass' : 'fail',
                restoredAfterRuntimeWrapper: restored,
                exactProductionPlan: true,
                actualStateIdentity,
                actualBagIdentity,
                opponent,
                human,
                meaning: 'opponentPreviewCount:null means no planning limit; the visible opponent HUD has three tiles.',
            },
            provenance: expectedProvenance,
        };
    } finally {
        OdysseyBotMatch.prototype.prepareBot = originalPrepare;
        BenchmarkBot.prototype.plan = originalHumanPlan;
    }
}

function taskKey(task) {
    return [task.levelId, task.profileId ?? task.profile, task.seed, task.scenarioId, task.cadenceId].join(':');
}

async function workerMain() {
    let running = false;
    process.on('message', async ({ task, revision }) => {
        if (running) throw new Error('Worker attempted concurrent virtual sessions');
        running = true;
        let attempt;
        try { attempt = await runObservedAttempt(task, revision); }
        catch (error) {
            attempt = {
                ...task, profileId: task.profile, outcome: 'error', reason: 'fidelity-driver-exception',
                error: String(error.stack || error), provenance: revision,
            };
        }
        running = false;
        process.send({ attempt });
    });
    process.on('disconnect', () => process.exit(0));
    process.send({ ready: true });
}

async function runWorkers(tasks, config, onResult) {
    let cursor = 0;
    let stopping = false;
    const children = new Set();
    const runWorker = () => new Promise((resolveWorker, rejectWorker) => {
        const child = fork(driverPath, ['--worker'], {
            cwd: repoRoot, stdio: ['ignore', 'ignore', 'pipe', 'ipc'], windowsHide: true,
        });
        children.add(child);
        let watchdog;
        let current;
        child.stderr.on('data', (chunk) => appendFileSync(resolve(config.outputDir, 'runner.log'), chunk));
        const assign = () => {
            current = tasks[cursor++];
            if (!current) { child.disconnect(); return; }
            child.send({ task: current, revision: config.provenance });
            watchdog = setTimeout(() => {
                child.kill();
                rejectWorker(new Error(`Worker watchdog expired for ${taskKey(current)}`));
            }, budgets.wallBudgetMs + 10000);
        };
        child.on('message', ({ ready, attempt }) => {
            if (stopping) return;
            if (ready) assign();
            else if (attempt) {
                clearTimeout(watchdog);
                current = null;
                onResult(attempt);
                assign();
            }
        });
        child.on('error', rejectWorker);
        child.on('exit', (code) => {
            children.delete(child);
            clearTimeout(watchdog);
            if (stopping) return;
            if (current || code !== 0) rejectWorker(new Error(`Fidelity worker exited ${code}`));
            else resolveWorker();
        });
    });
    try {
        await Promise.all(Array.from({ length: Math.min(config.workers, tasks.length) }, runWorker));
    } finally {
        stopping = true;
        children.forEach((child) => child.kill());
    }
}

async function main() {
    const args = process.argv.slice(2);
    const values = {};
    for (let index = 0; index < args.length; index++) {
        const key = args[index];
        if (['--run', '--help'].includes(key)) values[key] = true;
        else if (['--variants', '--output', '--workers'].includes(key)) values[key] = args[++index];
        else throw new Error(`Unknown argument ${key}`);
    }
    if (values['--help']) {
        console.log('node compare-authored-opponent.mjs --variants duel-fall700[,duel-fall850] [--workers 4] [--run]');
        console.log('Without --run, prints the plan and provenance and executes no simulation.');
        return;
    }
    const variants = [...new Set(String(values['--variants'] || '').split(',').filter(Boolean))];
    if (!variants.length || variants.some((variant) => !scenarioIdsAllowed.includes(variant))) {
        throw new Error('Supply --variants duel-fall700 and/or duel-fall850 after nomination');
    }
    const workers = Number(values['--workers'] || 4);
    if (!Number.isSafeInteger(workers) || workers < 1 || workers > 6) throw new Error('Workers must be 1–6');
    const outputDir = resolve(values['--output'] || resolve(dirname(driverPath), 'run'));
    const config = {
        kind: 'authored-opponent-fidelity-comparison',
        levelId: 4, seeds, profileIds: humanProfiles, cadenceId: 'steady',
        scenarioIds: ['baseline', ...variants], budgets, workers, outputDir,
        humanPlanningPreviewLimit: 3,
        opponentKnowledgePolicy: 'production-full-real-bag',
        opponentVisiblePreviewCount: 3,
        provenance: provenance(),
    };
    const tasks = seeds.flatMap((seed) => humanProfiles.flatMap((profile) => config.scenarioIds.map((scenarioId) => ({
        levelId: 4, seed, profile, cadenceId: 'steady', scenarioId, trace: true, ...budgets,
    }))));
    config.plannedAttempts = tasks.length;
    if (!values['--run']) { console.log(JSON.stringify(config, null, 2)); return; }
    mkdirSync(outputDir, { recursive: true });
    const rawPath = resolve(outputDir, 'raw.jsonl');
    const configPath = resolve(outputDir, 'config.json');
    if (existsSync(rawPath) || existsSync(configPath)) throw new Error('Use a new output directory; driver never mixes runs');
    writeFileSync(configPath, JSON.stringify(config, null, 2));
    writeFileSync(rawPath, '');
    const results = [];
    await runWorkers(tasks, config, (attempt) => {
        results.push(attempt);
        appendFileSync(rawPath, `${JSON.stringify(attempt)}\n`);
        console.log(`${results.length}/${tasks.length}: ${taskKey(attempt)} ${attempt.outcome}; fidelity ${attempt.fidelity?.status}`);
    });
    const finalProvenance = provenance();
    const stableSource = JSON.stringify(finalProvenance) === JSON.stringify(config.provenance);
    const uniqueAttempts = new Set(results.map(taskKey)).size === results.length;
    const validation = {
        expectedAttempts: tasks.length, actualAttempts: results.length,
        stableSource, uniqueAttempts, finalProvenance,
        fidelityPassed: results.filter((attempt) => attempt.fidelity?.status === 'pass').length,
        outcomeCounts: Object.fromEntries(['win', 'loss', 'censored', 'error']
            .map((outcome) => [outcome, results.filter((attempt) => attempt.outcome === outcome).length])),
        status: stableSource && uniqueAttempts && results.length === tasks.length
            && results.every((attempt) => attempt.fidelity?.status === 'pass') ? 'pass' : 'fail',
        interpretation: 'Matched production-opponent pacing comparison. No human calibration; higher tiers are outside this orb4 tier1 sample.',
    };
    writeFileSync(resolve(outputDir, 'validation.json'), JSON.stringify(validation, null, 2));
    console.log(JSON.stringify(validation, null, 2));
    if (validation.status !== 'pass' || validation.outcomeCounts.error > 0) process.exitCode = 1;
}

const operation = process.argv.includes('--worker') ? workerMain() : main();
operation.catch((error) => { console.error(error.stack || error); process.exitCode = 1; });
