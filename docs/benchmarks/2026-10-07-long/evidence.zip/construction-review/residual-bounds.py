#!/usr/bin/env python3
"""Pure arithmetic over preserved prior traces; never executes game physics or planning."""
import argparse
import hashlib
import json
import math
from pathlib import Path


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def residual(row, target_sequences, target_depth, piece_limit):
    metrics = row['metricsAfter']
    cells = row['cellConservation']['actual']
    sequences = max(0, target_sequences - metrics['cascades'])
    depth_missing = max(metrics['maxCombo'], metrics['maxCascadeDepth']) < target_depth
    trigger_locks = max(sequences, int(depth_missing))
    lines = target_depth + 2 * max(0, sequences - 1) if depth_missing else 2 * sequences
    material_locks = max(0, math.ceil((10 * lines - cells) / 4))
    pieces_left = max(0, piece_limit - metrics['piecesPlaced'])
    return {
        'step': row['step'], 'piecesPlaced': metrics['piecesPlaced'],
        'score': metrics['score'], 'linesCleared': metrics['lines'],
        'cascadeSequences': metrics['cascades'],
        'depth': max(metrics['maxCombo'], metrics['maxCascadeDepth']),
        'optimisticRemainingCells': cells,
        'missingSequenceCount': sequences, 'depthStillMissing': depth_missing,
        'minimumAdditionalClearLines': lines,
        'minimumAdditionalTriggerLocks': trigger_locks,
        'minimumAdditionalMaterialLocks': material_locks,
        'minimumAdditionalLocks': max(trigger_locks, material_locks),
        'piecesLeftInRegisteredLimit': pieces_left,
        'materialBoundExcludesLimit': material_locks > pieces_left,
        'triggerBoundExcludesLimit': trigger_locks > pieces_left,
        'remainingBudgetExcluded': max(trigger_locks, material_locks) > pieces_left,
    }


def analyze(root):
    expected = json.loads((root / 'residual-bounds.json').read_text())
    for entry in expected['inputs']:
        candidate = root / entry['candidate']
        config = root / entry['config']
        if candidate.stat().st_size != entry['bytes'] or digest(candidate) != entry['sha256']:
            raise ValueError('Preserved prior candidate hash/size mismatch: ' + entry['candidate'])
        if digest(config) != entry['configSha256']:
            raise ValueError('Preserved prior configuration hash mismatch: ' + entry['config'])
    out = {
        'schemaVersion': 1,
        'kind': 'retrospective-prior-trace-arithmetic-not-gameplay-probe',
        'claims': [
            'All inputs predate the long charged study; no new outcomes are read.',
            'Inventory counts are optimistic: including any unusable cells only weakens exclusion.',
            'Positive necessary bounds do not prove reachable geometry or timing.',
            'Orb49 score exclusion assumes the preserved untimed context: exactly +50 per lock.',
            'Showcase bounds exclude a 192-piece continuation of a particular state, not the authored level.',
        ],
        'inputs': [], 'showcaseResiduals': [], 'orb49': None,
    }
    for parent in sorted((root / 'prior-inputs').iterdir()):
        path = parent / 'candidate.json'
        item = json.loads(path.read_text())
        config = parent / 'config.json'
        out['inputs'].append({
            'candidate': path.relative_to(root).as_posix(), 'sha256': digest(path),
            'bytes': path.stat().st_size,
            'config': config.relative_to(root).as_posix(), 'configSha256': digest(config),
            'priorArchiveMember': 'search/' + parent.name + '/candidate.json',
        })
        complete = [t for t in item['trace'] if t['completed']]
        if item['levelId'] == 49:
            assert all(t['prediction']['lockBonus'] == 50 for t in complete)
            rows = []
            for t in complete:
                m = t['metricsAfter']
                if m['tetrises'] != 8:
                    continue
                cells = t['cellConservation']['actual']
                minimum_locks = max(1, math.ceil((200 - cells) / 4))
                headroom = 36000 - m['score']
                rows.append({
                    'step': t['step'], 'score': m['score'], 'quads': m['tetrises'],
                    'lines': m['lines'], 'optimisticRemainingCells': cells,
                    'minimumTerminalCells': 200, 'minimumFutureLocks': minimum_locks,
                    'minimumPreterminalScoreWith50Bonus': m['score'] + 50 * (minimum_locks - 1),
                    'strictScoreHeadroom': headroom,
                    'eightPriorRouteExcluded': m['score'] + 50 * (minimum_locks - 1) >= 36000,
                    'nineOrMorePriorRouteExcluded': 2000 >= headroom,
                })
            out['orb49'] = {
                'case': parent.name, 'termination': item['termination'],
                'finalPieces': item['piecesPlaced'],
                'firstEightPriorQuads': rows[0],
                'firstAllRoutesExcluded': next(r for r in rows if r['eightPriorRouteExcluded'] and r['nineOrMorePriorRouteExcluded']),
                'allEightPriorQuadBoundaries': rows,
                'terminalInventoryProof': {
                    'drainedBoardCellsAtMost': 4 * 10 + 20 * 9,
                    'triggerCellsAtMost': 4,
                    'terminalCellsAtMost': 224,
                    'eightWavesFiveQuadsRequireCells': 10 * (8 + 3 * 5),
                    'eightWavesFourQuadsRequireCells': 10 * (8 + 3 * 4),
                    'anyAdditionalPriorQuadScoreAtLeast': 2000,
                },
            }
            continue
        targets = item['requirements']['stars']['three']
        rows = [residual(t, targets['conditions']['cascades'], targets['effectiveChainDepth'], 192) for t in complete]
        out['showcaseResiduals'].append({
            'case': parent.name, 'termination': item['termination'],
            'targetSequences': targets['conditions']['cascades'],
            'targetDepth': targets['effectiveChainDepth'],
            'targetScore': targets['conditions']['score'],
            'initialCells': item['initialBoard']['occupiedCells'],
            'initialMinimumPiecesFromMaterial': math.ceil((10 * (targets['effectiveChainDepth'] + 2 * (targets['conditions']['cascades'] - 1)) - item['initialBoard']['occupiedCells']) / 4),
            'firstMaterialExclusion': next((r for r in rows if r['materialBoundExcludesLimit']), None),
            'firstTriggerExclusion': next((r for r in rows if r['triggerBoundExcludesLimit']), None),
            'final': rows[-1],
        })
    return out


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    print(json.dumps(analyze(args.root), indent=2) + '\n', end='')
