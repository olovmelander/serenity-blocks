# Constructive mastery gap review

This is a retrospective arithmetic and source review of existing structural-v1
traces. It was prepared without running the game or planner and before inspecting
any long charged-study outcome. The study's source and policy remain unchanged.
The last arithmetic invocation completed immediately before the root agent's
campaign-start pause notice. Subsequent work was prose and read-only source
inspection; no measured-phase simulation or performance probe was run.

The seven preserved candidate/configuration pairs are exact bytes from the
previous online study at source `96b2364`, combined source hash
`bbb09217bd3cabab39750d9ec3052b4a1c42d2042486b02c96bc1f8c2f754501`.
Selection is deliberate and retrospective: the orb-49 seed-9103 case is the
prior study's only eight-Quad structural prefix; all three structural seeds at
each showcase orb are retained to avoid selecting one showcase outcome. The
other two orb-49 structural runs reached only six/seven Quads before top-out and
are not needed for this particular eight-prior-Quad residual proof. This is not
an additional performance cohort or a new mastery witness.

`residual-bounds.json` records candidate byte counts and candidate/configuration
SHA-256 hashes. `residual-bounds.py` verifies those hashes and uses only these
preserved inputs, then recomputes the same output with pure integer arithmetic.
No repository checkout, old artifact directory, engine or planner is required:

```sh
python residual-bounds.py > /tmp/odyssey-construction-review.json
cmp residual-bounds.json /tmp/odyssey-construction-review.json
```

The existing JSON is the expected input-hash manifest as well as the result.
The containing evidence archive independently binds its bytes. Regenerate into
a different file, so shell redirection does not truncate that manifest first.
All bounds are necessary conditions. A state that passes them may still have no
reachable trigger, safe spawn, timely execution or useful cascade geometry.

Independent review identified and corrected one provenance metadata error:
`priorArchiveMember` originally prefixed an extra
`odyssey-online-mastery-2026-10-07/`, while the durable prior ZIP starts directly
at `search/`. The initial JSON and portability record are retained with
`.before-member-path-correction` filenames. `metadata-correction.json` records
the old/new hashes and verifies that only the seven member-path strings changed
in the result. All seven candidate/configuration pairs were then compared
directly with their actual prior ZIP members. Arithmetic, recorded outcomes and
preserved input bytes are unchanged. Reproduction and relocation verification
were repeated against the corrected result.

## A real orb-49 prefix becomes impossible before top-out

Ordinary orb 49 stops after the first fully resolved score-goal-winning lock.
Its eight-wave chain must be terminal: even eight single-line waves at level 7
score at least 51,000 before positive extras. The standard board has 20 visible
rows and four hidden rows. At a fully drained boundary each visible row is
incomplete, so it has at most `20*9 + 4*10 = 220` cells. The trigger contributes
at most four. Off-grid cells are not a reserve for later gravity waves.

An eight-wave chain containing five Quads would remove at least
`10*(8 + 3*5) = 230` cells, exceeding the 224-cell bound. Therefore at least eight
of the twelve required Quads must precede the terminal chain. With exactly eight
prior Quads, its remaining four Quads and four other waves need at least 200
cells. These are relaxed cell counts, not a valid arrangement of tetrominoes.

In the preserved structural 49/9103 trace:

| Boundary | Prior Quads | Score | Cells remaining | Minimum future locks for 200 terminal cells | Minimum preterminal score at +50 per lock |
| --- | ---: | ---: | ---: | ---: | ---: |
| Lock 83 | 8 | 32,550 | 12 | 47 | 34,850 |
| Lock 119 | 8 | 34,825 | 146 | 14 | 35,475 |
| Lock 121 | 8 | 35,400 | 144 | 14 | **36,050** |

The trace awards exactly 50 points for every untimed lock. After lock 121,
getting enough material needs at least 14 future locks; at least 13 precede the
finishing lock. Thus `35,400 + 13*50 = 36,050`, already over the 36,000 automatic
finish threshold. Clearing extra lines cannot help: it consumes cells and adds
nonnegative score. Taking a ninth prior Quad cannot help either: even its
level-zero base score is 2,000, greater than the 600 remaining headroom. Putting
five Quads in the final chain is already excluded by inventory. Every relaxed
allocation is therefore excluded at lock 121 under this trace's scoring context.
The search continues another five locks before its recorded top-out at 126.

This is a conditional impossibility for continuation of one **untimed** state,
not impossibility of the authored level or a timed state. Timed locks can award
less than 50; using this exclusion in a timed policy requires a separately sound
minimum future lock bonus, conservatively zero when no stronger bound is known.
Top-out itself is independently terminal; this argument identifies earlier
resource exhaustion without relying on that later outcome.

Source: `scripts/odyssey-benchmark/mastery-geometry.mjs`,
`drainedTerminalInventoryBound`, `orb49InventoryRoutes` and
`masteryGeometryUtility`; `src/core/scoring.js`,
`calculateLineClearScore`; `src/core/odyssey/data/levels.js`, effective orb-49
override; `src/core/odyssey/GameplayHybridEngine.js`, settled victory handling.
The current geometric headroom penalty is inside the `quad-prefix` branch;
`chain-storage` uses storage/preparation utility without the same route check.
Its generic route calculation also defaults to zero future lock bonus, so the
actual +50 untimed context needs explicit treatment before it could make this
particular exclusion.

## A joint sequence/depth reserve, checked after every lock

Let `K` be the required distinct sequence count, `k` the count already achieved,
`D` the required depth, `d` the achieved maximum depth, `C` the remaining cells,
and `R` the remaining allowed future placed pieces. Set `s = max(0, K-k)`.
Every sequence requires a different locking piece and at least two clear waves.
When the depth remains unmet, one future sequence must contain all `D` waves;
existing shallow chains cannot be extended across later locks.

Necessary future clear lines and distinct triggering locks are:

```text
if d < D:
    L = D + 2 * max(0, s-1)
    T = max(1, s)
else:
    L = 2*s
    T = s

materialLocks = max(0, ceil((10*L - C) / 4))
requiredFutureLocks >= max(T, materialLocks)
```

If that last bound exceeds `R`, this state cannot reach the joint sequence/depth
requirements inside the declared remaining piece budget. Counts that include
unusable/off-grid cells make the material test more optimistic, so they cannot
create a false exclusion. Score, timing, top-out and construction constraints
can only add restrictions. The bound is not a player rule: the 192-piece cap is
the experiment's censoring budget.

Initially the material bound reproduces 155 pieces for orb 55 and 140 for orb
59. It also exposes failures that an initial supply check misses:

| Prior structural case | First exclusion by missing trigger count | First exclusion by remaining material | At final recorded lock |
| --- | ---: | ---: | --- |
| 55 / 9101 | 159 | 175 | 798 cells; 34 sequences and an 18-wave chain still needed |
| 55 / 9102 | 159 | 181 | 798 cells; 34 sequences and an 18-wave chain still needed |
| 55 / 9103 | 159 | 179 | 808 cells; 34 sequences and an 18-wave chain still needed |
| 59 / 9101 | Never before top-out | Never before top-out | Top-out at 99; optimistic material minimum 79 more locks versus 93 budgeted |
| 59 / 9102 | Never before top-out | Never before top-out | Top-out at 59; optimistic material minimum 84 more locks versus 133 budgeted |
| 59 / 9103 | Never before top-out | Never before top-out | Top-out at 60; optimistic material minimum 85 more locks versus 132 budgeted |

At orb-55 lock 159, each run has only one of 35 sequences and only 33 future
locks available. No amount of stored material can make those 33 locks produce
34 distinct sequences. At their final boundaries, the material-only bound asks
for 11/11/8 more pieces, whereas the sequence-trigger requirement still asks for
at least 34. A policy that sees only board mass misses the dominant constraint.

The orb-59 cases demonstrate the opposite limitation: ample optimistic supply
does not prevent top-out. The residual check would not have rejected those
states on inventory alone. No legal finishing construction is established.

## Why the existing structural preferences miss the conjunction

`createMasteryGeometryObjective` keeps a showcase in `chain-storage` until the
full authored depth is reached. It raises a local depth stage by two from the
previous maximum, initially six. While not in danger, below-stage cascades cost
7,000 utility plus 220 per cleared line. Distinct sequence collection is a
separate phase only after depth 18/12 is reached. In the three prior orb-55
traces, that separation ends at one sequence and depth six/five/five after all
192 pieces. It postpones a finite trigger resource that cannot be recovered
merely by later releasing a larger tower.

Storage, a clear well or a high preparation score does not encode the component
release order needed for a deep chain. An 18-wave discharge counts as **one**
sequence, even when it produces a large score. The prior orb-49 run likewise
demonstrates a valid eight-Quad prefix but no surviving 200-cell, four-Quad
terminal construction. Separate impressive partial metrics do not compose
automatically into a legal joint witness.

At orb 55's fixed level 12, the scoring formula supplies another useful logical
implication. With one line in each wave and no perfect-clear, combo multiplier
or lock bonus, an 18-wave chain scores at least:

```text
2.2 * (18*250 + 200*(0^2 + ... + 17^2)) = 795,300
```

Thus completing the required depth already implies its 500,000 score threshold.
The 35 distinct sequences, timely primary acquisition and survival still matter.
A 13-wave chain similarly yields at least 293,150, enough for the 250,000 primary
if completely settled by 480 seconds. It is a sufficient arithmetic condition,
not a required strategy or a constructed chain. Choosing separate 13- and
18-wave chains plus 33 other two-wave sequences requires at least 97 lines and
183 pieces from the 240-cell start. That consumes most of a 192-piece experiment
before accounting for final leftovers or inefficient clears. A primary-first
phase should therefore choose a state-specific scoring route rather than blindly
adding a fixed intermediate depth target.

Source: `src/core/odyssey/data/levels.js`, effective orb-55 override (fixed level
12, no level progression); `src/core/scoring.js`,
`calculateLineClearScore`; `src/core/constants.js`, `SCORE_VALUES` and
`CASCADE_SCORING`; `src/core/physics.js`, nonnegative combo-multiplier scoring;
`src/core/odyssey/VictoryConditionEvaluator.js`, `onCascade` and `onCombo`.

Source locations in the reviewed checkout: effective level and disabled
progression at `levels.js:4914`; base/cascade/perfect-clear/level formula at
`scoring.js:23`; 250-point single and 200-point quadratic cascade constant at
`constants.js:116`; score application and multiplier lower bound at
`physics.js:856`. Scoring only applies the optional multiplier when it is
greater than one (`physics.js:862`), so omitting it cannot inflate the minimum. The complete source
paths above disambiguate these filenames. No score gain is attributed to a
chain until its actual clear waves occur, and timely primary qualification
still requires the entire goal-acquiring cascade to settle by the deadline.
An already acquired showcase primary permits later quality chains after that
deadline; the deadline is not reimposed on every subsequent chain.

## Concrete next solver step and authored-design questions

Before another larger search, add a diagnostic feasibility envelope to every
fully drained candidate state. It should carry remaining sequence-trigger
slots, necessary remaining clear cells, missing depth, actual primary-acquired
state, deadline slack and orb-49 preterminal score headroom. First verify these
arithmetic rejections against the retained prior counterexamples. Use gates only
where their assumptions are proven for the chosen timing mode; keep uncertified
geometry estimates as preferences. These bounds must remain active through all
setup phases, including terminal-chain storage.

Then search for reusable **legally built** release structures: record component
support dependencies, which removal releases the next wave, the intended trigger
and a reachable command path. For orb 49, start by solving the four-Quad,
eight-wave terminal schedule within the 224-cell capacity and score envelope,
and join it to a legal prefix. For 55/59, preserve opportunities for distinct
two-wave sequences while building the long release structure; do not wait until
the maximum depth is complete to account for their trigger slots. Retain a small
frontier separated by residual resources, rather than allowing one weighted
utility to discard every construction compatible with another joint condition.

A solved cell diagram or a board supplied to physics is only a prepared fixture.
A witness must still begin at the authored start, use the allowed observations,
place actual tetrominoes through legal paths, retain every automatic lock and
resolve every cascade in production physics. Actual charged replay must then
establish the deadline and scoring context. No such new witness is claimed by
this review; source changes require a new frozen experiment.

The relevant human questions are concrete: do players understand that a large
chain counts once toward 35/25 sequences; does orb 49 communicate that the first
score-winning lock ends its chance to earn the joint optional mastery; and do
its fast-lock bonuses make the intended prefix-plus-terminal puzzle satisfying
or encourage unwanted waiting? The authored orb-55 tip emphasizes taller towers,
so test comprehension of the distinct-sequence requirement separately from the
appeal of a spectacular chain. These are protocol questions, not measured
confusion, unfairness, a difficulty recommendation or authorization to retune.
