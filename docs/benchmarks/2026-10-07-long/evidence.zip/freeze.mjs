/** Source/protocol freeze only. Never launches a study invocation. */
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { cpus, availableParallelism, loadavg } from 'node:os';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { captureSourceRevision, parseOptions } from '../../scripts/odyssey-mastery.mjs';

const root = dirname(fileURLToPath(import.meta.url));
const repositoryRoot = resolve(root, '../..');
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const write = (name, value) => writeFileSync(resolve(root, name), `${JSON.stringify(value, null, 2)}\n`, { flag: 'wx' });
const ref = (name) => ({ path: name, sha256: sha(readFileSync(resolve(root, name))) });
if (process.argv.includes('--help')) {
    process.stdout.write('Manual freeze only after root authorization: node artifacts/odyssey-long-mastery-2026-10-07/freeze.mjs --source-ready\n');
    process.exit(0);
}
if (!process.argv.includes('--source-ready')) throw new Error('Wait for root source-ready/freeze authorization');
if (existsSync(resolve(root, 'registration.json'))) throw new Error('Never overwrite a registration');
execFileSync('git', ['diff', '--quiet', 'HEAD', '--', 'src', 'scripts', 'tests', 'package.json', 'package-lock.json'], { cwd: repositoryRoot });
const untracked = execFileSync('git', ['ls-files', '--others', '--exclude-standard', '--', 'src', 'scripts', 'tests'],
    { cwd: repositoryRoot, encoding: 'utf8' }).trim();
if (untracked) throw new Error(`Uncommitted source/tests: ${untracked}`);
for (const name of ['analyze.py', 'analysis-support.py', 'run.py', 'README.md']) {
    if (!existsSync(resolve(root, name))) throw new Error(`Missing freeze input ${name}`);
}
execFileSync('python3', [resolve(root, 'analyze.py'), '--self-test'], { stdio: 'inherit', cwd: repositoryRoot });
const tasks = [];
const measuredParents = [];
const common = ['--max-pieces', '192', '--beam-width', '8', '--max-nodes', '1440000', '--nodes-per-plan', '1200',
    '--unknown-tail-depth', '1', '--setup-strategy', 'none', '--timing-policy', 'fixed-cadence',
    '--max-decisions', '4096', '--replans-per-piece', '64', '--repair-nodes', '4096',
    '--reaction-ms', '150', '--action-ms', '100', '--max-seconds', '1800', '--wall-ms', '360000'];
function add(levelId, seed, pathRepair, planningLatency, group) {
    const condition = `${planningLatency}-${pathRepair}`;
    const id = `${condition}-orb-${levelId}-seed-${seed}`;
    const output = `online/${id}`;
    const task = { id, stage: 'online', levelId, seed, pathRepair, planningLatency, group,
        fixedPlanningMs: 200, cadence: 'steady',
        witnessScope: 'long-horizon-joint-mastery-development-only', output,
        command: ['node', 'scripts/odyssey-mastery.mjs', 'online', '--level', String(levelId), '--seed', String(seed),
            ...common, '--path-repair', pathRepair, '--planning-latency', planningLatency,
            ...(planningLatency === 'fixed' ? ['--fixed-planning-ms', '200'] : []), '--output', resolve(root, output)] };
    task.expectedOptions = parseOptions(task.command.slice(2));
    if (task.expectedOptions.fixedPlanningMs !== task.fixedPlanningMs) throw new Error('CLI latency defaults differ from protocol');
    tasks.push(task);
    const witness = `${output}/witness.json`;
    const replayOutput = `replay/${id}`;
    const replay = { ...task, id: `replay-${id}`, stage: 'replay-online', dependsOn: id,
        witnessScope: 'independent-recorded-schedule-replay', witness, output: replayOutput,
        command: ['node', 'scripts/odyssey-mastery.mjs', 'replay-online', '--witness', resolve(root, witness),
            '--wall-ms', '120000', '--output', resolve(root, replayOutput)] };
    replay.expectedOptions = parseOptions(replay.command.slice(2));
    tasks.push(replay);
    measuredParents.push(id);
}
for (const [levelId, seed, repairs] of [
    [49, 9101, ['none', 'reachable-v1']], [55, 9101, ['reachable-v1', 'none']],
    [59, 9101, ['none', 'reachable-v1']], [49, 9102, ['reachable-v1', 'none']],
    [55, 9102, ['none', 'reachable-v1']], [59, 9102, ['reachable-v1', 'none']],
]) {
    for (const repair of repairs) add(levelId, seed, repair, 'measured-wall', 'long-measured-wall-development');
}
if (tasks.length !== 24 || measuredParents.length !== 12) throw new Error('Unexpected task matrix');
const source = captureSourceRevision();
write('environment.json', { capturedAt: new Date().toISOString(), runtime: source.revision.runtime,
    availableParallelism: availableParallelism(), cpuModels: [...new Set(cpus().map((item) => item.model))],
    logicalCpuCount: cpus().length, loadAverage: loadavg(), workers: 3, measuredWallParentWorkers: 1,
    qualification: 'Measured wall is specific to this host/load; serial computation does not establish browser or human feasibility.' });
write('source-manifest.json', source.files);
writeFileSync(resolve(root, 'source.patch'), source.patch, { flag: 'wx' });
const independent = execFileSync('python3', ['-c', `
import hashlib,json,pathlib,sys,zipfile
root,repo=map(pathlib.Path,sys.argv[1:]);manifest=json.loads((root/'source-manifest.json').read_text());digest=hashlib.sha256()
with zipfile.ZipFile(root/'source-snapshot.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for name in sorted(manifest,key=lambda value:value.encode('utf-16-be')):
  data=(repo/name).read_bytes();assert manifest[name]=={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
  digest.update((name+'\\0').encode());digest.update(data)
  info=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;archive.writestr(info,data,compresslevel=9)
print(digest.hexdigest())`, root, repositoryRoot], { encoding: 'utf8' }).trim();
if (independent !== source.revision.sourceHash) throw new Error('Independent archived-source digest differs');
// Preserve only relevant committed text validation inputs; production bytes are
// already in source-snapshot.zip. Unchanged-code test results retain their old provenance.
const previousRoot = resolve(repositoryRoot, 'artifacts/odyssey-planning-latency-2026-10-07');
const previousRegistration = JSON.parse(readFileSync(resolve(previousRoot, 'registration.json')));
if (source.revision.sourceHash !== previousRegistration.sourceFreeze.sourceHash) throw new Error('Source changed since prior validation');
execFileSync('python3', ['-c', `
import hashlib,json,pathlib,shutil,sys,zipfile
root,repo,prior=map(pathlib.Path,sys.argv[1:])
provenance=root/'prior-validation';provenance.mkdir()
for name in ['registration.json','registration.sha256']:
 shutil.copyfile(prior/name,provenance/name)
shutil.copyfile(repo/'docs/benchmarks/2026-10-07-latency/manifest.json',provenance/'durable-manifest.json')
shutil.copytree(prior/'validation',provenance/'validation')
refs={str(p.relative_to(root)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(provenance.rglob('*')) if p.is_file()}
(root/'prior-validation.json').write_text(json.dumps({'qualification':'Inherited unchanged-source validation, not tests run for this campaign.','files':refs},indent=2)+'\\n')
names=['package.json','package-lock.json','vitest.config.js']
names += [str(p.relative_to(repo)) for p in sorted((repo/'tests/unit').glob('odyssey-mastery-*.test.js'))]
names += [str(p.relative_to(repo)) for p in sorted((repo/'tests/unit').glob('odyssey-authored-construction*.test.js'))]
names=[n for n in names if (repo/n).is_file()]
manifest={}
with zipfile.ZipFile(root/'validation-source.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for name in sorted(set(names)):
  data=(repo/name).read_bytes();data.decode('utf-8')
  info=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;archive.writestr(info,data,compresslevel=9)
  manifest[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
(root/'validation-source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\\n')
fresh=json.loads((root/'validation/summary.json').read_text())
assert fresh['allPassed'] is True and all(item['exitCode']==0 for item in fresh['checks'])
refs={str(p.relative_to(root)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted((root/'validation').rglob('*')) if p.is_file()}
(root/'current-validation.json').write_text(json.dumps({'files':refs,'sourceHash':fresh['sourceHash']},indent=2)+'\\n')
`, root, repositoryRoot, previousRoot], { stdio: 'inherit' });
const registration = {
    schemaVersion: 1, executionReady: true, frozenAt: new Date().toISOString(), repositoryRoot,
    purpose: 'Bounded exact joint-mastery construction/execution development study with charged measured-wall timing; no human calibration.',
    sourceFreeze: { commit: source.revision.head, sourceHash: source.revision.sourceHash, runtime: source.revision.runtime,
        sourceManifest: ref('source-manifest.json'), sourceSnapshot: ref('source-snapshot.zip'), sourcePatch: ref('source.patch'),
        validationSource: ref('validation-source.zip'), validationManifest: ref('validation-source-manifest.json'),
        inheritedValidation: ref('prior-validation.json'), currentValidation: ref('current-validation.json'),
        analyzerSha256: sha(readFileSync(resolve(root, 'analyze.py'))), analysisSupport: ref('analysis-support.py') },
    runnerSha256: sha(readFileSync(resolve(root, 'run.py'))), freezeScriptSha256: sha(readFileSync(fileURLToPath(import.meta.url))),
    protocol: ref('README.md'), environment: ref('environment.json'), workers: 3,
    developmentSeeds: [9101, 9102], reservedConfirmationSeedsStart: 11001,
    plannedCounts: { online: 12, 'replay-online': 12 },
    executionPhases: [
        { id: 'measured-wall-parents', workers: 1, taskIds: measuredParents },
        { id: 'measured-wall-replays', workers: 3, taskIds: measuredParents.map((id) => `replay-${id}`) },
    ],
    comparisons: {
        repairPairs: 'none versus reachable-v1 within orb/seed/latency; list every assigned pair and all excluded observations.',
        latencyPairs: 'None: every parent uses measured-wall charged timing.',
        metrics: ['pieces', 'elapsed time', 'score', 'lines', 'cascades', 'depth', 'quads', 'rejected inputs', 'automatic locks',
            'fallback drops', 'plan/repair calls and nodes and wall/CPU cost', 'charged delay', 'applied/no-path/stale repair attempts'],
        qualification: 'Original completed, verified parent and independent exact timestamp replay required for paired numerical comparisons.',
        inference: 'Development-only descriptive comparisons; no effect-size adoption threshold, significance test, retuning or human claim.',
    },
    selectionRule: 'Execute all24 assignments. Preserve all failures and censors. No automatic retry, seed replacement or silent recovery.',
    exactGoals: {
        49: { primaryScore: 36000, deadlineSeconds: null, three: { score: 36000, tetrises: 12, combo: 8 }, necessaryPieceFloor: 130 },
        55: { primaryScore: 250000, deadlineSeconds: 480, three: { score: 500000, cascades: 35, maxCascadeDepth: 10, combo: 18 }, necessaryPieceFloor: 155 },
        59: { primaryScore: 160000, deadlineSeconds: 210, three: { score: 260000, cascades: 25, maxCascadeDepth: 7, combo: 12 }, necessaryPieceFloor: 140 },
    },
    scopeLimits: ['192 pieces exceed known necessary cell-supply floors, not sufficient construction or timing bounds.',
        'Measured-wall latency is host/load dependent; serial and balanced order remains descriptive.',
        'Repair consumes the shared total node budget. Failed, stale and interrupted computations remain charged and reported.',
        'Legacy ordinary-loop virtual60Hz timing is not canonical fixed60-v1.',
        'Recorded schedule replay does not establish browser scheduling or human playability.'],
    tasks,
};
write('registration.json', registration);
writeFileSync(resolve(root, 'registration.sha256'), `${sha(readFileSync(resolve(root, 'registration.json')))}  registration.json\n`, { flag: 'wx' });
process.stdout.write(`${JSON.stringify({ commit: source.revision.head, sourceHash: source.revision.sourceHash, tasks: tasks.length })}\n`);
