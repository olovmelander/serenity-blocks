#!/usr/bin/env python3
"""Portable analysis of the frozen longer joint-mastery development study."""
import argparse
from collections import Counter, defaultdict
import hashlib
import importlib.util
import json
import math
from pathlib import Path, PurePosixPath
import zipfile

ROOT = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('long_mastery_support', ROOT / 'analysis-support.py')
SUPPORT = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(SUPPORT)
FINISHES = {'primary-goal', 'manual-showcase-finish', 'showcase-top-out'}
RESULT_NAMES = {'online': 'witness.json', 'replay-online': 'replay.json'}
OPTION_FLAGS = {'--output': 'outputDir', '--wall-ms': 'wallBudgetMs', '--level': 'levelId', '--seed': 'seed',
    '--max-pieces': 'maxPieces', '--beam-width': 'beamWidth', '--max-nodes': 'maxNodes',
    '--nodes-per-plan': 'maxNodesPerPlan', '--unknown-tail-depth': 'unknownTailDepth', '--setup-strategy': 'setupStrategy',
    '--reaction-ms': 'reactionMs', '--action-ms': 'actionIntervalMs', '--max-seconds': 'maxSimSeconds',
    '--timing-policy': 'timingPolicy', '--max-decisions': 'maxDecisions', '--replans-per-piece': 'maxReplansPerPiece',
    '--witness': 'witnessPath', '--path-repair': 'pathRepair', '--repair-nodes': 'maxRepairNodes',
    '--planning-latency': 'planningLatency', '--fixed-planning-ms': 'fixedPlanningMs'}
PROJECTION_KEYS = ['levelId', 'seed', 'initialBoardHash', 'commands', 'trace', 'outcome', 'reason', 'qualityCensored',
    'primaryReachedAtPiece', 'primaryReached', 'goalReachedAtSeconds', 'stoppedAtSeconds', 'stopPhase',
    'physicsDrainedThroughSeconds', 'metrics', 'quality', 'computeSchedule']
EPS = 1e-6


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


class Inputs:
    def __init__(self, root):
        self.root, self.hashes = root, {}

    def read(self, name):
        path = PurePosixPath(name)
        require(not path.is_absolute() and '..' not in path.parts, 'Unsafe artifact input path')
        data = (self.root / name).read_bytes()
        self.hashes[name] = {'bytes': len(data), 'sha256': sha(data)}
        return data

    def json(self, name):
        return json.loads(self.read(name))

    def reference(self, reference):
        data = self.read(reference['path'])
        require(sha(data) == reference['sha256'], 'Reference checksum differs: ' + reference['path'])
        return data



def check_options(task, options):
    require(options == task['expectedOptions'], 'Config options differ from frozen expected options')
    argv = task['command']
    require(len(argv) >= 3 and Path(argv[1]).name == 'odyssey-mastery.mjs' and argv[2] == task['stage'], 'Command stage/tool differs')
    require(options['command'] == task['stage'], 'Options command differs')
    tokens = argv[3:]
    require(len(tokens) % 2 == 0, 'Registration commands require explicit flag/value pairs')
    seen = set()
    for flag, value in zip(tokens[::2], tokens[1::2]):
        require(flag in OPTION_FLAGS and flag not in seen, 'Unknown/duplicate command flag: ' + flag)
        seen.add(flag)
        require(str(options[OPTION_FLAGS[flag]]) == value, 'Option differs from command: ' + flag)
    parts = PurePosixPath(task['output']).parts
    require(parts and '..' not in parts and not PurePosixPath(task['output']).is_absolute(), 'Unsafe task output')
    output = Path(options['outputDir'])
    require(output.parts[-len(parts):] == parts, 'Output path differs from task')
    original_root = output.parents[len(parts) - 1]
    for field, option in [('candidate', 'candidatePath'), ('witness', 'witnessPath')]:
        if field in task:
            require(Path(options[option]) == original_root / task[field], 'Input path differs from task')
    for field in ('levelId', 'seed'):
        if field in options:
            require(options[field] == task[field], 'Task identity differs from options')


def verify_source(reg, inputs):
    freeze = reg['sourceFreeze']
    require(reg['executionReady'] is True, 'Registration not frozen')
    require(sha(inputs.read('registration.json')) == inputs.read('registration.sha256').decode().split()[0], 'Registration changed')
    for name, expected in [('analyze.py', freeze['analyzerSha256']), ('analysis-support.py', freeze['analysisSupport']['sha256']),
                           ('run.py', reg['runnerSha256']), ('freeze.mjs', reg['freezeScriptSha256'])]:
        require(sha(inputs.read(name)) == expected, 'Frozen scaffold changed: ' + name)
        if name in ('analyze.py', 'analysis-support.py'):
            require(sha((ROOT / name).read_bytes()) == expected, 'Running analyzer differs: ' + name)
    manifest = json.loads(inputs.reference(freeze['sourceManifest']))
    inputs.reference(freeze['sourceSnapshot']); inputs.reference(freeze['sourcePatch'])
    inputs.reference(reg['environment']); inputs.reference(reg['protocol'])
    digest = hashlib.sha256()
    with zipfile.ZipFile(inputs.root / freeze['sourceSnapshot']['path']) as archive:
        members = [item.filename for item in archive.infolist() if not item.is_dir()]
        require(len(members) == len(set(members)) and set(members) == set(manifest), 'ZIP/manifest paths differ')
        for name in sorted(members, key=lambda value: value.encode('utf-16-be', errors='surrogatepass')):
            path = PurePosixPath(name)
            require(not path.is_absolute() and '..' not in path.parts, 'Unsafe source archive path')
            data = archive.read(name)
            require(manifest[name] == {'bytes': len(data), 'sha256': sha(data)}, 'Source bytes differ: ' + name)
            digest.update((name + '\0').encode()); digest.update(data)
    require(digest.hexdigest() == freeze['sourceHash'], 'Full-path/NUL/source digest differs')
    if 'validationSource' in freeze:
        inputs.reference(freeze['validationSource'])
        validation = json.loads(inputs.reference(freeze['validationManifest']))
        with zipfile.ZipFile(inputs.root / freeze['validationSource']['path']) as archive:
            members = [item.filename for item in archive.infolist() if not item.is_dir()]
            require(len(members) == len(set(members)) and set(members) == set(validation), 'Validation archive paths differ')
            for name in members:
                path = PurePosixPath(name)
                require(not path.is_absolute() and '..' not in path.parts, 'Unsafe validation archive path')
                data = archive.read(name)
                require(validation[name] == {'bytes': len(data), 'sha256': sha(data)}, 'Validation source bytes differ: ' + name)
                if name in manifest: require(validation[name] == manifest[name], 'Validation and CLI source differ: ' + name)
    if 'inheritedValidation' in freeze:
        inherited = json.loads(inputs.reference(freeze['inheritedValidation']))
        for name, expected in inherited['files'].items():
            data = inputs.read(name)
            require(expected == {'bytes': len(data), 'sha256': sha(data)}, 'Inherited validation input changed: ' + name)
        previous = inputs.json('prior-validation/registration.json')
        require(previous['sourceFreeze']['sourceHash'] == freeze['sourceHash'], 'Inherited validation source differs')
        require(sha(inputs.read('prior-validation/registration.json')) == inputs.read('prior-validation/registration.sha256').decode().split()[0], 'Inherited registration changed')
    if 'currentValidation' in freeze:
        current = json.loads(inputs.reference(freeze['currentValidation']))
        require(current['sourceHash'] == freeze['sourceHash'], 'Fresh validation source differs')
        for name, expected in current['files'].items():
            data = inputs.read(name)
            require(expected == {'bytes': len(data), 'sha256': sha(data)}, 'Fresh validation input changed: ' + name)
        summary = inputs.json('validation/summary.json')
        require(summary['allPassed'] is True and all(row['exitCode'] == 0 for row in summary['checks']), 'Fresh validation not passed')
    return manifest, {'verified': True, 'files': len(manifest), 'commit': freeze['commit'],
                      'sourceHash': digest.hexdigest(), 'runtime': freeze['runtime']}


def verify_tasks(reg):
    if 'exactGoals' in reg:
        require(reg['exactGoals'] == {str(key): value for key, value in GOALS.items()}, 'Frozen exact authored goal oracle differs')
    tasks = reg['tasks']; by_id = {task['id']: task for task in tasks}
    require(len(tasks) == len(by_id) == len({task['output'] for task in tasks}), 'Duplicate task IDs/outputs')
    require(dict(Counter(task['stage'] for task in tasks)) == reg['plannedCounts'], 'Task counts differ')
    children = {}
    for task in tasks:
        check_options(task, task['expectedOptions'])
        require(task['stage'] in RESULT_NAMES, 'Unexpected stage')
        if task['stage'] == 'online':
            require(not task.get('dependsOn'), 'Parent unexpectedly has dependency')
            for key in ('pathRepair', 'planningLatency', 'fixedPlanningMs'):
                require(task[key] == task['expectedOptions'][key], 'Condition label differs: ' + key)
        else:
            require(task.get('dependsOn') in by_id, 'Unknown replay parent')
            parent = by_id[task['dependsOn']]
            require(parent['stage'] == 'online', 'Replay parent stage differs')
            require(all(task.get(key) == parent.get(key) for key in
                        ('levelId', 'seed', 'cadence', 'pathRepair', 'planningLatency', 'fixedPlanningMs', 'group')), 'Replay identity differs')
            require(task['witness'] == parent['output'] + '/witness.json', 'Replay input differs from parent')
            require(parent['id'] not in children, 'Multiple replay children')
            children[parent['id']] = task['id']
    require(set(children) == {task['id'] for task in tasks if task['stage'] == 'online'}, 'Missing independent replay assignment')
    phase_ids = [task_id for phase in reg['executionPhases'] for task_id in phase['taskIds']]
    require(len(phase_ids) == len(set(phase_ids)) and set(phase_ids) == set(by_id), 'Execution phase coverage differs')
    for phase in reg['executionPhases']:
        require(1 <= phase['workers'] <= 3, 'Worker cap differs')
        if any(by_id[task_id]['stage'] == 'online' and by_id[task_id]['planningLatency'] == 'measured-wall' for task_id in phase['taskIds']):
            require(phase['workers'] == 1, 'Measured-wall parents must be serial')
    return children


def read_journal(inputs, reg):
    name = 'events.jsonl'
    tasks = {task['id']: task for task in reg['tasks']}
    if not (inputs.root / name).exists():
        return {}, {'present': False, 'events': 0, 'tornTail': False, 'issues': [], 'runComplete': False}
    data = inputs.read(name)
    lines = data.splitlines(keepends=True)
    events = []; issues = []; torn = False
    for index, line in enumerate(lines):
        try:
            event = json.loads(line)
        except (ValueError, UnicodeDecodeError):
            if index == len(lines) - 1 and not line.endswith(b'\n'):
                torn = True; issues.append({'kind': 'torn-final-line', 'line': index + 1}); break
            raise ValueError('Malformed journal line: ' + str(index + 1))
        require(event.get('sequence') == index, 'Journal sequence differs')
        events.append(event)
    records = {}; active = set(); max_active = 0; phase = None; phase_completed = set(); launches = []
    phases = {item['id']: item for item in reg['executionPhases']}
    for event in events:
        kind = event['event']; task_id = event.get('id')
        if kind == 'phase-start':
            require(not active and phase is None, 'Overlapping phases or unreaped task')
            require(event['phase'] in phases and event['phase'] not in phase_completed, 'Unknown/repeated phase')
            require(event['phase'] == reg['executionPhases'][len(phase_completed)]['id'], 'Phase order differs')
            phase = event['phase']
            require(event['workers'] == phases[phase]['workers'], 'Phase worker limit differs')
        elif kind == 'phase-complete':
            require(not active and event['phase'] == phase, 'Phase ends with active tasks')
            require(all(task_id in records and records[task_id]['status'] != 'interrupted-unknown'
                        for task_id in phases[phase]['taskIds']), 'Phase omits assigned tasks')
            phase_completed.add(phase); phase = None
        elif kind in ('launch', 'spawned', 'exit', 'runner-error', 'skipped'):
            require(task_id in tasks and phase is not None and task_id in phases[phase]['taskIds'], 'Task outside declared phase')
            if kind == 'launch':
                require(task_id not in records, 'Duplicate launch/retry in original cohort')
                require(event.get('command') == tasks[task_id]['command'] and event.get('output') == tasks[task_id]['output'], 'Launch command/output differs')
                records[task_id] = {'status': 'interrupted-unknown', 'launch': event}
                active.add(task_id); launches.append(task_id); max_active = max(max_active, len(active))
                require(len(active) <= phases[phase]['workers'], 'Concurrent worker cap exceeded')
            elif kind == 'spawned':
                require(task_id in active and 'spawned' not in records[task_id], 'Unexpected process record')
                records[task_id]['spawned'] = event
            elif kind == 'skipped':
                require(task_id not in records and tasks[task_id]['stage'] == 'replay-online', 'Invalid skipped task')
                records[task_id] = {'status': 'skipped', 'terminal': event}
            else:
                require(task_id in active, 'Terminal event without active launch')
                active.remove(task_id)
                records[task_id].update({'status': kind, 'terminal': event})
                if kind == 'exit':
                    require(isinstance(event.get('exitCode'), int), 'Invalid observed exit code')
                    records[task_id]['exitCode'] = event['exitCode']
                    require(sha(inputs.read(event['log'])) == event['logSha256'], 'Log bytes differ from exit record')
        elif kind == 'run-complete':
            require(not active and phase is None and set(records) == set(tasks), 'Incomplete run marked complete')
            require(sha(inputs.read('execution.json')) == event['executionSha256'], 'Execution summary changed')
        elif kind != 'run-start':
            raise ValueError('Unknown journal event: ' + kind)
    for item in phases.values():
        if item['workers'] == 1:
            observed = [task_id for task_id in launches if task_id in item['taskIds']]
            require(observed == item['taskIds'][:len(observed)], 'Serial launch order differs')
    for name in ('measured-wall-environment-before.json', 'measured-wall-environment-after.json', 'execution-source-check.json'):
        if (inputs.root / name).exists(): inputs.json(name)
    if 'measured-wall-parents' in phase_completed:
        for name in ('measured-wall-environment-before.json', 'measured-wall-environment-after.json'):
            require((inputs.root / name).is_file(), 'Completed measured-wall phase lacks environment evidence: ' + name)
    if (inputs.root / 'execution-source-check.json').exists():
        recorded_source = inputs.json('execution-source-check.json')
        for key, expected in [('head', reg['sourceFreeze']['commit']), ('sourceHash', reg['sourceFreeze']['sourceHash']), ('runtime', reg['sourceFreeze']['runtime'])]:
            require(recorded_source['revision'].get(key) == expected, 'Pre-execution source check differs: ' + key)
    return records, {'present': True, 'events': len(events), 'tornTail': torn, 'issues': issues,
                     'maximumConcurrentLaunches': max_active, 'unfinishedLaunches': sorted(active),
                     'completedPhases': sorted(phase_completed), 'runComplete': any(event['event'] == 'run-complete' for event in events)}


def close(a, b):
    return isinstance(a, (float, int)) and isinstance(b, (float, int)) and math.isclose(a, b, rel_tol=1e-9, abs_tol=EPS)


def compute_checks(result, replay=False):
    events = result.get('computeSchedule', []); decisions = result.get('decisions', [])
    config = result.get('config', {}); errors = []
    def check(condition, message, index=None):
        if not condition: errors.append({'kind': message, 'index': index})
    previous_end = -math.inf
    previous_start = -math.inf
    for index, event in enumerate(events, 1):
        check(event.get('index') == index and event.get('kind') in ('plan', 'repair'), 'event-identity', index)
        charge = event.get('chargedMs'); duration = event.get('computeWallMs')
        expected = duration if config.get('planningLatency') == 'measured-wall' else config.get('fixedPlanningMs') if config.get('planningLatency') == 'fixed' else 0
        check(close(charge, expected), 'latency-model-charge', index)
        check(isinstance(duration, (int, float)) and duration >= 0, 'invalid-measured-duration', index)
        check(close(event.get('readyAtMs'), event.get('atMs', 0) + (charge or 0)), 'ready-time', index)
        check(event.get('atMs', -math.inf) + EPS >= previous_end, 'overlapping-computations', index)
        check(event.get('atMs', -math.inf) > previous_start, 'non-increasing-computation-start', index)
        previous_start = event.get('atMs', -math.inf)
        end = event.get('settledAtMs')
        check(isinstance(end, (float, int)) and end + EPS >= event.get('atMs', 0), 'missing-settlement', index)
        if isinstance(end, (float, int)):
            check(end <= result.get('stoppedAtSeconds', math.inf) * 1000 + EPS, 'settlement-after-terminal', index)
            if event.get('disposition') != 'interrupted':
                check(end + EPS >= event.get('readyAtMs', math.inf), 'released-before-ready', index)
            previous_end = end
            check(not any(event.get('atMs', 0) <= command['atMs'] < end - EPS for command in result.get('commands', [])), 'input-during-compute-window', index)
        if event.get('kind') == 'repair':
            check(config.get('pathRepair') == 'reachable-v1', 'unexpected-repair', index)
            check(event.get('repairStatus') in ('reachable', 'unreachable', 'budget'), 'repair-status', index)
            check(event.get('hasActions') == (event.get('repairStatus') == 'reachable'), 'repair-status-actions', index)
        check(event.get('disposition') in ('accepted', 'no-path', 'stale-piece', 'stale-board', 'stale-pose', 'interrupted', 'error'), 'unknown-disposition', index)
        check(event.get('hasActions') == bool(event.get('actions')), 'actions-flag', index)
    accounting = {}
    if not replay:
        check(len(events) == len(decisions), 'decision-event-count')
        for event, decision in zip(events, decisions):
            for key in ('index', 'kind', 'step', 'atMs', 'observationHash', 'pose', 'chargedMs'):
                check(event.get(key) == decision.get(key), 'decision-event-' + key, event.get('index'))
            kind = event.get('kind'); key = 'repairWallMs' if kind == 'repair' else 'plannerWallMs'
            check(close(event.get('computeWallMs'), decision.get(key)), 'decision-duration', event.get('index'))
            cap = config.get('maxRepairNodes') if kind == 'repair' else config.get('maxNodesPerPlan')
            check(isinstance(decision.get('nodes'), int) and 0 <= decision['nodes'] <= (cap or 0), 'per-call-node-budget', event.get('index'))
        for kind, prefix in [('plan', 'planner'), ('repair', 'repair')]:
            chosen = [item for item in decisions if item.get('kind') == kind]
            accounting[kind] = {'calls': len(chosen), 'nodes': sum(item.get('nodes', 0) for item in chosen),
                'wallMs': sum(item.get(prefix + 'WallMs', 0) for item in chosen), 'cpuMs': sum(item.get(prefix + 'CpuMs', 0) for item in chosen),
                'callWallMs': SUPPORT.distribution([item.get(prefix + 'WallMs') for item in chosen]),
                'callCpuMs': SUPPORT.distribution([item.get(prefix + 'CpuMs') for item in chosen]),
                'dispositions': dict(Counter(item.get('disposition') for item in events if item.get('kind') == kind))}
            for field, name in [('Nodes', 'nodes'), ('WallMs', 'wallMs'), ('CpuMs', 'cpuMs')]:
                check(close(result.get(prefix + field), accounting[kind][name]), 'aggregate-' + prefix + field)
        check(close(result.get('nodes'), sum(item.get('nodes', 0) for item in decisions)), 'aggregate-total-nodes')
        check(result.get('nodes', math.inf) <= config.get('maxNodes', 0), 'total-node-budget')
        check(len(decisions) <= config.get('maxDecisions', 0), 'decision-budget')
        check(close(result.get('planningChargedMs'), sum(event.get('chargedMs', 0) for event in events)), 'aggregate-charged-ms')
    settled = [event for event in events if isinstance(event.get('settledAtMs'), (float, int))]
    check(close(result.get('planningElapsedMs'), sum(event['settledAtMs'] - event['atMs'] for event in settled)), 'aggregate-elapsed-ms')
    repair = [event for event in events if event.get('kind') == 'repair']
    accepted_repairs = [event for event in repair if event.get('disposition') == 'accepted']
    # 'Applied' is an accepted input sourced from this accepted repair's release
    # window; accepting a computed path alone does not prove the target was locked.
    applied = []
    for index, event in enumerate(events):
        if event not in accepted_repairs: continue
        until = events[index + 1]['atMs'] if index + 1 < len(events) else math.inf
        if any(command.get('source') == 'repair' and command.get('accepted') and command.get('step') == event['step']
               and event['settledAtMs'] - EPS <= command['atMs'] < until for command in result.get('commands', [])):
            applied.append(event)
    retained = sum(any(prior.get('step') == event.get('step') and prior.get('boardHash') == event.get('boardHash')
                       and prior.get('target') == event.get('target') and event.get('target') is not None
                       for prior in events[:index]) for index, event in enumerate(events) if event.get('kind') == 'repair')
    locks = []
    for entry in result.get('trace', []):
        hard_drop = any(action.get('source') == 'repair' and action.get('type') == 'hardDrop' for action in entry.get('actions', []))
        validation = entry.get('targetValidation')
        if hard_drop:
            check(isinstance(validation, dict), 'missing-repair-target-validation', entry.get('step'))
        if validation:
            keys = ('shapeKey', 'x', 'y', 'rotation')
            target = {key: (validation.get('target') or {}).get(key) for key in keys}
            actual = {key: (entry.get('lockedPiece') or {}).get(key) for key in keys}
            target['rotation'] = (validation.get('target') or {}).get('rotation', 0)
            actual['rotation'] = (entry.get('lockedPiece') or {}).get('rotation', 0)
            target_match = bool(validation.get('target') and entry.get('lockedPiece') and target == actual)
            check(validation.get('actual') == actual and validation.get('targetAchieved') == target_match and target_match,
                  'repair-target-lock-mismatch', entry.get('step'))
            locks.append({'step': entry.get('step'), 'target': target, 'actual': actual, 'targetAchieved': target_match})
    return {'validAccounting': not errors, 'errors': errors, 'calls': len(events), 'byKind': accounting,
        'requestedChargedMs': sum(event.get('chargedMs', 0) for event in events),
        'simulatedComputeOccupancyMs': sum(event['settledAtMs'] - event['atMs'] for event in settled),
        'actualReleaseWaitMs': SUPPORT.distribution([event['settledAtMs'] - event['atMs'] for event in settled if event.get('disposition') != 'interrupted']),
        'releaseOvershootMs': SUPPORT.distribution([event['settledAtMs'] - event['readyAtMs'] for event in settled if event.get('disposition') != 'interrupted']),
        'interruptedCalls': sum(event.get('disposition') == 'interrupted' for event in events),
        'plansStaleAtRelease': sum(event.get('kind') == 'plan' and str(event.get('disposition')).startswith('stale-') for event in events),
        'repairAttempts': len(repair), 'repairDispositions': dict(Counter(event.get('disposition') for event in repair)),
        'repairSearchStatuses': dict(Counter(event.get('repairStatus') for event in repair)),
        'repairsRetainingEarlierRecordedTarget': retained, 'repairsAcceptedAtRelease': len(accepted_repairs),
        'repairsWithAcceptedInput': len(applied), 'repairsAppliedDefinition': 'At least one accepted repair-sourced input before the next computation; not proof of reaching the target lock.',
        'repairTargetLockChecks': locks, 'repairTargetsAchievedAtLock': sum(row['targetAchieved'] for row in locks),
        'latencyModel': config.get('planningLatency'), 'humanValidated': False, 'realTimePlanningQualified': False}


GOALS = {
    49: {'primaryScore': 36000, 'deadlineSeconds': None,
         'three': {'score': 36000, 'tetrises': 12, 'combo': 8}, 'necessaryPieceFloor': 130},
    55: {'primaryScore': 250000, 'deadlineSeconds': 480,
         'three': {'score': 500000, 'cascades': 35, 'maxCascadeDepth': 10, 'combo': 18}, 'necessaryPieceFloor': 155},
    59: {'primaryScore': 160000, 'deadlineSeconds': 210,
         'three': {'score': 260000, 'cascades': 25, 'maxCascadeDepth': 7, 'combo': 12}, 'necessaryPieceFloor': 140},
}


def goal_evidence(result):
    """Separate acquired primary history from threshold metrics drained after cutoff."""
    level_id = result.get('levelId')
    if level_id not in GOALS:
        return {'supported': False, 'valid': True, 'errors': []}
    expected = GOALS[level_id]
    requirements = result.get('requirements', {})
    metrics = result.get('metrics', {})
    conditions = expected['three']
    errors = []
    if requirements.get('stars', {}).get('three', {}).get('conditions') != conditions:
        errors.append('three-star authored conditions differ')
    primary = requirements.get('primary', {})
    if primary.get('type') != 'score' or primary.get('target') != expected['primaryScore']:
        errors.append('primary authored condition differs')
    deadlines = [item['seconds'] for item in primary.get('timeConstraints', []) if item.get('type') == 'primary-acquisition-deadline']
    if deadlines != ([] if expected['deadlineSeconds'] is None else [expected['deadlineSeconds']]):
        errors.append('primary authored acquisition deadline differs')
    if requirements.get('finishPolicy', {}).get('showcaseCanContinueAfterPrimary') is not (level_id != 49):
        errors.append('authored showcase policy differs')
    final = SUPPORT.independently_met(conditions, metrics)
    stopped = result.get('stoppedAtSeconds')
    reached = result.get('primaryReached') is True
    reached_time = result.get('goalReachedAtSeconds')
    reached_piece = result.get('primaryReachedAtPiece')
    deadline = expected['deadlineSeconds']
    acquired_in_time = reached and isinstance(reached_time, (int, float)) and isinstance(stopped, (int, float)) and reached_time <= stopped + EPS and (deadline is None or reached_time <= deadline + EPS)
    if reached and not acquired_in_time: errors.append('primary acquisition timestamp is absent or outside acquisition window')
    if not reached and (reached_time is not None or reached_piece is not None): errors.append('unacquired primary has acquisition timestamp/piece')
    threshold_first = None
    conjunction_first = None
    acquisition_lock = None
    for entry in result.get('trace', []):
        if not entry.get('completed'): continue
        at = entry.get('resolvedAtMs')
        row_metrics = entry.get('metricsAfter', {})
        if row_metrics.get('piecesPlaced') == reached_piece: acquisition_lock = entry
        if threshold_first is None and row_metrics.get('score', 0) >= expected['primaryScore']:
            threshold_first = {'piece': row_metrics.get('piecesPlaced'), 'resolvedAtSeconds': at / 1000 if isinstance(at, (int, float)) else None}
        if conjunction_first is None and SUPPORT.independently_met(conditions, row_metrics)['conditionsMet']:
            conjunction_first = {'piece': row_metrics.get('piecesPlaced'), 'resolvedAtSeconds': at / 1000 if isinstance(at, (int, float)) else None}
    if reached:
        if acquisition_lock is None or acquisition_lock.get('metricsAfter', {}).get('score', 0) < expected['primaryScore']:
            errors.append('acquired primary lacks qualifying completed lock')
        elif not isinstance(acquisition_lock.get('resolvedAtMs'), (int, float)) or acquisition_lock['resolvedAtMs'] / 1000 > reached_time + EPS:
            errors.append('primary acquired before qualifying lock resolution')
    conjunction_in_time = bool(conjunction_first and isinstance(conjunction_first['resolvedAtSeconds'], (int, float)) and isinstance(stopped, (int, float)) and conjunction_first['resolvedAtSeconds'] <= stopped + EPS)
    final_joint = bool(acquired_in_time and final['conditionsMet'])
    timely_joint = bool(acquired_in_time and conjunction_in_time)
    quality_censor = bool(result.get('qualityCensored') or result.get('quality', {}).get('censored'))
    primary_censor = result.get('outcome') == 'censored' and not reached
    showcase = level_id != 49
    showcase_state = ('not-applicable-ordinary-finish' if not showcase else 'not-entered' if not reached else
                      'censored-after-acquisition' if quality_censor else 'completed-policy-finish' if result.get('reason') == 'manual-showcase-finish' else
                      'completed-top-out' if result.get('reason') == 'showcase-top-out' else 'other-observed-stop')
    reported = result.get('quality', {}).get('masteryConditionsMet')
    if reported is not bool(reached and final['conditionsMet']):
        errors.append('reported mastery conjunction differs from recorded primary history and exact final residuals')
    return {'supported': True, 'valid': not errors, 'errors': errors,
        'exactPrimary': {'scoreTarget': expected['primaryScore'], 'finalScore': metrics.get('score', 0),
            'remainingScore': max(0, expected['primaryScore'] - metrics.get('score', 0)),
            'acquired': reached, 'acquisitionPiece': reached_piece, 'acquisitionSeconds': reached_time,
            'acquiredWithinDeadlineAndStop': bool(acquired_in_time), 'deadlineSeconds': deadline,
            'deadlineHeadroomAtAcquisitionSeconds': deadline - reached_time if acquired_in_time and deadline is not None else None,
            'deadlineRemainingAtStopSeconds': max(0, deadline - stopped) if deadline is not None and isinstance(stopped, (int, float)) and not reached else None,
            'firstCompletedLockAtScoreThreshold': threshold_first, 'censoredBeforeAcquisition': primary_censor},
        'exactThreeStars': final, 'firstCompletedLockAtAllThreeStarThresholds': conjunction_first,
        'finalPrimaryAndThreeStarConjunction': final_joint, 'jointConditionsMetAtOrBeforeStop': timely_joint,
        'completeMasteryWitnessBeforeReplay': bool(timely_joint and not quality_censor and result.get('outcome') == 'win' and result.get('reason') in FINISHES),
        'showcase': {'state': showcase_state, 'entered': showcase and reached, 'qualityCensored': quality_censor,
            'observedPostPrimarySeconds': max(0, stopped - reached_time) if showcase and acquired_in_time else None,
            'deadlineAppliesToAcquisitionOnly': showcase},
        'inventoryContext': {'necessaryPieceFloor': expected['necessaryPieceFloor'], 'assignedMaxPieces': result.get('config', {}).get('maxPieces'),
            'completedPieces': metrics.get('piecesPlaced'), 'necessarySupplyIsNotConstructionProof': True,
            'optionalTwentyQuadsExcludedFromOrb55ThreeStars': level_id == 55,
            'comboAndMaxCascadeDepthAreSameWaveOrdinal': True},
        'orb49ScoreHeadroomBeforeAutomaticFinish': max(0, expected['primaryScore'] - metrics.get('score', 0)) if level_id == 49 and not reached else None}


def describe(result, parent=None):
    trace = SUPPORT.online_trace_checks(result)
    compute = compute_checks(result, replay=parent is not None)
    quality = result.get('quality', {}); metrics = result.get('metrics', {})
    conditions = result.get('requirements', {}).get('stars', {}).get('three', {}).get('conditions', {})
    bonuses = sum(item.get('conditionMet') is True for item in quality.get('optionalBonuses', []))
    independent = SUPPORT.independently_met(conditions, metrics, bonuses)
    goals = goal_evidence(result)
    valid = result.get('traceValid') is True and trace['validRecordedEvidence'] and compute['validAccounting'] and goals['valid']
    replay = None
    if parent is not None:
        equal = {key: result.get(key) for key in PROJECTION_KEYS} == {key: parent.get(key) for key in PROJECTION_KEYS}
        hashes = isinstance(result.get('expectedExecutionHash'), str) and len(result['expectedExecutionHash']) == 64 and result['expectedExecutionHash'] == result.get('actualExecutionHash')
        replay = {'independentProjectionMatches': equal, 'reportedReplayValid': result.get('replayValid') is True,
            'reportedTraceComplete': result.get('traceComplete') is True, 'executionHashMatches': hashes,
            'qualified': bool(valid and equal and hashes and result.get('status') == 'pass'
                              and result.get('replayValid') is True and result.get('traceComplete') is True)}
    return {'outcome': result.get('outcome'), 'reason': result.get('reason'), 'resultStatus': result.get('status'),
        'recordedEvidenceValid': valid, 'traceEvidence': trace, 'compute': compute, 'timestampReplay': replay,
        'primaryReached': result.get('primaryReached') is True, 'primaryReachedAtPiece': result.get('primaryReachedAtPiece'),
        'goalReachedAtSeconds': result.get('goalReachedAtSeconds'), 'stoppedAtSeconds': result.get('stoppedAtSeconds'),
        'primaryCensored': result.get('outcome') == 'censored' and not result.get('primaryReached'),
        'qualityCensored': bool(result.get('qualityCensored') or quality.get('censored')),
        'timedStars': quality.get('timedStars'), 'reportedMasteryConditionsMet': quality.get('masteryConditionsMet'),
        'independentTierThree': independent, 'goalEvidence': goals, 'metrics': metrics, 'maximumDepth': result.get('maximumDepth'),
        'counters': result.get('counters'), 'failure': result.get('failure'), 'config': result.get('config'),
        'primaryTerminal': result.get('outcome') == 'win' and result.get('reason') in FINISHES,
        'humanValidated': False, 'realTimePlanningQualified': False, 'boundedJointMasteryAttempt': True}


def analyze_task(task, reg, manifest, inputs, execution):
    record = {key: task.get(key) for key in ('id', 'stage', 'output', 'levelId', 'seed', 'pathRepair', 'planningLatency', 'fixedPlanningMs', 'group', 'dependsOn')}
    run = execution.get(task['id'])
    record.update({'status': 'missing', 'provenanceVerified': False, 'execution': run})
    folder = task['output']
    try:
        if not (inputs.root / folder).exists():
            if run: record['status'] = {'skipped': 'not-executed', 'interrupted-unknown': 'interrupted-unknown', 'runner-error': 'runner-error'}.get(run['status'], 'missing-after-exit')
            return record
        if not (inputs.root / folder / 'config.json').exists():
            record['status'] = 'missing-config'; return record
        config = inputs.json(folder + '/config.json'); check_options(task, config['options'])
        require(config.get('schemaVersion') == 1, 'Unknown config schema')
        for field, expected in [('head', reg['sourceFreeze']['commit']), ('sourceHash', reg['sourceFreeze']['sourceHash']), ('runtime', reg['sourceFreeze']['runtime'])]:
            require(config['revision'].get(field) == expected, 'Invocation source/runtime differs: ' + field)
        require(inputs.json(folder + '/source-manifest.json') == manifest, 'Invocation manifest differs')
        require(inputs.read(folder + '/source.patch') == inputs.reference(reg['sourceFreeze']['sourcePatch']), 'Invocation patch differs')
        parent = None
        require(config.get('candidateSha256') is None, 'Unexpected candidate input')
        if task['stage'] == 'replay-online':
            data = inputs.read(task['witness']); parent = json.loads(data)
            require(config.get('witnessSha256') == sha(data), 'Witness input hash differs')
            require(inputs.read(folder + '/input-witness.json') == data, 'Copied witness differs')
        else: require(config.get('witnessSha256') is None, 'Unexpected witness input')
        record['provenanceVerified'] = True
        if (inputs.root / folder / 'failure.json').exists(): record['failure'] = inputs.json(folder + '/failure.json')
        if not (inputs.root / folder / 'summary.json').exists():
            record['status'] = 'result-error' if record.get('failure') else 'interrupted-unknown' if run and run['status'] == 'interrupted-unknown' else 'incomplete'
            if (inputs.root / folder / RESULT_NAMES[task['stage']]).exists():
                inputs.read(folder + '/' + RESULT_NAMES[task['stage']]); record['unqualifiedResultRetained'] = True
            return record
        summary = inputs.json(folder + '/summary.json')
        require(not record.get('failure'), 'Success summary conflicts with failure record')
        require(summary.get('status') == 'completed' and summary.get('sourceStable') is True, 'Tool incomplete/source unstable')
        require(summary['command'] == task['stage'] and summary['revision'] == config['revision'], 'Summary/config differs')
        for field in ('candidateSha256', 'witnessSha256'): require(summary.get(field) == config.get(field), 'Summary input hash differs')
        filename = RESULT_NAMES[task['stage']]; data = inputs.read(folder + '/' + filename)
        require(summary['result'] == {'path': filename, 'bytes': len(data), 'sha256': sha(data)}, 'Result bytes/hash differ')
        result = json.loads(data)
        require(result.get('schemaVersion') == 1 and result.get('version') == 'adaptive-fixed-cadence-v2', 'Unexpected result schema/version')
        require(result.get('kind') == ('online-mastery-witness' if task['stage'] == 'online' else 'online-mastery-replay'), 'Unexpected result kind')
        require(result.get('levelId') == task['levelId'] and result.get('seed') == task['seed'], 'Result identity differs')
        expected_config = parent['config'] if parent else {key: value for key, value in config['options'].items() if key not in ('command', 'outputDir')}
        require(result.get('config') == expected_config, 'Result configuration differs')
        require(result.get('planningLatency') == expected_config['planningLatency'], 'Result latency label differs')
        require(result.get('plannerWallTimeChargedToSimulation') is (expected_config['planningLatency'] == 'measured-wall'), 'Compute charging label differs')
        require(result.get('realtimePlanningFeasibility') == 'unverified', 'Unexpected real-time qualification')
        observation = describe(result, parent)
        status = 'result-error' if result.get('status') == 'error' else 'completed'
        if not run or run['status'] == 'interrupted-unknown': status = 'completed-exit-unknown'
        elif run['status'] != 'exit' or run.get('exitCode') != 0: status = 'execution-contradiction'
        record.update({'status': status, 'resultSha256': sha(data), 'elapsedWallMs': summary.get('elapsedWallMs'), 'observation': observation})
        if status != 'completed' and observation.get('timestampReplay'): observation['timestampReplay']['qualified'] = False
        return record
    except (ValueError, KeyError, TypeError, OSError, IndexError) as error:
        record.update({'status': 'verification-error', 'provenanceVerified': False, 'verificationError': str(error)})
        record.pop('observation', None)
        return record


def pair_values(observation):
    values = dict(observation.get('metrics') or {})
    values['stoppedAtSeconds'] = observation.get('stoppedAtSeconds')
    values['maximumDepth'] = observation.get('maximumDepth')
    goals = observation.get('goalEvidence', {})
    values['primaryScoreResidual'] = goals.get('exactPrimary', {}).get('remainingScore')
    for residual in goals.get('exactThreeStars', {}).get('residual', []):
        values['threeStarResidual.' + residual['key']] = residual['remaining']
    for key in ('rejectedInputs', 'automaticLocks', 'fallbackDrops', 'gravityReplans'):
        values[key] = (observation.get('counters') or {}).get(key)
    compute = observation.get('compute', {})
    for key in ('requestedChargedMs', 'simulatedComputeOccupancyMs', 'plansStaleAtRelease', 'repairAttempts', 'repairsAcceptedAtRelease', 'repairsWithAcceptedInput'):
        values[key] = compute.get(key)
    for kind, row in compute.get('byKind', {}).items():
        for key in ('calls', 'nodes', 'wallMs', 'cpuMs'): values[kind + '.' + key] = row[key]
    return values


def paired(records, dimension):
    parents = [record for record in records if record['stage'] == 'online']
    groups = defaultdict(dict)
    for record in parents:
        if dimension == 'repair': key = (record['group'], record['levelId'], record['seed'], record['planningLatency']); condition = record['pathRepair']
        else:
            if record['planningLatency'] == 'measured-wall': continue
            key = (record['group'], record['levelId'], record['seed'], record['pathRepair']); condition = record['planningLatency']
        require(condition not in groups[key], 'Duplicate paired assignment'); groups[key][condition] = record
    left_label, right_label = ('none', 'reachable-v1') if dimension == 'repair' else ('uncharged', 'fixed')
    output = []
    for key, members in sorted(groups.items()):
        require(set(members) == {left_label, right_label}, 'Incomplete registered pair')
        left, right = members[left_label], members[right_label]
        qualified = all(row['status'] == 'completed' and row.get('observation', {}).get('independentTimestampReplayQualified') for row in (left, right))
        row = {'key': list(key), 'left': left['id'], 'right': right['id'], 'leftStatus': left['status'], 'rightStatus': right['status'],
               'qualifiedForDescriptiveDifference': qualified, 'differenceDirection': right_label + ' minus ' + left_label,
               'leftOutcome': left.get('observation', {}).get('outcome'), 'rightOutcome': right.get('observation', {}).get('outcome')}
        if qualified:
            a, b = pair_values(left['observation']), pair_values(right['observation'])
            row['leftMetrics'] = a; row['rightMetrics'] = b
            row['differences'] = {name: b[name] - a[name] for name in sorted(a.keys() & b.keys())
                                  if isinstance(a[name], (int, float)) and isinstance(b[name], (int, float))}
            row['primaryCensors'] = [left['observation']['primaryCensored'], right['observation']['primaryCensored']]
            row['qualityCensors'] = [left['observation']['qualityCensored'], right['observation']['qualityCensored']]
        else: row['exclusion'] = 'One or both original parent/replay pairs lacks completed, provenance-verified exact replay evidence.'
        output.append(row)
    return output


def analyze(root):
    inputs = Inputs(root.resolve()); reg = inputs.json('registration.json')
    manifest, source = verify_source(reg, inputs); children = verify_tasks(reg)
    execution, journal = read_journal(inputs, reg)
    records = [analyze_task(task, reg, manifest, inputs, execution) for task in reg['tasks']]
    by_id = {record['id']: record for record in records}
    for record in records:
        if record['stage'] == 'online' and record.get('observation'):
            child = by_id[children[record['id']]]
            record['observation']['independentTimestampReplayQualified'] = bool(record['status'] == 'completed'
                and record['observation']['recordedEvidenceValid'] and child['status'] == 'completed'
                and (child.get('observation', {}).get('timestampReplay') or {}).get('qualified'))
            record['observation']['fullMasteryWitnessQualified'] = bool(record['observation']['independentTimestampReplayQualified']
                and record['observation'].get('goalEvidence', {}).get('completeMasteryWitnessBeforeReplay'))
    groups = defaultdict(list)
    for record in records:
        groups[f"{record['stage']}/{record['group']}/orb-{record['levelId']}/{record['planningLatency']}/{record['pathRepair']}"].append(record)
    aggregates = {}
    for key, rows in sorted(groups.items()):
        observations = [row['observation'] for row in rows if row.get('observation')]
        aggregates[key] = {'planned': len(rows), 'statuses': dict(Counter(row['status'] for row in rows)),
            'retainedObservations': len(observations), 'outcomes': dict(Counter(row['outcome'] for row in observations)),
            'reasons': dict(Counter(row['reason'] for row in observations)),
            'primaryReached': sum(row['primaryReached'] for row in observations),
            'primaryCensored': sum(row['primaryCensored'] for row in observations),
            'qualityCensored': sum(row['qualityCensored'] for row in observations),
            'fullMasteryWitnessQualified': sum(row.get('fullMasteryWitnessQualified', False) for row in observations),
            'jointConditionsMetAtOrBeforeStop': sum(row.get('goalEvidence', {}).get('jointConditionsMetAtOrBeforeStop', False) for row in observations),
            'qualifiedIndependentReplays': sum(row.get('independentTimestampReplayQualified', False) for row in observations),
            'pieces': SUPPORT.distribution([row['metrics'].get('piecesPlaced') for row in observations]),
            'stoppedAtSeconds': SUPPORT.distribution([row['stoppedAtSeconds'] for row in observations])}
    return {'schemaVersion': 1, 'kind': 'Longer exact joint-mastery charged-timing development analysis',
        'sourceVerification': source, 'plannedTasks': len(reg['tasks']), 'taskStatuses': dict(Counter(record['status'] for record in records)),
        'journal': journal, 'groups': aggregates, 'repairPairs': paired(records, 'repair'), 'latencyPairs': paired(records, 'latency'),
        'tasks': records, 'allPlannedInvocationsCompleted': all(record['status'] == 'completed' for record in records),
        'limits': ['Development seeds9101/9102; no fresh confirmation or human calibration.',
            '192 pieces exceed known necessary inventory floors; this does not demonstrate sufficient legal construction or timing.',
            'Measured-wall rows describe this host and recorded load and run serially in balanced pair order.',
            'Final drained thresholds, timely joint conjunction and replay-qualified complete mastery are separate.',
            'Beam and BFS nodes are heterogeneous work units; no per-node efficiency inference.',
            'Replays consume recorded compute schedules and inputs without invoking the planner or repairer.',
            'Tool completion, recorded trace validity, primary acquisition, terminal completion and quality censoring are separate.',
            'Valid scheduled execution is not browser scheduling or human difficulty validation.',
            'No retuning threshold, significance test or production change is selected from this study.'],
        'inputHashes': dict(sorted(inputs.hashes.items()))}


def synthetic_fixture(root):
    """Small artifact-only fixture: no game code, seeds or campaign outcomes."""
    import copy
    import shutil
    def write(name, value):
        path = root / name; path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(value, indent=2) + '\n')
    def ref(name): return {'path': name, 'sha256': sha((root / name).read_bytes())}
    for name in ('analyze.py', 'analysis-support.py', 'run.py', 'freeze.mjs', 'README.md'):
        shutil.copyfile(ROOT / name, root / name)
    source = {'src/a.js': b'fixture\n', 'package.json': b'{}\n'}
    manifest = {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in source.items()}
    digest = hashlib.sha256()
    with zipfile.ZipFile(root / 'source-snapshot.zip', 'w') as archive:
        for name in sorted(source, key=lambda name: name.encode('utf-16-be')):
            digest.update((name + '\0').encode()); digest.update(source[name]); archive.writestr(name, source[name])
    write('source-manifest.json', manifest); (root / 'source.patch').write_text(''); write('environment.json', {})
    runtime = {'node': 'synthetic', 'platform': 'synthetic', 'arch': 'synthetic'}
    revision = {'head': 'synthetic', 'sourceHash': digest.hexdigest(), 'runtime': runtime}
    tasks = []
    config_base = {'levelId': 49, 'seed': 9101, 'maxPieces': 64, 'reactionMs': 150, 'actionIntervalMs': 100,
        'maxSimSeconds': 1800, 'wallBudgetMs': 120000, 'timingPolicy': 'fixed-cadence', 'maxDecisions': 1024,
        'maxReplansPerPiece': 64, 'beamWidth': 8, 'maxNodes': 360000, 'maxNodesPerPlan': 1200,
        'unknownTailDepth': 1, 'setupStrategy': 'none', 'maxRepairNodes': 4096, 'planningLatency': 'uncharged', 'fixedPlanningMs': 200}
    witness_template = {'schemaVersion': 1, 'kind': 'online-mastery-witness', 'version': 'adaptive-fixed-cadence-v2',
        'status': 'observed', 'levelId': 49, 'seed': 9101, 'outcome': 'censored', 'reason': 'piece-budget',
        'traceValid': True, 'allRecordedLocksComplete': True, 'initialBoardHash': 'synthetic-board', 'commands': [], 'trace': [],
        'decisions': [], 'computeSchedule': [], 'counters': {}, 'nodes': 0, 'plannerNodes': 0, 'repairNodes': 0,
        'plannerWallMs': 0, 'plannerCpuMs': 0, 'repairWallMs': 0, 'repairCpuMs': 0, 'planningChargedMs': 0, 'planningElapsedMs': 0,
        'planningLatency': 'uncharged', 'plannerWallTimeChargedToSimulation': False, 'realtimePlanningFeasibility': 'unverified',
        'primaryReached': False, 'primaryReachedAtPiece': None, 'goalReachedAtSeconds': None, 'stoppedAtSeconds': 1,
        'stopPhase': 'input', 'physicsDrainedThroughSeconds': 1, 'qualityCensored': False, 'maximumDepth': 0,
        'quality': {'timedStars': None, 'tierThreeConditionsMet': False, 'masteryConditionsMet': False, 'censored': False, 'optionalBonuses': []},
        'requirements': {'stars': {'three': {'conditions': GOALS[49]['three']}},
            'primary': {'type': 'score', 'target': 36000, 'timeConstraints': []},
            'finishPolicy': {'showcaseCanContinueAfterPrimary': False}},
        'metrics': {'score': 0, 'piecesPlaced': 0, 'lines': 0, 'cascades': 0, 'tetrises': 0}}
    for task_id in ('none', 'reachable-v1', 'fixed-none', 'fixed-reachable-v1'):
        repair = task_id.removeprefix('fixed-'); latency = 'fixed' if task_id.startswith('fixed-') else 'uncharged'
        folder = 'online/' + task_id
        options = {'command': 'online', 'outputDir': str(root / folder), **config_base, 'pathRepair': repair, 'planningLatency': latency}
        argv = ['node', 'scripts/odyssey-mastery.mjs', 'online']
        reverse = {value: key for key, value in OPTION_FLAGS.items()}
        for key, value in options.items():
            if key != 'command': argv.extend([reverse[key], str(value)])
        parent = {'id': task_id, 'stage': 'online', 'levelId': 49, 'seed': 9101, 'pathRepair': repair,
            'planningLatency': latency, 'fixedPlanningMs': 200, 'group': 'fixture', 'cadence': 'steady',
            'output': folder, 'command': argv, 'expectedOptions': options}
        witness = copy.deepcopy(witness_template); witness['config'] = {key: value for key, value in options.items() if key not in ('command', 'outputDir')}
        witness['planningLatency'] = latency
        write(folder + '/witness.json', witness)
        replay_folder = 'replay/' + task_id; witness_path = folder + '/witness.json'
        replay_options = {'command': 'replay-online', 'outputDir': str(root / replay_folder), 'wallBudgetMs': 120000, 'witnessPath': str(root / witness_path)}
        child = {**parent, 'id': 'replay-' + task_id, 'stage': 'replay-online', 'output': replay_folder, 'dependsOn': task_id,
            'witness': witness_path, 'expectedOptions': replay_options,
            'command': ['node', 'scripts/odyssey-mastery.mjs', 'replay-online', '--witness', str(root / witness_path),
                        '--wall-ms', '120000', '--output', str(root / replay_folder)]}
        replay = copy.deepcopy(witness); replay.update({'kind': 'online-mastery-replay', 'status': 'pass',
            'replayValid': True, 'traceComplete': True, 'expectedExecutionHash': '0' * 64, 'actualExecutionHash': '0' * 64})
        write(replay_folder + '/replay.json', replay)
        witness_data = (root / witness_path).read_bytes(); (root / replay_folder / 'input-witness.json').write_bytes(witness_data)
        for task in (parent, child):
            output = task['output']; replay_input = sha(witness_data) if task['stage'] == 'replay-online' else None
            config = {'schemaVersion': 1, 'options': task['expectedOptions'], 'revision': revision, 'candidateSha256': None, 'witnessSha256': replay_input}
            write(output + '/config.json', config); write(output + '/source-manifest.json', manifest); (root / output / 'source.patch').write_text('')
            filename = RESULT_NAMES[task['stage']]; data = (root / output / filename).read_bytes()
            write(output + '/summary.json', {'status': 'completed', 'sourceStable': True, 'command': task['stage'], 'revision': revision,
                'candidateSha256': None, 'witnessSha256': replay_input, 'result': {'path': filename, 'bytes': len(data), 'sha256': sha(data)}})
        tasks.extend([parent, child])
    phases = [{'id': 'parents', 'workers': 3, 'taskIds': [task['id'] for task in tasks if task['stage'] == 'online']},
              {'id': 'replays', 'workers': 3, 'taskIds': [task['id'] for task in tasks if task['stage'] == 'replay-online']}]
    reg = {'schemaVersion': 1, 'executionReady': True, 'repositoryRoot': '/synthetic',
        'sourceFreeze': {'commit': 'synthetic', 'sourceHash': digest.hexdigest(), 'runtime': runtime,
            'sourceManifest': ref('source-manifest.json'), 'sourceSnapshot': ref('source-snapshot.zip'), 'sourcePatch': ref('source.patch'),
            'analyzerSha256': sha((root / 'analyze.py').read_bytes()), 'analysisSupport': ref('analysis-support.py')},
        'runnerSha256': sha((root / 'run.py').read_bytes()), 'freezeScriptSha256': sha((root / 'freeze.mjs').read_bytes()),
        'protocol': ref('README.md'), 'environment': ref('environment.json'), 'workers': 3,
        'plannedCounts': {'online': 4, 'replay-online': 4}, 'executionPhases': phases, 'tasks': tasks}
    write('registration.json', reg); (root / 'registration.sha256').write_text(sha((root / 'registration.json').read_bytes()) + '\n')
    events = []
    def event(value): events.append({'sequence': len(events), 'at': 'synthetic', **value})
    event({'event': 'run-start'}); by_id = {task['id']: task for task in tasks}
    for phase in phases:
        event({'event': 'phase-start', 'phase': phase['id'], 'workers': phase['workers']})
        for task_id in phase['taskIds']:
            task = by_id[task_id]; event({'event': 'launch', 'id': task_id, 'output': task['output'], 'command': task['command']})
            log = 'logs/' + task_id + '.log'; (root / 'logs').mkdir(exist_ok=True); (root / log).write_text('synthetic\n')
            event({'event': 'exit', 'id': task_id, 'exitCode': 0, 'log': log, 'logSha256': sha((root / log).read_bytes())})
        event({'event': 'phase-complete', 'phase': phase['id']})
    (root / 'events.jsonl').write_text(''.join(json.dumps(item) + '\n' for item in events))
    return reg, witness_template


def self_test():
    import copy
    import shutil
    import tempfile
    import unittest
    class Tests(unittest.TestCase):
        def test_exact_joint_goals_residuals_and_showcase_censors(self):
            result = {'levelId': 55, 'initialBoardHash': 'synthetic-board', 'requirements': {'primary': {'type': 'score', 'target': 250000, 'timeConstraints': [{'type': 'primary-acquisition-deadline', 'seconds': 480}]},
                    'stars': {'three': {'conditions': GOALS[55]['three']}}, 'finishPolicy': {'showcaseCanContinueAfterPrimary': True}},
                'metrics': {'score': 500000, 'cascades': 35, 'maxCascadeDepth': 18, 'maxCombo': 18, 'piecesPlaced': 155},
                'config': {'maxPieces': 192}, 'primaryReached': False, 'primaryReachedAtPiece': None,
                'goalReachedAtSeconds': None, 'stoppedAtSeconds': 481, 'outcome': 'censored', 'reason': 'piece-budget',
                'qualityCensored': False, 'quality': {'masteryConditionsMet': False}, 'trace': []}
            evidence = goal_evidence(result)
            self.assertTrue(evidence['exactThreeStars']['conditionsMet'])
            self.assertFalse(evidence['finalPrimaryAndThreeStarConjunction'])
            self.assertEqual(evidence['showcase']['state'], 'not-entered')
            result.update({'primaryReached': True, 'primaryReachedAtPiece': 150, 'goalReachedAtSeconds': 470,
                           'outcome': 'win', 'qualityCensored': True})
            result['quality']['masteryConditionsMet'] = True
            result['trace'] = [{'completed': True, 'resolvedAtMs': 469000, 'metricsAfter': {'piecesPlaced': 150, 'score': 250000}},
                               {'completed': True, 'resolvedAtMs': 482000, 'metricsAfter': result['metrics']}]
            evidence = goal_evidence(result)
            self.assertTrue(evidence['finalPrimaryAndThreeStarConjunction'])
            self.assertFalse(evidence['jointConditionsMetAtOrBeforeStop'])
            self.assertEqual(evidence['showcase']['state'], 'censored-after-acquisition')
            self.assertEqual(evidence['showcase']['observedPostPrimarySeconds'], 11)
            result['trace'][1]['resolvedAtMs'] = 480000
            result.update({'qualityCensored': False, 'reason': 'manual-showcase-finish'})
            evidence = goal_evidence(result)
            self.assertTrue(evidence['completeMasteryWitnessBeforeReplay'])
            self.assertEqual(evidence['exactPrimary']['deadlineHeadroomAtAcquisitionSeconds'], 10)
            result['goalReachedAtSeconds'] = 480.1
            evidence = goal_evidence(result)
            self.assertFalse(evidence['valid']); self.assertFalse(evidence['finalPrimaryAndThreeStarConjunction'])
            result['goalReachedAtSeconds'] = 470
            result['metrics']['maxCombo'] = 17
            residual = goal_evidence(result)['exactThreeStars']
            self.assertFalse(residual['conditionsMet'])
            self.assertEqual(next(row['remaining'] for row in residual['residual'] if row['key'] == 'combo'), 1)

        def test_charge_accounting_and_projection(self):
            with tempfile.TemporaryDirectory() as temporary:
                root = Path(temporary); _, result = synthetic_fixture(root)
                result['config'] = {'planningLatency': 'fixed', 'fixedPlanningMs': 200, 'maxNodes': 10, 'maxNodesPerPlan': 10,
                                    'maxRepairNodes': 10, 'maxDecisions': 10, 'pathRepair': 'none'}
                result['planningLatency'] = 'fixed'; result['nodes'] = result['plannerNodes'] = 5
                result['plannerWallMs'] = 2; result['plannerCpuMs'] = 1; result['planningChargedMs'] = 200
                result['planningElapsedMs'] = 216.6666666667
                event = {'index': 1, 'kind': 'plan', 'step': 1, 'atMs': 100, 'readyAtMs': 300, 'chargedMs': 200,
                    'computeWallMs': 2, 'observationHash': 'x', 'pose': None, 'actions': [], 'hasActions': False,
                    'settledAtMs': 316.6666666667, 'disposition': 'no-path'}
                result['computeSchedule'] = [event]
                result['decisions'] = [{key: event[key] for key in ('index', 'kind', 'step', 'atMs', 'chargedMs', 'observationHash', 'pose')} |
                    {'plannerWallMs': 2, 'plannerCpuMs': 1, 'repairWallMs': 0, 'repairCpuMs': 0, 'nodes': 5}]
                checks = compute_checks(result); self.assertTrue(checks['validAccounting'], checks)
                self.assertAlmostEqual(checks['simulatedComputeOccupancyMs'], 216.6666666667)
                lock_result = copy.deepcopy(result)
                target = {'shapeKey': 'I', 'x': 1, 'y': 2, 'rotation': 0}
                lock_result['trace'] = [{'step': 1, 'lockedPiece': target,
                    'actions': [{'source': 'repair', 'type': 'hardDrop'}],
                    'targetValidation': {'target': target, 'actual': target, 'targetAchieved': True}}]
                self.assertEqual(compute_checks(lock_result)['repairTargetsAchievedAtLock'], 1)
                lock_result['trace'][0]['targetValidation']['targetAchieved'] = False
                self.assertFalse(compute_checks(lock_result)['validAccounting'])
                for change in ('chargedMs', 'readyAtMs', 'settledAtMs'):
                    modified = copy.deepcopy(result); modified['computeSchedule'][0][change] = -1
                    self.assertFalse(compute_checks(modified)['validAccounting'], change)
                replay = copy.deepcopy(result); replay.update({'status': 'pass', 'replayValid': True, 'traceComplete': True,
                    'expectedExecutionHash': '0' * 64, 'actualExecutionHash': '0' * 64})
                self.assertTrue(describe(replay, result)['timestampReplay']['qualified'])
                for key in PROJECTION_KEYS:
                    modified = copy.deepcopy(replay)
                    if key == 'computeSchedule': modified[key][0]['target'] = {'x': 99}
                    elif key in ('commands', 'trace', 'metrics', 'quality'): continue
                    else: modified[key] = 'changed'
                    try: qualified = describe(modified, result)['timestampReplay']['qualified']
                    except (ValueError, TypeError): qualified = False
                    self.assertFalse(qualified, key)

        def test_portable_provenance_pairing_and_unknown_exit(self):
            with tempfile.TemporaryDirectory() as temporary:
                root = Path(temporary) / 'fixture'; root.mkdir(); reg, _ = synthetic_fixture(root)
                inputs = Inputs(root); manifest, _ = verify_source(reg, inputs); children = verify_tasks(reg)
                execution, journal = read_journal(inputs, reg)
                records = [analyze_task(task, reg, manifest, inputs, execution) for task in reg['tasks']]
                self.assertEqual(Counter(item['status'] for item in records), {'completed': 8})
                self.assertTrue(records[1]['observation']['timestampReplay']['qualified'])
                full_analysis = analyze(root)
                self.assertEqual(full_analysis['taskStatuses'], {'completed': 8})
                self.assertEqual(sum(row['qualifiedForDescriptiveDifference'] for row in full_analysis['repairPairs']), 2)
                moved = Path(temporary) / 'moved'; shutil.copytree(root, moved)
                moved_inputs = Inputs(moved); verify_source(reg, moved_inputs)
                moved_execution, moved_journal = read_journal(moved_inputs, reg)
                self.assertEqual(journal, moved_journal)
                self.assertEqual(records, [analyze_task(task, reg, manifest, moved_inputs, moved_execution) for task in reg['tasks']])
                self.assertEqual(full_analysis, analyze(moved))
                unknown = copy.deepcopy(execution); unknown['none'] = {'status': 'interrupted-unknown'}
                self.assertEqual(analyze_task(reg['tasks'][0], reg, manifest, inputs, unknown)['status'], 'completed-exit-unknown')
                bad_exit = copy.deepcopy(execution); bad_exit['none']['exitCode'] = 1
                self.assertEqual(analyze_task(reg['tasks'][0], reg, manifest, inputs, bad_exit)['status'], 'execution-contradiction')
                for field, value in [('dependsOn', 'unknown'), ('witness', 'online/other/witness.json'), ('seed', 9102)]:
                    broken = copy.deepcopy(reg); broken['tasks'][1][field] = value
                    with self.assertRaises(ValueError, msg=field): verify_tasks(broken)
                (moved / 'analysis-support.py').write_text('changed')
                with self.assertRaises(ValueError): verify_source(reg, Inputs(moved))

        def test_torn_journal_retains_prefix_and_missing_launch(self):
            with tempfile.TemporaryDirectory() as temporary:
                root = Path(temporary); reg, _ = synthetic_fixture(root)
                path = root / 'events.jsonl'; original = path.read_bytes()
                lines = original.splitlines(keepends=True)
                # Preserve the final launched replay but tear its exit event.
                path.write_bytes(b''.join(lines[:-2]) + b'{"event":"exit",')
                records, journal = read_journal(Inputs(root), reg)
                self.assertTrue(journal['tornTail'])
                self.assertEqual(records['replay-fixed-reachable-v1']['status'], 'interrupted-unknown')
                self.assertEqual(records['none']['exitCode'], 0)
                path.write_bytes(b'not-json\n' + original)
                with self.assertRaises(ValueError): read_journal(Inputs(root), reg)
                events = [json.loads(line) for line in original.splitlines()]
                events[1]['phase'] = 'replays'
                path.write_text(''.join(json.dumps(item) + '\n' for item in events))
                with self.assertRaisesRegex(ValueError, 'Phase order'): read_journal(Inputs(root), reg)
                events = [json.loads(line) for line in original.splitlines()]
                changed = copy.deepcopy(reg); changed['executionPhases'][0]['id'] = 'measured-wall-parents'
                changed['executionPhases'][0]['workers'] = 1
                for event in events:
                    if event.get('phase') == 'parents':
                        event['phase'] = 'measured-wall-parents'
                        if 'workers' in event: event['workers'] = 1
                path.write_text(''.join(json.dumps(item) + '\n' for item in events))
                with self.assertRaisesRegex(ValueError, 'lacks environment evidence'): read_journal(Inputs(root), changed)

        def test_source_and_result_tampering(self):
            with tempfile.TemporaryDirectory() as temporary:
                root = Path(temporary); reg, _ = synthetic_fixture(root); inputs = Inputs(root)
                manifest, _ = verify_source(reg, inputs); execution, _ = read_journal(inputs, reg)
                (root / 'online/none/witness.json').write_text('{}\n')
                row = analyze_task(reg['tasks'][0], reg, manifest, inputs, execution)
                self.assertEqual(row['status'], 'verification-error')
                (root / 'source-snapshot.zip').write_bytes(b'changed')
                with self.assertRaises(ValueError): verify_source(reg, Inputs(root))

        def test_pair_inclusion_requires_both_replays(self):
            rows = []
            for repair in ('none', 'reachable-v1'):
                for latency in ('uncharged', 'fixed'):
                    rows.append({'id': repair + latency, 'stage': 'online', 'group': 'fixture', 'levelId': 49, 'seed': 9101,
                        'pathRepair': repair, 'planningLatency': latency, 'status': 'completed',
                        'observation': {'independentTimestampReplayQualified': True, 'metrics': {'piecesPlaced': 64},
                            'primaryCensored': True, 'qualityCensored': False}})
            self.assertEqual(len(paired(rows, 'repair')), 2); self.assertEqual(len(paired(rows, 'latency')), 2)
            self.assertTrue(all(row['qualifiedForDescriptiveDifference'] for row in paired(rows, 'repair')))
            rows[0]['status'] = 'completed-exit-unknown'
            pairs = paired(rows, 'repair')
            self.assertEqual(sum(row['qualifiedForDescriptiveDifference'] for row in pairs), 1)
            self.assertEqual(len(pairs), 2)

    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
    return result.wasSuccessful()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT); parser.add_argument('--output', type=Path)
    parser.add_argument('--verify-only', action='store_true'); parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test: raise SystemExit(0 if self_test() else 1)
    if args.verify_only:
        inputs = Inputs(args.root.resolve()); reg = inputs.json('registration.json')
        _, source = verify_source(reg, inputs); verify_tasks(reg)
        print(json.dumps(source, sort_keys=True)); return
    result = analyze(args.root)
    output = args.output or args.root / 'analysis.json'
    with output.open('x') as handle:
        json.dump(result, handle, indent=2, sort_keys=True); handle.write('\n')
    print(json.dumps({'plannedTasks': result['plannedTasks'], 'taskStatuses': result['taskStatuses']}, indent=2))


if __name__ == '__main__':
    main()


