#!/usr/bin/env python3
"""Recorded-trace arithmetic, copied before new outcomes; no game execution."""
import math
import statistics

def distribution(values):
    values = [value for value in values if isinstance(value, (int, float))]
    if not values:
        return {'count': 0, 'sum': 0, 'median': None, 'p90NearestRank': None, 'maximum': None}
    ordered = sorted(values)
    return {'count': len(values), 'sum': sum(values), 'median': statistics.median(values),
            'p90NearestRank': ordered[math.ceil(.9 * len(values)) - 1], 'maximum': max(values)}



def online_trace_checks(result):
    config = result.get('config', {})
    trace = result.get('trace', [])
    commands = result.get('commands', [])
    completed = [entry for entry in trace if entry.get('completed')]
    errors = []
    previous_hash = result.get('initialBoardHash')
    for entry in trace:
        if previous_hash is not None and entry.get('boardHashBefore') != previous_hash:
            errors.append({'step': entry.get('step'), 'kind': 'board-continuity'})
        previous_hash = entry.get('boardHashAfter')
        if len(entry.get('preview', [])) != 3:
            errors.append({'step': entry.get('step'), 'kind': 'preview-count'})
        for action in entry.get('actions', []):
            if action['atMs'] + 1e-7 < entry['spawnAtMs'] + config.get('reactionMs', 0):
                errors.append({'step': entry.get('step'), 'kind': 'reaction-gate'})
        if entry.get('completed'):
            piece = entry.get('lockedPiece', {})
            if sum(bool(cell) for row in piece.get('shape', []) for cell in row) != 4:
                errors.append({'step': entry.get('step'), 'kind': 'non-tetromino'})
            cell = entry.get('cellConservation', {})
            if not cell.get('valid') or cell.get('overlap') or cell.get('expected') != cell.get('actual'):
                errors.append({'step': entry.get('step'), 'kind': 'conservation'})
    if [action for entry in trace for action in entry.get('actions', [])] != commands:
        errors.append({'kind': 'command-trace-projection'})
    for before, after in zip(commands, commands[1:]):
        if after['atMs'] <= before['atMs'] or after['atMs'] - before['atMs'] + 1e-7 < config.get('actionIntervalMs', 0):
            errors.append({'kind': 'action-cadence'})
    if any(command['atMs'] > result.get('stoppedAtSeconds', float('inf')) * 1000 + 1e-7 for command in commands):
        errors.append({'kind': 'command-after-terminal'})
    metrics = result.get('metrics')
    if metrics:
        observed = {'piecesPlaced': len(completed), 'lines': sum(sum(entry['lineClears']) for entry in completed),
                    'cascades': sum(len(entry['lineClears']) >= 2 for entry in completed),
                    'tetrises': sum(value == 4 for entry in completed for value in entry['lineClears'])}
        for key, value in observed.items():
            if metrics.get(key) != value:
                errors.append({'kind': 'trace-metric', 'metric': key, 'computed': value, 'reported': metrics.get(key)})
    return {'validRecordedEvidence': not errors, 'errors': errors, 'spawnedEntries': len(trace),
            'completedLocks': len(completed), 'unlockedEntries': sum(not entry.get('lockedPiece') for entry in trace),
            'lockedIncompleteEntries': sum(bool(entry.get('lockedPiece')) and not entry.get('completed') for entry in trace),
            'rejectedInputs': sum(not command.get('accepted') and not command.get('legalStop') for command in commands),
            'groundedStops': sum(bool(command.get('legalStop')) for command in commands),
            'automaticLocks': sum(entry.get('lockSource') == 'automatic' for entry in trace),
            'interpretation': 'Rejected commands and automatic locks are recorded online events, not automatically invalid traces. Production timestamp replay validates execution.'}



def independently_met(conditions, metrics, bonus_count=0, untimed=False):
    aliases = {"combo": "maxCombo", "cascade": "cascades", "max-cascade-depth": "maxCascadeDepth",
               "tetris-count": "tetrises", "pieces": "piecesPlaced", "maxDeaths": "deaths"}
    details = []
    for name, target in conditions.items():
        if untimed and name == "time":
            continue
        actual = bonus_count if name == "bonuses" else metrics.get(aliases.get(name, name), 0)
        actual = 0 if actual is None else actual
        upper = name in ("time", "maxDeaths")
        met = actual <= target if upper else actual >= target
        details.append({"key": name, "target": target, "actual": actual, "upperBound": upper,
                        "met": met, "remaining": max(0, actual - target if upper else target - actual)})
    return {"conditionsMet": bool(details) and all(item["met"] for item in details), "residual": details}


