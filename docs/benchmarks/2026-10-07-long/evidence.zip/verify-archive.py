"""Fresh extraction must reproduce the frozen analysis and independent audit."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parent
DESTINATION = ROOT.parent.parent / 'docs/benchmarks/2026-10-07-long'
manifest_path = DESTINATION / 'manifest.json'
manifest = json.loads(manifest_path.read_text())
archive_path = DESTINATION / manifest['archive']['path']
sha = lambda data: hashlib.sha256(data).hexdigest()
assert archive_path.stat().st_size == manifest['archive']['bytes']
assert sha(archive_path.read_bytes()) == manifest['archive']['sha256']
extracted = Path(tempfile.mkdtemp(prefix='odyssey-long-verified-'))
expected = {entry['path']: entry for entry in manifest['files']}
with zipfile.ZipFile(archive_path) as archive:
    assert len(archive.namelist()) == len(expected) and set(archive.namelist()) == set(expected)
    for name, entry in expected.items():
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
        data = archive.read(name)
        assert len(data) == entry['bytes'] and sha(data) == entry['sha256'], name
    archive.extractall(extracted)
subprocess.run(['python3', str(extracted / 'analyze.py'), '--output',
                str(extracted / 'regenerated-analysis.json')], check=True)
assert (extracted / 'analysis.json').read_bytes() == (extracted / 'regenerated-analysis.json').read_bytes()
subprocess.run(['python3', str(extracted / 'independent-audit/audit.py'), '--root', str(extracted),
                '--output', str(extracted / 'regenerated-raw-audit.json')], check=True)
original = json.loads((extracted / 'independent-audit/result-audit.json').read_text())
regenerated = json.loads((extracted / 'regenerated-raw-audit.json').read_text())
assert original.pop('auditedAt') and regenerated.pop('auditedAt')
assert original == regenerated and regenerated['allChecksPassed']
construction = extracted / 'construction-review'
diagnostic = subprocess.check_output(['python3', str(construction / 'residual-bounds.py')])
assert diagnostic == (construction / 'residual-bounds.json').read_bytes()
verification = {
    'verifiedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'archiveHashVerified': True,
    'memberCount': len(expected),
    'everyMemberBytesAndHashVerified': True,
    'frozenAnalysisReproducesByteForByte': True,
    'independentRawAuditReproduces': True,
    'rawAuditExcludedFields': ['auditedAt'],
    'constructionDiagnosticReproducesByteForByte': True,
    'verificationContext': 'Fresh temporary extraction using only archived analysis, source and evidence inputs.',
}
manifest['independentVerification'] = verification
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'extractedTo': str(extracted), **verification}, indent=2))
