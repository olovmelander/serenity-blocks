#!/usr/bin/env python3
"""Run one frozen cohort once; durable append-only events, no automatic recovery."""
import argparse
import concurrent.futures
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import threading
import time

ROOT = Path(__file__).resolve().parent


def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_new(path, data):
    with path.open('x') as handle:
        json.dump(data, handle, indent=2, sort_keys=True)
        handle.write('\n'); handle.flush(); os.fsync(handle.fileno())


class Journal:
    def __init__(self, path):
        self.handle = path.open('x')
        self.lock = threading.Lock()
        self.index = 0

    def append(self, event):
        with self.lock:
            event = {'sequence': self.index, 'at': stamp(), **event}
            self.handle.write(json.dumps(event, sort_keys=True) + '\n')
            self.handle.flush(); os.fsync(self.handle.fileno())
            self.index += 1
            print(json.dumps(event, sort_keys=True), flush=True)


def environment():
    process = subprocess.run(['ps', '-eo', 'pid,ppid,pcpu,comm'], capture_output=True, text=True, check=True)
    cpu = Path('/proc/cpuinfo')
    return {'at': stamp(), 'logicalCpus': os.cpu_count(),
            'affinityCpus': sorted(os.sched_getaffinity(0)) if hasattr(os, 'sched_getaffinity') else None,
            'loadAverage': os.getloadavg(), 'cpuInfo': cpu.read_text() if cpu.exists() else None,
            'processInventory': process.stdout}


def invoke(task, registration, journal):
    task_id = task['id']
    folder = ROOT / task['output']
    log_path = ROOT / 'logs' / (task_id + '.log')
    input_name = task.get('witness')
    if input_name and not (ROOT / input_name).is_file():
        result = {'id': task_id, 'status': 'skipped', 'reason': 'Parent did not retain a witness', 'output': task['output']}
        journal.append({'event': 'skipped', **result})
        return result
    if folder.exists() or log_path.exists():
        raise RuntimeError('Refusing pre-existing task output/log: ' + task_id)
    started = time.monotonic()
    journal.append({'event': 'launch', 'id': task_id, 'output': task['output'], 'command': task['command']})
    child = None
    try:
        with log_path.open('x') as log:
            child = subprocess.Popen(task['command'], cwd=registration['repositoryRoot'], stdout=log, stderr=subprocess.STDOUT)
            journal.append({'event': 'spawned', 'id': task_id, 'pid': child.pid})
            exit_code = child.wait()
            log.flush(); os.fsync(log.fileno())
        result = {'id': task_id, 'status': 'exited', 'exitCode': exit_code, 'output': task['output'],
                  'elapsedWallSeconds': time.monotonic() - started,
                  'log': str(log_path.relative_to(ROOT)), 'logSha256': digest(log_path)}
        journal.append({'event': 'exit', **result})
        return result
    except Exception as error:
        # Bookkeeping failure must not release a worker while its child keeps
        # computing: stop and reap before the next task can occupy this slot.
        if child is not None and child.poll() is None:
            child.terminate()
            try:
                child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                child.kill(); child.wait()
        result = {'id': task_id, 'status': 'runner-error', 'error': repr(error), 'output': task['output']}
        journal.append({'event': 'runner-error', **result})
        return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute-frozen', action='store_true')
    parser.add_argument('--serial-compute-window-confirmed', action='store_true',
                        help='Operator has stopped tests and other benchmark work for measured-wall phase.')
    args = parser.parse_args()
    if not args.execute_frozen or not args.serial_compute_window_confirmed:
        parser.error('Require both --execute-frozen and --serial-compute-window-confirmed')
    registration = json.loads((ROOT / 'registration.json').read_text())
    assert registration['executionReady'] is True
    assert digest(ROOT / 'registration.json') == (ROOT / 'registration.sha256').read_text().split()[0]
    assert digest(Path(__file__)) == registration['runnerSha256']
    assert registration['workers'] == 3
    for task in registration['tasks']:
        assert not (ROOT / task['output']).exists(), 'Refusing existing task output'
        assert not (ROOT / 'logs' / (task['id'] + '.log')).exists(), 'Refusing existing task log'
    assert not (ROOT / 'execution.json').exists(), 'Refusing prior execution summary'
    # Run provenance-only verification before launching any campaign game code.
    subprocess.run(['python3', str(ROOT / 'analyze.py'), '--verify-only'], check=True)
    live = subprocess.check_output(['node', '--input-type=module', '-e',
        "import {captureSourceRevision} from './scripts/odyssey-mastery.mjs'; console.log(JSON.stringify(captureSourceRevision()));"],
        cwd=registration['repositoryRoot'], text=True)
    live = json.loads(live)
    for key, expected in [('head', registration['sourceFreeze']['commit']), ('sourceHash', registration['sourceFreeze']['sourceHash']),
                          ('runtime', registration['sourceFreeze']['runtime'])]:
        assert live['revision'][key] == expected, 'Live source/runtime differs: ' + key
    write_new(ROOT / 'execution-source-check.json', {'at': stamp(), **live})
    (ROOT / 'logs').mkdir(exist_ok=True)
    journal = Journal(ROOT / 'events.jsonl')
    journal.append({'event': 'run-start', 'workers': 3, 'operatorSerialWindowConfirmed': True})
    records = []
    by_id = {task['id']: task for task in registration['tasks']}
    for phase in registration['executionPhases']:
        journal.append({'event': 'phase-start', 'phase': phase['id'], 'workers': phase['workers']})
        if phase['id'] == 'measured-wall-parents':
            write_new(ROOT / 'measured-wall-environment-before.json', environment())
        # Futures are collected inside the phase, so no earlier benchmark task
        # can overlap the serial measured-wall parents.
        if phase['workers'] == 1:
            for task_id in phase['taskIds']:
                records.append(invoke(by_id[task_id], registration, journal))
        else:
            with concurrent.futures.ThreadPoolExecutor(max_workers=phase['workers']) as pool:
                futures = [pool.submit(invoke, by_id[task_id], registration, journal) for task_id in phase['taskIds']]
                for future in concurrent.futures.as_completed(futures):
                    records.append(future.result())
        if phase['id'] == 'measured-wall-parents':
            write_new(ROOT / 'measured-wall-environment-after.json', environment())
        journal.append({'event': 'phase-complete', 'phase': phase['id']})
    records.sort(key=lambda row: next(i for i, task in enumerate(registration['tasks']) if task['id'] == row['id']))
    write_new(ROOT / 'execution.json', records)
    journal.append({'event': 'run-complete', 'tasks': len(records), 'executionSha256': digest(ROOT / 'execution.json')})
    journal.handle.close()


if __name__ == '__main__':
    main()
