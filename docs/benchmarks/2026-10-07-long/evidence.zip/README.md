# Longer Odyssey joint-mastery development protocol

This protocol fixes a bounded construction-and-execution question on unchanged
production rules. The preceding 64-piece screen could not supply the known
necessary three-star inventories. This study allows 192 pieces, retains exact
joint goals, and compares experimental reachable-target repair with its no-repair
control while charging measured planning and repair wall time. It is not an
ordinary-player success-rate estimate, policy adoption trial or human playtest.

Registration is frozen only after scaffold review and the root agent's explicit
source-ready authorization. The freezer never launches gameplay. The protocol
checkpoint is committed before freeze. No outcomes from this cohort are examined
before registration. Previously observed development seeds 9101/9102 are reused;
confirmation seeds 11001 and above remain untouched.

## Assignments and fixed budgets

Twelve online parents cover orbs 49/55/59 × seeds 9101/9102 × repair `none` or
`reachable-v1`. Each has a separately invoked timestamp replay: 24 total tasks.
All parents use `planningLatency: measured-wall`; the inactive fixed-delay value
remains the CLI default 200 ms and is not charged. `setupStrategy: none` isolates
the repair condition and does not claim specialized deep-chain construction.

Each parent receives 192 pieces, beam width 8, 1,200 beam transitions per full
plan, 1,440,000 shared plan-plus-repair nodes, 4,096 decisions, 64 decisions per
piece, 4,096 BFS nodes per repair, one unknown-tail surrogate, three visible
previews, 150 ms reaction, 100 ms action intervals, 1,800 simulated seconds and
360,000 ms process wall budget. Every independent replay has a 120,000 ms wall
budget. Repair BFS nodes and beam transitions are heterogeneous units; there is
no per-node efficiency inference. Larger total budgets support the longer fixed
horizon and are not an unbounded search or an adaptive response to its outcomes.

All twelve parents run serially in this balanced order:

| Pair order | Orb | Seed | First policy | Second policy |
| --- | ---: | ---: | --- | --- |
| 1 | 49 | 9101 | none | reachable-v1 |
| 2 | 55 | 9101 | reachable-v1 | none |
| 3 | 59 | 9101 | none | reachable-v1 |
| 4 | 49 | 9102 | reachable-v1 | none |
| 5 | 55 | 9102 | none | reachable-v1 |
| 6 | 59 | 9102 | reachable-v1 | none |

No tests or other benchmark work run during the parent phase. CPU/runtime/load
and process inventory are recorded before and after. Serial execution reduces
campaign contention, without asserting an idle host. All twelve replays follow,
using at most three workers and consuming saved schedules without invoking or
remeasuring the planner. The parent wall-budget sum is 72 minutes; four replay
batches add at most eight minutes of assigned wall budgets, plus startup, final
physics drainage and evidence overhead. Those are limits, not predicted runtime.

## Exact authored goals and evidence

| Orb | Primary acquisition | Full three stars | Finish semantics | Necessary piece floor |
| --- | --- | --- | --- | ---: |
| 49 | score ≥36,000 | score ≥36,000 AND Quads ≥12 AND chain depth ≥8 | ordinary automatic finish after primary resolution | 130 |
| 55 | score ≥250,000 by 480 s | score ≥500,000 AND cascade sequences ≥35 AND maxCascadeDepth ≥10 AND combo ≥18 (effective chain depth 18) | showcase continues after primary | 155 |
| 59 | score ≥160,000 by 210 s | score ≥260,000 AND cascade sequences ≥25 AND maxCascadeDepth ≥7 AND combo ≥12 (effective chain depth 12) | showcase continues after primary | 140 |

`combo` and `maxCascadeDepth` both observe peak single-piece cascade-wave ordinal;
the duplicate authored conditions remain individually reported. Orb 55's optional
20-Quad bonus is not a three-star requirement. Requiring every optional bonus
would need at least 305 pieces by the existing necessary supply bound.

The 130/155/140 floors are necessary inventory relaxations, not legal construction
proofs, sufficient budgets or timing guarantees. Orb 49's fully drained standard
board plus trigger holds at most 224 usable cells, excluding five Quad waves in
an eight-wave terminal chain. Its surviving arithmetic routes remain geometrically
unproven. The study preserves all exact targets and does not inject prepared cells.

The analyzer retains every assignment and each observed exit state. For every
parent and replay it reports provenance, conservation, commands, compute windows,
repair target completion, primary acquisition piece/time, stop reason, primary
censor, post-primary showcase observation state, and quality censor. It reports
primary score residual and deadline headroom separately from every exact three-star
condition residual. Thresholds first seen after terminal cutoff during mandatory
physics drainage do not become a timely primary acquisition or qualified mastery
witness. Primary history is not erased when showcase time exceeds its acquisition
deadline. Final metric conjunction, timely conjunction and independently replayed
complete mastery witness remain distinct fields.

Before primary acquisition, a deadline or top-out is a recorded loss. A budget stop before primary is a
censored primary observation, not proof of player defeat or impossible goals.
A budget stop after showcase acquisition preserves the primary win while censoring
quality observation. False quality-censor flags before primary do not imply an
observed showcase. Automatic locks and rejected commands are retained execution
events, not automatically invalid traces.

Every repair pair remains listed, including incomplete or excluded members.
Descriptive differences require both original parents and passing exact independent
replays. Report score, Quads, sequences, depth, goal residuals, pieces, simulated
time, full-plan/repair costs, actual simulated compute occupancy, stale work,
rejected inputs and target-lock checks. Changed trajectories, durations and stopping
points prevent a causal speedup or gameplay quality claim. There is no pooled
population efficacy, significance test, adoption threshold or production retune.

## Source, interruption and reproduction

The freezer stores committed production source, full-path/NUL hash, runtime,
commands/options, this protocol, analyzer dependencies and runner. Source must
match the preceding tested implementation's source hash. It copies immutable
prior validation provenance/logs and includes only relevant text test/config
sources in a compact validation snapshot; the unrelated binary validation fixtures
are not duplicated. Those copied test results are inherited evidence, not new tests.

The runner verifies all frozen bytes and live source before launching. Task outputs,
logs and registration are exclusive. Its append-only launch/completion/skip journal
is flushed and fsynced. No retries, resumes, seed substitutions or replacements
occur in the original cohort. Preserve partial files and unknown exit codes; any
recovery needs a separately registered cohort. Portable analysis reads only archived
inputs, includes all censors and can reproduce byte for byte after relocation.
Synthetic self-tests are excluded from gameplay results.

Measured wall cost remains host/load specific, and legacy virtual 60 Hz simulation
is not canonical fixed60-v1 or direct browser scheduling. Replay validates a recorded
simulator schedule, not main-thread responsiveness, player skill, enjoyment or fair
challenge. A legal full joint witness and human sessions remain separate evidence
needs. The existing player protocol and blank template are ready; this campaign
does not invent player sessions.
