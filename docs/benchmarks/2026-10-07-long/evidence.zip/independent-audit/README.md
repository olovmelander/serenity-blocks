# Independent long-mastery audit

Prepared and snapshotted before registration or outcome review. See `development-history.json` for immutable pre-outcome snapshots. The auditor imports neither the frozen main analyzer nor game/planner modules and launches no benchmark.

After campaign completion:

```sh
python3 independent-audit/audit.py --self-test
python3 independent-audit/audit.py
```

Run from an extracted study directory with Python standard library and Node. Node is used only for canonical JavaScript JSON serialization of independently compared replay projections. No repository or installed dependencies are needed.

The retained authored oracle contains only initialization, scoring and rules from prior independently verified initialization. Every one of its 1,172 production source fingerprints must match the frozen snapshot. Current source matched before this auditor was snapshotted; played outcomes from the prior study are not part of the oracle.

Checks cover all 24 assignments, exact conditions and budgets, counterbalanced serial parent order and three-worker replay phase, durable events and exit observations, source/config/input/result hashes, all 17 replay projection fields, every completed-lock conservation/count/score calculation, measured-wall computation windows and charged normal-loop timing, stale-result ownership, repaired target retention and fully consumed path locks, shared node budgets, authored primary acquisition and exact three-star predicates, optional-bonus separation, deadlines and budget/showcase censoring. Residuals report each authored condition independently; they are not additive effort estimates.

`inventory-bounds.json` records unchanged necessary supply floors and source references. The 192-piece allowance exceeds the 130/155/140 floors; it is not sufficient construction or timing evidence. Orb55's optional 20-Quad bonus is outside the exact three-star goal and raises the joint necessary supply floor to305 pieces if additionally required.

Every invocation remains in the denominator. Missing/partial outcomes and unknown process exits are not invented authored losses. Any later recovery needs separate registration and an explicitly disclosed audit revision. Original observations cannot be replaced silently.

Serial measured-wall runs remain host/load specific. No replay proves browser scheduling or player enjoyment, challenge, skill or real-time feasibility. Repair acceptance differs from completing the entire path at its exact target. Shared BFS/beam nodes use different units and are not interchangeable efficiency measurements. All audit check counts include parents and independent replays separately.
