#!/usr/bin/env python3
"""Independent study auditor. No campaign analyzer imports or planner/physics execution.

Authored initialization oracle is retained from the prior independent frozen-source
initialization and guarded by every production source fingerprint. Runtime result
files are read only when explicitly invoked after campaign completion. Synthetic
self-tests never count as campaign observations.
"""
import argparse
from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import subprocess
import zipfile

FILENAMES = {'search': 'candidate.json', 'replay': 'replay.json',
             'online': 'witness.json', 'replay-online': 'replay.json'}
COUNTER_KEYS = ('piecesPlaced', 'lines', 'singles', 'doubles', 'triples', 'tetrises',
                'cascades', 'combos', 'maxCombo', 'maxCascadeDepth')
PROJECTION_KEYS = ('levelId', 'seed', 'initialBoardHash', 'commands', 'trace', 'outcome',
                   'reason', 'qualityCensored', 'primaryReachedAtPiece', 'primaryReached',
                   'goalReachedAtSeconds', 'stoppedAtSeconds', 'stopPhase',
                   'physicsDrainedThroughSeconds', 'metrics', 'quality', 'computeSchedule')
BUDGET_REASONS = {'piece-budget', 'simulation-budget', 'wall-budget', 'node-budget', 'decision-budget'}
PIECES = {'I', 'J', 'L', 'O', 'S', 'T', 'Z'}
EPSILON = 1e-6

def digest(data):
    return hashlib.sha256(data).hexdigest()


def pose(piece):
    return {key: piece.get(key, 0 if key == 'rotation' else None)
            for key in ('shapeKey', 'x', 'y', 'rotation')} if piece else None


def command_valid(command):
    kind = command.get('type')
    return kind in ('softDrop', 'hardDrop') or (kind == 'move' and command.get('dir') in (-1, 1)) \
        or (kind == 'rotate' and command.get('dir') in ('left', 'right', 'flip'))


def bonus_met(bonus, metrics, top_out=False):
    key = bonus['type']
    aliases = {'max-cascade-depth': 'maxCascadeDepth', 'tetris-count': 'tetrises',
               'cascade': 'cascades', 'combo': 'maxCombo'}
    if key in aliases:
        return metrics.get(aliases[key], 0) >= bonus['target']
    if key == 'no-singles':
        return metrics.get('singles', 0) == 0
    if key == 'no-top-out':
        return not top_out and metrics.get('deaths', 0) == 0
    if key in ('pieces', 'time'):
        return (metrics.get('piecesPlaced' if key == 'pieces' else 'time') or 0) <= bonus['target']
    raise ValueError('Unknown bonus: ' + key)


def tier_met(conditions, metrics, bonuses, timed):
    for key, target in conditions.items():
        if key == 'time' and not timed:
            continue
        metric = {'combo': 'maxCombo', 'maxDeaths': 'deaths'}.get(key, key)
        actual = sum(bonuses) if key == 'bonuses' else (metrics.get(metric) or 0)
        if key in ('time', 'maxDeaths'):
            if actual > target:
                return False
        elif actual < target:
            return False
    return True


def calculate_score(lines, level, ordinal, perfect):
    base = {1: 250, 2: 500, 3: 1000, 4: 2000}.get(lines, 200 * lines * lines)
    subtotal = base + 200 * max(0, ordinal - 1) ** 2
    if perfect:
        subtotal += lines * 1250 if lines <= 4 else lines * lines * 500
    return subtotal + math.floor(subtotal * 0.1 * level)


def qualify(result, stage, primary, tier_three):
    """Raw metric predicates are separate from a complete, independently replayed win."""
    if stage == 'search':
        return bool(result.get('traceValid') and result.get('quality', {}).get('qualified')
                    and primary and tier_three)
    return bool(result.get('replayValid') and result.get('traceComplete')
                and result.get('outcome') == 'win' and not result.get('qualityCensored')
                and not result.get('quality', {}).get('censored') and primary and tier_three)


def residuals(conditions, metrics, bonuses):
    """Independent per-condition gaps; they are not additive effort estimates."""
    result = {}
    for key, target in conditions.items():
        metric = {'combo': 'maxCombo', 'maxDeaths': 'deaths'}.get(key, key)
        actual = sum(bonuses) if key == 'bonuses' else (metrics.get(metric) or 0)
        upper = key in ('time', 'maxDeaths')
        gap = max(0, actual - target) if upper else max(0, target - actual)
        result[key] = {'metric': metric, 'target': target, 'actual': actual,
                       'operator': '<=' if upper else '>=', 'remaining': gap, 'met': gap == 0}
    return result


class Audit:
    def __init__(self, root):
        self.root = root
        self.errors = []
        self.input_hashes = {}
        self.lock_checks = 0
        self.command_checks = 0
        self.compute_checks = 0
        self.completed_repaired_targets = 0
        self.results = []
        self.raw_results = {}

    def check(self, condition, scope, message):
        if not condition:
            self.errors.append({'scope': scope, 'message': message})
        return bool(condition)

    def read_bytes(self, relative):
        data = (self.root / relative).read_bytes()
        self.input_hashes[str(relative)] = digest(data)
        return data

    def read(self, relative):
        return json.loads(self.read_bytes(relative))

    def freeze(self):
        registration = self.read('registration.json')
        self.check(digest(self.read_bytes('registration.json')) ==
                   self.read_bytes('registration.sha256').decode().split()[0], 'freeze', 'Registration digest mismatch')
        frozen = registration['sourceFreeze']
        refs = [frozen[key] for key in ('sourceManifest', 'sourceSnapshot', 'sourcePatch', 'analysisSupport')]
        refs += [frozen[key] for key in ('validationSource', 'validationManifest', 'inheritedValidation')]
        refs += [registration['protocol'], registration['environment']]
        for item in refs:
            self.check(digest(self.read_bytes(item['path'])) == item['sha256'], 'freeze', 'Changed frozen artifact: ' + item['path'])
        for name, expected in [('analyze.py', frozen['analyzerSha256']), ('run.py', registration['runnerSha256']),
                               ('freeze.mjs', registration['freezeScriptSha256'])]:
            self.check(digest(self.read_bytes(name)) == expected, 'freeze', 'Frozen scaffold changed: ' + name)
        self.manifest = self.read(frozen['sourceManifest']['path'])
        combined = hashlib.sha256()
        with zipfile.ZipFile(self.root / frozen['sourceSnapshot']['path']) as archive:
            self.check(set(archive.namelist()) == set(self.manifest), 'freeze', 'Snapshot member set differs')
            for name in sorted(self.manifest, key=lambda value: value.encode('utf-16-be')):
                data = archive.read(name)
                self.check(self.manifest[name] == {'bytes': len(data), 'sha256': digest(data)}, 'freeze',
                           'Snapshot source differs: ' + name)
                combined.update((name + '\0').encode()); combined.update(data)
        self.check(combined.hexdigest() == frozen['sourceHash'], 'freeze', 'Combined source hash differs')
        validation_manifest = self.read(frozen['validationManifest']['path'])
        with zipfile.ZipFile(self.root / frozen['validationSource']['path']) as archive:
            self.check(set(archive.namelist()) == set(validation_manifest), 'freeze', 'Validation-source member set differs')
            for name, expected in validation_manifest.items():
                data = archive.read(name)
                self.check({'bytes': len(data), 'sha256': digest(data)} == expected, 'freeze', 'Validation source changed: ' + name)
        inherited = self.read(frozen['inheritedValidation']['path'])
        for name, expected in inherited['files'].items():
            data = self.read_bytes(name)
            self.check({'bytes': len(data), 'sha256': digest(data)} == expected, 'freeze', 'Inherited validation changed: ' + name)
        prior = self.read('prior-validation/registration.json')
        self.check(prior['sourceFreeze']['sourceHash'] == frozen['sourceHash'], 'freeze', 'Inherited tested source differs')
        oracle = self.read('independent-audit/authored-oracle.json')
        self.check({key: val for key, val in self.manifest.items() if key.startswith('src/')}
                   == oracle['productionSourceManifest'], 'freeze', 'Production changed since authored initialization oracle')
        self.initial = {(item['levelId'], item['seed']): item for item in oracle['initialBoards']}
        for level, floor in ((49, 130), (55, 155), (59, 140)):
            authored = self.initial[(level, 9101)]
            failure = authored['victory'].get('failure', {})
            expected = {'primaryScore': authored['victory']['primary']['target'],
                        'deadlineSeconds': failure.get('value') if failure.get('type') == 'time' else None,
                        'three': authored['stars']['three'], 'necessaryPieceFloor': floor}
            self.check(registration['exactGoals'][str(level)] == expected, 'matrix', 'Registered joint goal differs from authored oracle')
        tasks = registration['tasks']
        self.check(len(tasks) == len({task['id'] for task in tasks}) == 24, 'matrix', 'Expected24 distinct assignments')
        self.check(Counter(task['stage'] for task in tasks) == {'online': 12, 'replay-online': 12},
                   'matrix', 'Expected12 parents and12 replays')
        expected = {(level, seed, repair, latency) for level in (49, 55, 59) for seed in (9101, 9102)
                    for repair in ('none', 'reachable-v1') for latency in ('measured-wall',)}
        self.check({(task['levelId'], task['seed'], task['pathRepair'], task['planningLatency'])
                    for task in tasks if task['stage'] == 'online'} == expected, 'matrix', 'Study matrix differs')
        for task in tasks:
            if task['stage'] == 'online':
                opts = task['expectedOptions']
                required = {'maxPieces': 192, 'beamWidth': 8, 'maxNodes': 1440000, 'maxNodesPerPlan': 1200,
                            'maxRepairNodes': 4096, 'maxDecisions': 4096, 'maxReplansPerPiece': 64,
                            'unknownTailDepth': 1, 'setupStrategy': 'none', 'reactionMs': 150,
                            'actionIntervalMs': 100, 'maxSimSeconds': 1800, 'wallBudgetMs': 360000}
                self.check(all(opts.get(key) == value for key, value in required.items()), task['id'], 'Unexpected registered budget')
                self.check(opts['pathRepair'] == task['pathRepair'] and opts['planningLatency'] == task['planningLatency'],
                           task['id'], 'Condition labels differ from CLI options')
                if opts['planningLatency'] == 'fixed':
                    self.check(opts['fixedPlanningMs'] == 200, task['id'], 'Fixed arm does not charge200ms')
        pair_order = [(49, 9101, ('none', 'reachable-v1')), (55, 9101, ('reachable-v1', 'none')),
                      (59, 9101, ('none', 'reachable-v1')), (49, 9102, ('reachable-v1', 'none')),
                      (55, 9102, ('none', 'reachable-v1')), (59, 9102, ('reachable-v1', 'none'))]
        phases = registration['executionPhases']
        self.check(len(phases) == 2 and phases[0]['id'] == 'measured-wall-parents'
                   and phases[0]['workers'] == 1 and phases[1]['workers'] == 3,
                   'matrix', 'Expected serial measured parents before three-worker replays')
        by_id = {task['id']: task for task in tasks}
        actual_order = [(by_id[key]['levelId'], by_id[key]['seed'], by_id[key]['pathRepair'])
                        for key in phases[0]['taskIds']]
        expected_order = [(level, seed, repair) for level, seed, repairs in pair_order for repair in repairs]
        self.check(actual_order == expected_order, 'matrix', 'Predeclared counterbalanced pair order differs')
        self.check(len(phases[1]['taskIds']) == 12 and all(by_id[key]['stage'] == 'replay-online'
                   for key in phases[1]['taskIds']), 'matrix', 'Second phase must contain every independent replay')
        self.registration = registration
        return registration

    def journal(self):
        events = [json.loads(line) for line in self.read_bytes('events.jsonl').splitlines() if line]
        assignments = {task['id']: task for task in self.registration['tasks']}
        per_task = {key: [] for key in assignments}
        active = set()
        current_phase = None
        phases = {item['id']: item for item in self.registration['executionPhases']}
        seen_phases = []
        launch_order = []
        observed = {}
        previous_at = None
        for index, event in enumerate(events):
            self.check(event['sequence'] == index, 'journal', 'Nonsequential append-only event index')
            at = datetime.fromisoformat(event['at'])
            self.check(previous_at is None or at >= previous_at, 'journal', 'Journal timestamp decreased')
            previous_at = at
            kind = event['event']
            if kind == 'phase-start':
                self.check(not active and current_phase is None, 'journal', 'Overlapping execution phases')
                current_phase = event['phase']; seen_phases.append(current_phase)
                self.check(event['workers'] == phases[current_phase]['workers'], 'journal', 'Phase worker cap changed')
            elif kind == 'phase-complete':
                self.check(not active and current_phase == event['phase'], 'journal', 'Phase completed with active children')
                current_phase = None
            if 'id' not in event:
                continue
            task_id = event['id']
            self.check(task_id in assignments, 'journal', 'Unknown invocation in journal')
            per_task.setdefault(task_id, []).append(event)
            if kind == 'launch':
                self.check(task_id not in active and task_id not in launch_order, task_id, 'Invocation launched more than once')
                self.check(current_phase is not None and task_id in phases[current_phase]['taskIds'], task_id, 'Launch outside assigned phase')
                active.add(task_id); launch_order.append(task_id)
                self.check(len(active) <= phases[current_phase]['workers'], 'journal', 'Concurrent invocations exceed phase cap')
                self.check(event['command'] == assignments[task_id]['command'], task_id, 'Launched command differs')
            elif kind in ('exit', 'runner-error'):
                self.check(task_id in active, task_id, 'Terminal invocation event has no active launch')
                active.discard(task_id)
                self.check(task_id not in observed, task_id, 'Duplicate terminal journal event')
                observed[task_id] = event
                if kind == 'exit':
                    self.check(digest(self.read_bytes(event['log'])) == event['logSha256'], task_id, 'Invocation log hash differs')
            elif kind == 'skipped':
                self.check(task_id not in observed and task_id not in active, task_id, 'Skipped invocation was already launched')
                observed[task_id] = event
        self.check(seen_phases == [item['id'] for item in self.registration['executionPhases']], 'journal', 'Execution phase order differs')
        measured = phases['measured-wall-parents']['taskIds']
        self.check([item for item in launch_order if item in measured] == measured, 'journal', 'Measured serial order differs')
        for name in ('measured-wall-environment-before.json', 'measured-wall-environment-after.json'):
            data = self.read(name)
            self.check(bool(data.get('processInventory')) and bool(data.get('cpuInfo')) and len(data.get('loadAverage', [])) == 3,
                       'journal', 'Measured-wall environment snapshot incomplete')
        execution_path = self.root / 'execution.json'
        if execution_path.exists():
            execution = self.read('execution.json')
            self.check(len(execution) == len({row['id'] for row in execution}) == 24, 'journal', 'Execution assignment accounting differs')
            for row in execution:
                event = observed.get(row['id'])
                self.check(event is not None and all(event.get(key) == value for key, value in row.items()),
                           row['id'], 'Execution summary conflicts with durable terminal observation')
            final = [event for event in events if event['event'] == 'run-complete']
            self.check(len(final) == 1 and final[0]['executionSha256'] == self.input_hashes['execution.json'],
                       'journal', 'Run-complete execution digest differs')
        # Preserve incomplete observations without assigning an invented process exit or authored loss.
        for task_id in assignments:
            if task_id not in observed:
                observed[task_id] = {'status': 'interrupted' if task_id in launch_order else 'not-launched',
                                     'exitCode': None, 'exitCodeObserved': False}
        self.executions = observed
        return observed

    def computation(self, result, task):
        scope = task['id']
        config = result['config']; schedule = result['computeSchedule']; commands = result['commands']
        frame = 1000 / 60
        tolerance = 2e-5
        def on_frame(value):
            return abs(value - round(value / frame) * frame) < tolerance
        def close(a, b):
            return abs(a - b) <= tolerance
        entries = {entry['step']: entry for entry in result['trace']}
        by_event_commands = {event['index']: [] for event in schedule}
        previous = None
        for index, event in enumerate(schedule, 1):
            event_scope = scope + '/compute-' + str(index)
            self.compute_checks += 1
            self.check(event['index'] == index and event['kind'] in ('plan', 'repair'), event_scope, 'Invalid computation identity')
            self.check(on_frame(event['atMs']) and event['atMs'] >= 0, event_scope, 'Computation did not start on normal input frame')
            self.check(event['step'] in entries and event['pose']['shapeKey'] == entries[event['step']]['shapeKey'],
                       event_scope, 'Computation does not own recorded piece')
            entry = entries[event['step']]
            self.check(event['boardHash'] == entry['boardHashBefore'], event_scope, 'Computation board differs from falling-piece board')
            self.check(event['atMs'] + tolerance >= entry['spawnAtMs'] + config['reactionMs'], event_scope, 'Computation bypassed spawn reaction')
            before_commands = [command for command in commands if command['atMs'] < event['atMs'] - tolerance]
            if before_commands:
                self.check(event['atMs'] + tolerance >= before_commands[-1]['atMs'] + config['actionIntervalMs'],
                           event_scope, 'Computation began before next eligible input slot')
            duration = event['computeWallMs']
            self.check(math.isfinite(duration) and duration >= 0, event_scope, 'Invalid measured computation duration')
            charge = {'uncharged': 0, 'fixed': config['fixedPlanningMs'], 'measured-wall': duration}[config['planningLatency']]
            self.check(close(event['chargedMs'], charge) and close(event['readyAtMs'], event['atMs'] + charge),
                       event_scope, 'Charged duration does not match declared latency model')
            settled = event['settledAtMs']; disposition = event['disposition']
            self.check(isinstance(settled, (float, int)) and settled + tolerance >= event['atMs'], event_scope, 'Missing/backward computation settlement')
            if previous:
                self.check(event['atMs'] > previous['settledAtMs'] - tolerance, event_scope, 'Overlapping computation windows')
            if disposition == 'interrupted':
                self.check(close(settled, result['stoppedAtSeconds'] * 1000) and index == len(schedule),
                           event_scope, 'Interrupted computation was not the terminal pending call')
            elif charge == 0:
                self.check(close(settled, event['atMs']), event_scope, 'Uncharged computation release was delayed')
            else:
                # Input precedes normal logic. Readiness must have been processed by the previous full logic frame.
                first_logic = math.ceil((event['readyAtMs'] - tolerance) / frame) * frame
                self.check(on_frame(settled) and close(settled, first_logic + frame),
                           event_scope, 'Positive charge did not release first frame after normal logic reached readiness')
            for command in commands:
                self.check(not (event['atMs'] - tolerance <= command['atMs'] < settled - tolerance),
                           event_scope, 'Input occurred while computation was pending')
            self.check(event['hasActions'] == bool(event['actions']) and all(command_valid(command) for command in event['actions']),
                       event_scope, 'Computation action metadata/vocabulary differs')
            same_step = event.get('settledStep') == event['step']
            same_board = event.get('settledBoardHash') == event['boardHash']
            same_pose = event.get('settledPose') == event['pose']
            lock_before_settle = entry.get('lockAtMs') is not None and entry['lockAtMs'] <= settled + tolerance
            if disposition == 'stale-piece':
                self.check(not same_step or lock_before_settle, event_scope, 'Piece staleness has no recorded ownership/lock witness')
            elif disposition == 'stale-board':
                self.check(same_step and not same_board and not lock_before_settle, event_scope, 'Board staleness misclassified')
            elif disposition == 'stale-pose':
                self.check(same_step and same_board and not same_pose and not lock_before_settle, event_scope, 'Pose staleness misclassified')
            elif disposition in ('accepted', 'no-path'):
                self.check(same_step and same_board and same_pose and not event['error'], event_scope, 'Stale/errored computation was applied')
                self.check((disposition == 'accepted') == event['hasActions'], event_scope, 'Accepted/no-path mismatch')
            else:
                self.check(disposition in ('error', 'interrupted'), event_scope, 'Unknown computation disposition')
            if event['kind'] == 'repair':
                self.check(config['pathRepair'] == 'reachable-v1' and event['target'] is not None,
                           event_scope, 'Repair missing opt-in or exact target')
                self.check(previous is not None and previous['step'] == event['step']
                           and previous['boardHash'] == event['boardHash'] and previous['target'] == event['target']
                           and previous['disposition'] in ('accepted', 'stale-pose'),
                           event_scope, 'Repair changed the retained target or stale board/piece ownership')
                if event['hasActions']:
                    self.check(event['actions'][-1]['type'] == 'hardDrop', event_scope, 'Reachable repair lacks final drop')
                self.check(event.get('repairStatus') in ('reachable', 'unreachable', 'budget'), event_scope, 'Repair status missing')
                self.check(event['hasActions'] == (event.get('repairStatus') == 'reachable'), event_scope, 'Reachability status/actions disagree')
            previous = event
        for command in commands:
            self.check(on_frame(command['atMs']), scope, 'Command did not occur on regular60Hz input frame')
            eligible = [event for event in schedule if event['atMs'] <= command['atMs'] + tolerance]
            latest = eligible[-1] if eligible else None
            if command['source'] in ('planner', 'repair'):
                good = latest is not None and latest['disposition'] == 'accepted' and latest['settledAtMs'] <= command['atMs'] + tolerance
                good = good and latest['step'] == command['step'] and ('repair' if latest['kind'] == 'repair' else 'planner') == command['source']
                if self.check(good, scope, 'Command consumed a stale/missing/unready computational result'):
                    issued = by_event_commands[latest['index']]
                    offset = len(issued)
                    self.check(offset < len(latest['actions']) and all(command.get(key) == latest['actions'][offset].get(key)
                               for key in ('type', 'dir')), scope, 'Command differs from retained computed action prefix')
                    issued.append(command)
            else:
                self.check(command['source'] == 'fallback' and command['type'] == 'hardDrop', scope, 'Unrecognized input source')
        for event in schedule:
            issued = by_event_commands[event['index']]
            if event['kind'] == 'repair' and len(issued) == len(event['actions']) and issued and issued[-1]['accepted']:
                actual = entries[event['step']].get('lockedPiece')
                self.check(pose(actual) == pose(event['target']), scope, 'Completed repaired path missed exact target orientation/pose')
                if event['target'].get('shape') is not None:
                    self.check(actual and actual.get('shape') == event['target']['shape'], scope, 'Completed repair changed target shape')
                validation = entries[event['step']].get('targetValidation')
                self.check(validation is not None and validation.get('targetAchieved') is True,
                           scope, 'Completed repaired hard drop lacks exact-target validation')
                if validation:
                    self.check(validation.get('target') == event['target'] and validation.get('actual') == pose(actual),
                               scope, 'Target-validation witness differs from retained target/actual lock')
                self.completed_repaired_targets += 1
        if task['stage'] == 'online':
            decisions = result['decisions']
            self.check(len(decisions) == len(schedule), scope, 'Decision/computation count differs')
            used = 0
            for decision, event in zip(decisions, schedule):
                self.check(all(decision.get(key) == event.get(key) for key in
                               ('index', 'kind', 'step', 'atMs', 'pose', 'observationHash', 'chargedMs')),
                           scope, 'Decision and computation identity mismatch')
                self.check(len(decision['preview']) == 3 and set(decision['preview']) <= PIECES, scope, 'Decision preview boundary differs')
                allowance = min(config['maxRepairNodes'] if event['kind'] == 'repair' else config['maxNodesPerPlan'], config['maxNodes'] - used)
                self.check(isinstance(decision['nodes'], int) and 0 <= decision['nodes'] <= allowance, scope, 'Computation exceeded bounded shared nodes')
                used += decision['nodes']
                prefix = 'repair' if event['kind'] == 'repair' else 'planner'
                other = 'planner' if prefix == 'repair' else 'repair'
                self.check(close(decision[prefix + 'WallMs'], event['computeWallMs'])
                           and decision[other + 'WallMs'] == decision[other + 'CpuMs'] == 0,
                           scope, 'Planner/repair cost attribution differs')
                self.check(decision[prefix + 'CpuMs'] >= 0, scope, 'Negative CPU duration')
            for prefix, kind in (('planner', 'plan'), ('repair', 'repair')):
                selected = [decision for decision in decisions if decision['kind'] == kind]
                for suffix in ('WallMs', 'CpuMs'):
                    self.check(close(result[prefix + suffix], sum(item[prefix + suffix] for item in selected)),
                               scope, 'Computation cost aggregate differs: ' + prefix + suffix)
                self.check(result[prefix + 'Nodes'] == sum(item['nodes'] for item in selected), scope, 'Node-kind aggregate differs')
            self.check(used == result['nodes'] == result['plannerNodes'] + result['repairNodes'], scope, 'Total shared nodes differ')
            counters = result['counters']
            predicates = {
                'planningCalls': lambda e: e['kind'] == 'plan',
                'repairAttempts': lambda e: e['kind'] == 'repair',
                'repairSuccesses': lambda e: e['kind'] == 'repair' and e['disposition'] == 'accepted',
                'repairFailures': lambda e: e['kind'] == 'repair' and e['disposition'] == 'no-path',
                'staleComputations': lambda e: e['disposition'].startswith('stale-'),
            }
            for key, predicate in predicates.items():
                self.check(counters[key] == sum(predicate(event) for event in schedule), scope, 'Computation counter differs: ' + key)
        self.check(close(result['planningChargedMs'], sum(event['chargedMs'] for event in schedule)), scope, 'Charged-delay aggregate differs')
        self.check(close(result['planningElapsedMs'], sum(event['settledAtMs'] - event['atMs'] for event in schedule)),
                   scope, 'Actual pending-window occupancy differs')
        return {'computationWindows': len(schedule), 'dispositions': dict(Counter(event['disposition'] for event in schedule)),
                'repairDispositions': dict(Counter(event['disposition'] for event in schedule if event['kind'] == 'repair')),
                'planningChargedMs': result['planningChargedMs']}

    def metrics(self, result, task, initial):
        scope = task['id']
        counts = {key: 0 for key in COUNTER_KEYS}
        previous_hash = initial['hash']
        previous_score = 0
        scoring = dict(initial['scoring'])
        timed = task['stage'] in ('online', 'replay-online')
        completed = 0
        all_actions = []
        for index, entry in enumerate(result.get('trace', []), 1):
            entry_scope = f'{scope}/piece-{index}'
            self.check(entry['step'] == index, entry_scope, 'Piece index discontinuity')
            self.check(len(entry.get('preview', [])) == 3 and set(entry['preview']) <= PIECES,
                       entry_scope, 'Preview scope is not exactly three legal pieces')
            self.check(entry.get('shapeKey') in PIECES, entry_scope, 'Invalid tetromino name')
            self.check(entry.get('boardHashBefore') == previous_hash, entry_scope, 'Board hash continuity mismatch')
            for command in entry.get('actions', []):
                self.command_checks += 1
                self.check(command_valid(command), entry_scope, 'Invalid command vocabulary')
                if task['stage'] in ('search', 'replay'):
                    self.check(command.get('accepted') or command.get('legalStop'), entry_scope, 'Rejected construction input')
                all_actions.append(command)
            if not entry.get('lockedPiece'):
                self.check(not entry.get('completed'), entry_scope, 'Completed piece has no lock')
                continue
            piece = entry['lockedPiece']
            cells = sum(bool(cell) for row in piece['shape'] for cell in row)
            self.check(cells == 4, entry_scope, 'Recorded lock is not a four-cell tetromino')
            if not entry.get('completed'):
                continue
            completed += 1
            counts['piecesPlaced'] += 1
            waves = entry.get('lineClears', [])
            counts['lines'] += sum(waves)
            for width, key in ((1, 'singles'), (2, 'doubles'), (3, 'triples'), (4, 'tetrises')):
                counts[key] += waves.count(width)
            if len(waves) >= 2:
                counts['cascades'] += 1
                counts['combos'] += len(waves) - 1
                counts['maxCombo'] = max(counts['maxCombo'], len(waves))
                counts['maxCascadeDepth'] = max(counts['maxCascadeDepth'], len(waves))
            observed = entry['metricsAfter']
            for key, value in counts.items():
                self.check(observed.get(key) == value, entry_scope, 'Cumulative metric mismatch: ' + key)
            self.check(observed['score'] >= previous_score, entry_scope, 'Score decreased')
            score_before = previous_score
            previous_score = observed['score']
            conservation = entry['cellConservation']
            expected = initial['cells'] + 4 * observed['piecesPlaced'] - initial['columns'] * observed['lines']
            self.check(conservation['expected'] == expected, entry_scope, 'Cell equation differs from authored inventory')
            self.check(conservation['actual'] == expected, entry_scope, 'Actual cell count violates conservation')
            if 'visible' in conservation:
                self.check(conservation['actual'] == conservation['visible'] + conservation['offBoard'],
                           entry_scope, 'Visible plus off-board cell count mismatch')
                self.check(conservation['valid'] and not conservation['overlap'], entry_scope, 'Replay reports overlap/invalid cells')
            line_score = 0
            multiplier = scoring['comboMultiplier'] if scoring['comboMultiplierEnabled'] else 1
            for ordinal, width in enumerate(waves, 1):
                self.check(isinstance(width, int) and width > 0, entry_scope, 'Invalid line-clear width')
                scoring['linesUntilNextLevel'] -= width
                if scoring['linesUntilNextLevel'] <= 0:
                    if not scoring['disableLevelProgression']:
                        scoring['level'] += 1
                    scoring['linesUntilNextLevel'] += 15
                raw_points = calculate_score(width, scoring['level'], ordinal, False)
                line_score += math.floor(raw_points * multiplier + 0.5)
            if waves and conservation['actual'] == 0:
                depth = sum(waves)
                bonus = calculate_score(depth, scoring['level'], len(waves), True) \
                    - calculate_score(depth, scoring['level'], len(waves), False)
                line_score += math.floor(bonus * multiplier + 0.5)
            inferred_lock_bonus = observed['score'] - score_before - line_score
            self.check((0 <= inferred_lock_bonus <= 50) if timed else inferred_lock_bonus == 50,
                       entry_scope, 'Score differs from independent clear/perfect-clear model and allowed lock bonus')
            if scoring['comboMultiplierEnabled']:
                scoring['comboCount'] = scoring['comboCount'] + 1 if waves else 0
                scoring['comboMultiplier'] = 1 + scoring['comboCount'] * 0.5
            self.lock_checks += 1
            previous_hash = entry['boardHashAfter']
        final = result.get('metrics')
        if final:
            for key, value in counts.items():
                self.check(final.get(key) == value, scope, 'Final metric differs from recorded completed locks: ' + key)
            self.check(final['score'] == previous_score, scope, 'Final score differs from last fully resolved lock')
        if task['stage'] in ('online', 'replay-online') and result.get('traceValid'):
            self.check(all_actions == result['commands'], scope, 'Flat timestamp log differs from per-piece input log')
            previous_time = -1.0
            entries = {entry['step']: entry for entry in result['trace']}
            cadence = result['config']
            for event in result['commands']:
                self.check(event['atMs'] > previous_time, scope, 'Command timestamps are not strictly increasing')
                if previous_time >= 0:
                    self.check(event['atMs'] - previous_time + EPSILON >= cadence['actionIntervalMs'],
                               scope, 'Input cadence violated')
                previous_time = event['atMs']
                entry = entries[event['step']]
                self.check(event['atMs'] + EPSILON >= entry['spawnAtMs'] + cadence['reactionMs'],
                           scope, 'Spawn reaction delay violated')
                self.check(event['atMs'] <= result['stoppedAtSeconds'] * 1000 + EPSILON,
                           scope, 'Command occurs after the recorded stop')
                if entry.get('lockAtMs') is not None:
                    self.check(event['atMs'] <= entry['lockAtMs'] + EPSILON, scope, 'Command occurs after its piece locked')
            counters = result['counters']
            self.check(counters['automaticLocks'] == sum(entry.get('lockSource') == 'automatic'
                       for entry in result['trace']), scope, 'Automatic-lock count mismatch')
            self.check(counters['rejectedInputs'] == sum(not event['accepted'] and not event['legalStop']
                       for event in result['commands']), scope, 'Rejected-input count mismatch')
            self.check(counters['groundedStops'] == sum(bool(event['legalStop']) for event in result['commands']),
                       scope, 'Grounded-stop count mismatch')
            self.check(result['plannerWallTimeChargedToSimulation'] == (cadence['planningLatency'] == 'measured-wall')
                       and result['realtimePlanningFeasibility'] == 'unverified', scope, 'Timing qualification was overstated')
        return completed

    def quality(self, result, task, initial):
        scope = task['id']
        metrics = result.get('metrics')
        if not metrics:
            return {'qualifiedMastery': False, 'unavailable': True}
        stage = task['stage']
        timed = stage in ('online', 'replay-online')
        top_out = bool(result.get('topOut')) or result.get('reason') in ('top-out', 'showcase-top-out')
        bonuses = [bonus_met(bonus, metrics, top_out) if timed or bonus['type'] != 'time' else False
                   for bonus in initial['victory'].get('bonuses', [])]
        tiers = {tier: tier_met(initial['stars'][tier], metrics, bonuses, timed)
                 for tier in ('one', 'two', 'three')}
        quality = result['quality']
        requirements = result.get('requirements', {})
        for tier in ('one', 'two', 'three'):
            self.check(requirements.get('stars', {}).get(tier, {}).get('conditions') == initial['stars'][tier],
                       scope, 'Reported star requirements differ from frozen authored conditions: ' + tier)
        primary_definition = requirements.get('primary', {})
        self.check(all(primary_definition.get(key) == value for key, value in initial['victory']['primary'].items()),
                   scope, 'Reported primary requirements differ from frozen authored conditions')
        primary = bool(quality.get('primaryReachedUntimed')) if stage == 'search' else bool(result['primaryReached'])
        reached_piece = result.get('primaryReachedAtPiece')
        self.check(primary == (reached_piece is not None), scope, 'Primary flag and acquisition piece disagree')
        if primary:
            matching = [entry for entry in result['trace'] if entry.get('completed')
                        and entry['metricsAfter']['piecesPlaced'] == reached_piece]
            self.check(len(matching) == 1, scope, 'Acquisition piece is not one completed recorded lock')
            if matching:
                acquisition = matching[0]
                self.check(acquisition['metricsAfter']['score'] >= initial['victory']['primary']['target'],
                           scope, 'Primary acquired below the authored score goal')
                if timed:
                    at = result['goalReachedAtSeconds']
                    self.check(at + EPSILON >= acquisition['resolvedAtMs'] / 1000,
                               scope, 'Primary acquired before physics resolved')
                    failure = initial['victory'].get('failure', {})
                    if failure.get('type') == 'time':
                        self.check(at <= failure['value'] + EPSILON, scope, 'Primary acquired after its deadline')
            if initial['victoryLapPolicy'] != 'showcase':
                self.check(metrics['piecesPlaced'] == reached_piece, scope, 'Ordinary orb continued after primary finish')
        if timed:
            stop = result['stoppedAtSeconds']
            failure = initial['victory'].get('failure', {})
            deadline = failure.get('value') if failure.get('type') == 'time' else None
            eligible_before_stop = [entry for entry in result['trace'] if entry.get('completed')
                                    and entry['metricsAfter']['score'] >= initial['victory']['primary']['target']
                                    and entry['resolvedAtMs'] / 1000 < stop - EPSILON
                                    and (deadline is None or entry['resolvedAtMs'] / 1000 <= deadline + EPSILON)]
            self.check(primary or not eligible_before_stop, scope,
                       'Primary falsely absent despite an eligible completed lock strictly before the cutoff')
            reason = result.get('reason')
            if reason == 'deadline':
                self.check(deadline is not None and stop + EPSILON >= deadline and not primary
                           and result['outcome'] == 'loss' and not result['qualityCensored'],
                           scope, 'Authored deadline termination differs from pre-primary loss')
            if reason == 'primary-goal':
                self.check(initial['victoryLapPolicy'] != 'showcase' and primary
                           and result['outcome'] == 'win' and not result['qualityCensored'],
                           scope, 'Ordinary primary finish misclassified')
            if reason == 'manual-showcase-finish':
                self.check(initial['victoryLapPolicy'] == 'showcase' and primary and tiers['three']
                           and result['outcome'] == 'win' and not result['qualityCensored'],
                           scope, 'Explicit showcase finish lacks full acquired three-star result')
            if primary and initial['victoryLapPolicy'] == 'showcase':
                self.check(result['outcome'] == 'win', scope,
                           'Already acquired showcase primary was lost at later deadline or cutoff')
            if reason in ('top-out', 'showcase-top-out'):
                self.check(result['outcome'] == ('win' if primary else 'loss')
                           and (reason == 'showcase-top-out') == primary, scope,
                           'Top-out outcome does not preserve acquired showcase primary')
        if stage == 'search':
            self.check(quality['tierThreeUntimedConditionsMet'] == tiers['three'], scope, 'Search tier-three mismatch')
            self.check(quality['masteryUntimedConditionsMet'] == qualify(result, stage, primary, tiers['three']),
                       scope, 'Search mastery qualifier mismatch')
            self.check(quality['timedStars'] is None, scope, 'Untimed search awards timed stars')
            self.check(result['status'] == ('candidate' if qualify(result, stage, primary, tiers['three']) else 'inconclusive'),
                       scope, 'Search status overstates qualification')
        else:
            for tier, met in tiers.items():
                self.check(quality['tiers'][tier]['conditionsMet'] == met, scope, 'Raw tier predicate mismatch: ' + tier)
            self.check(quality['tierThreeConditionsMet'] == tiers['three'], scope, 'Tier-three aggregate mismatch')
            self.check(quality['masteryConditionsMet'] == (primary and tiers['three']),
                       scope, 'Observed mastery conjunction mismatch')
            stars = max([0] + [index for index, tier in enumerate(('one', 'two', 'three'), 1) if tiers[tier]])
            self.check(quality['timedStars'] == (stars if timed else None), scope, 'Raw star count mismatch')
            self.check(quality['censored'] == bool(result.get('qualityCensored')), scope, 'Censoring flags disagree')
            if stage in ('online', 'replay-online'):
                budget_stop = result.get('reason') in BUDGET_REASONS
                if budget_stop:
                    self.check(result['outcome'] == ('win' if primary else 'censored'), scope, 'Budget outcome misclassified')
                    self.check(result['qualityCensored'] == primary, scope, 'Post-primary budget quality censoring mismatch')
                if result.get('outcome') == 'win':
                    self.check(primary, scope, 'Win without acquired primary')
            for index, bonus in enumerate(initial['victory'].get('bonuses', [])):
                expected = bonuses[index] if timed or bonus['type'] != 'time' else None
                self.check(quality['optionalBonuses'][index]['conditionMet'] == expected,
                           scope, 'Optional bonus predicate mismatch: ' + bonus['type'])
        deadline = initial['victory'].get('failure', {})
        deadline = deadline.get('value') if deadline.get('type') == 'time' else None
        return {'primaryReached': primary, 'rawTierThreeConditionsMet': tiers['three'],
                'authoredPrimaryResidual': residuals({'score': initial['victory']['primary']['target']}, metrics, bonuses),
                'authoredTierThreeResiduals': residuals(initial['stars']['three'], metrics, bonuses),
                'primaryDeadlineSeconds': deadline,
                'primaryDeadlineAppliesUntilAcquired': deadline is not None,
                'postPrimaryShowcase': primary and initial['victoryLapPolicy'] == 'showcase',
                'qualificationScope': {'search': 'untimed-search-candidate', 'replay': 'independent-untimed-replay',
                                       'online': 'raw-online-observation-only',
                                       'replay-online': 'independent-timed-timestamp-replay'}[stage],
                'qualityCensored': bool(result.get('qualityCensored')),
                'qualifiedMastery': qualify(result, stage, primary, tiers['three']),
                'rawStars': quality.get('timedStars'), 'allOptionalBonusesMet': all(bonuses)}

    def task(self, task):
        scope = task['id']; output = task['output']; execution = self.executions[scope]
        basic = {key: task.get(key) for key in ('id', 'stage', 'levelId', 'seed', 'pathRepair', 'planningLatency', 'group')}
        basic.update({'runnerStatus': execution.get('status'), 'exitCode': execution.get('exitCode'),
                      'exitCodeObserved': execution.get('event') == 'exit', 'observationAvailable': False,
                      'qualifiedMastery': False})
        if not (self.root / output / 'summary.json').exists():
            self.results.append({**basic, 'resultStatus': 'unavailable', 'authoredLoss': False})
            return
        config = self.read(output + '/config.json'); summary = self.read(output + '/summary.json')
        frozen = self.registration['sourceFreeze']
        for container in (config, summary):
            for key, value in [('sourceHash', frozen['sourceHash']), ('head', frozen['commit']), ('runtime', frozen['runtime'])]:
                self.check(container['revision'][key] == value, scope, 'Invocation revision differs: ' + key)
        self.check(config['options'] == task['expectedOptions'], scope, 'Executed configuration differs from registration')
        self.check(summary['status'] == 'completed' and summary['sourceStable'] is True, scope, 'CLI completion/source instability')
        self.check(self.read(output + '/source-manifest.json') == self.manifest, scope, 'Invocation manifest differs')
        self.check(digest(self.read_bytes(output + '/source.patch')) == frozen['sourcePatch']['sha256'], scope, 'Invocation source patch differs')
        filename = 'witness.json' if task['stage'] == 'online' else 'replay.json'
        data = self.read_bytes(output + '/' + filename); result = json.loads(data)
        self.check(summary['result'] == {'path': filename, 'bytes': len(data), 'sha256': digest(data)}, scope, 'Result digest differs')
        self.check(result['levelId'] == task['levelId'] and result['seed'] == task['seed'], scope, 'Result identity differs')
        self.raw_results[scope] = result
        if result.get('traceValid') is not True:
            completed_entries = [entry for entry in result.get('trace', []) if entry.get('completed')]
            completed = 0
            if completed_entries:
                # A later harness error must not hide an already completed lock.
                prefix_result = {**result, 'metrics': completed_entries[-1]['metricsAfter']}
                completed = self.metrics(prefix_result, task, self.initial[(task['levelId'], task['seed'])])
            self.results.append({**basic, 'observationAvailable': True, 'resultStatus': result['status'],
                                 'outcome': result.get('outcome'), 'reason': result.get('reason'), 'traceValid': False,
                                 'completedLocks': completed, 'authoredLoss': False})
            return
        self.check(result['version'] == 'adaptive-fixed-cadence-v2', scope, 'Unexpected witness execution version')
        self.check(result['previewLimit'] == 3 and result['knowledgePolicy'] == 'current-plus-three-preview-receding-horizon',
                   scope, 'Declared observation boundary differs')
        expected_config = task['expectedOptions'] if task['stage'] == 'online' else None
        if expected_config:
            self.check(all(result['config'].get(key) == value for key, value in expected_config.items()
                           if key not in ('command', 'outputDir')), scope, 'Runtime condition differs from CLI configuration')
        initial = self.initial[(task['levelId'], task['seed'])]
        self.check(result['initialBoardHash'] == initial['hash'], scope, 'Authored initial hash differs')
        if task['stage'] == 'replay-online':
            parent_bytes = self.read_bytes(task['witness']); parent = json.loads(parent_bytes)
            self.check(self.read_bytes(output + '/input-witness.json') == parent_bytes, scope, 'Copied replay witness differs')
            self.check(config['witnessSha256'] == digest(parent_bytes), scope, 'Replay input fingerprint differs')
            actual = {key: result.get(key) for key in PROJECTION_KEYS}
            expected = {key: parent.get(key) for key in PROJECTION_KEYS}
            self.check(actual == expected and result['config'] == parent['config'], scope, 'Independent timestamp execution projection differs')
            self.check(result.get('replayValid') is True and result.get('traceComplete') is True, scope, 'Independent replay did not validate fully')
            # Built-in serialization only; no simulator, planner or analyzer module is executed.
            script = "const c=require('node:crypto');let s='';process.stdin.on('data',x=>s+=x);process.stdin.on('end',()=>console.log(c.createHash('sha256').update(JSON.stringify(JSON.parse(s))).digest('hex')));"
            hashed = subprocess.run(['node', '-e', script], input=json.dumps(actual), text=True,
                                    capture_output=True, check=True).stdout.strip()
            self.check(hashed == result['actualExecutionHash'] == result['expectedExecutionHash'], scope, 'Independent projection digest differs')
        completed = self.metrics(result, task, initial)
        compute = self.computation(result, task)
        quality = self.quality(result, task, initial)
        self.results.append({**basic, 'observationAvailable': True, 'resultStatus': result['status'],
                             'outcome': result['outcome'], 'reason': result['reason'], 'traceValid': result['traceValid'],
                             'replayValid': result.get('replayValid'), 'completedLocks': completed, 'metrics': result['metrics'],
                             'primaryCensored': result['outcome'] == 'censored', 'authoredLoss': result['outcome'] == 'loss',
                             'nodes': result['nodes'], 'plannerNodes': result['plannerNodes'], 'repairNodes': result['repairNodes'],
                             'planningElapsedMs': result['planningElapsedMs'], **compute, **quality})

    def run(self):
        self.freeze(); self.journal()
        for task in self.registration['tasks']:
            try:
                self.task(task)
            except Exception as error:
                self.errors.append({'scope': task['id'], 'message': type(error).__name__ + ': ' + str(error)})
                self.results.append({**{key: task.get(key) for key in ('id', 'stage', 'levelId', 'seed', 'pathRepair', 'planningLatency', 'group')},
                                     'resultStatus': 'audit-error', 'observationAvailable': False,
                                     'qualifiedMastery': False, 'authoredLoss': False})
        return {'schemaVersion': 1, 'kind': 'independent-long-mastery-raw-audit',
                'auditedAt': datetime.now(timezone.utc).isoformat(),
                'auditScriptSha256': digest(Path(__file__).read_bytes()),
                'sourceHash': self.registration['sourceFreeze']['sourceHash'],
                'registrationSha256': self.input_hashes['registration.json'],
                'allChecksPassed': not self.errors, 'errors': self.errors,
                'assignedCounts': dict(Counter(task['stage'] for task in self.registration['tasks'])),
                'auditedCounts': dict(Counter(row['stage'] for row in self.results)),
                'observedCounts': dict(Counter(row['stage'] for row in self.results if row['observationAvailable'])),
                'completedLockConservationAndScoreChecks': self.lock_checks,
                'recordedCommandChecks': self.command_checks, 'computationWindowChecks': self.compute_checks,
                'completedRepairedTargetChecks': self.completed_repaired_targets,
                'records': self.results, 'inputHashes': dict(sorted(self.input_hashes.items())),
                'limitations': [
                    'Development seeds9101–9102 and192 pieces only; adequate supply is not a legal construction proof, human difficulty calibration, balance adoption or confirmation.',
                    'Measured-wall is host/load dependent; all parents are serial and pair order is counterbalanced, but neither proves an idle or interchangeable host.',
                    'Exact timestamp replay is simulator execution evidence, not browser scheduling or human real-time feasibility.',
                    'Repair accepted-result counts differ from complete repaired paths that actually lock at the retained target.',
                    'Shared beam/BFS node budgets use different node units and are not interchangeable efficiency measurements.',
                    'Score/metrics/cell inventories are independently recomputed, while geometry is certified by the separately executed timestamp replay.',
                    'Authored initialization oracle was retained from a previous independent source initialization; all production source bytes must still match.',
                    'No new simulation or planner is run by this auditor. Node is used only for canonical JavaScript JSON serialization.',
                    'Original failures/interruptions remain explicit; no retry or replacement observation is silently inferred.',
                ]}


def self_test_quality():
    stars = {'one': {'score': 250000},
             'two': {'score': 350000, 'cascades': 25, 'maxCascadeDepth': 6},
             'three': {'score': 500000, 'cascades': 35, 'combo': 18, 'maxCascadeDepth': 10}}
    initial = {'victory': {'primary': {'type': 'score', 'target': 250000},
                          'failure': {'type': 'time', 'value': 480},
                          'bonuses': [{'type': 'tetris-count', 'target': 20}]},
               'stars': stars, 'victoryLapPolicy': 'showcase'}
    def fixture(primary, reason, stop, metrics):
        tiers = {tier: tier_met(conditions, metrics, [False], True) for tier, conditions in stars.items()}
        censored = primary and reason in BUDGET_REASONS
        result = {'metrics': metrics, 'reason': reason,
                  'outcome': 'win' if primary else ('censored' if reason in BUDGET_REASONS else 'loss'),
                  'qualityCensored': censored, 'primaryReached': primary,
                  'primaryReachedAtPiece': 1 if primary else None,
                  'goalReachedAtSeconds': 100 if primary else None, 'stoppedAtSeconds': stop,
                  'trace': [{'completed': True, 'metricsAfter': {'score': 260000, 'piecesPlaced': 1},
                             'resolvedAtMs': 100000}] if primary else [],
                  'requirements': {'primary': initial['victory']['primary'],
                                   'stars': {key: {'conditions': value} for key, value in stars.items()}},
                  'quality': {'tiers': {key: {'conditionsMet': value} for key, value in tiers.items()},
                              'tierThreeConditionsMet': tiers['three'], 'masteryConditionsMet': primary and tiers['three'],
                              'timedStars': max([0] + [index for index, tier in enumerate(('one', 'two', 'three'), 1) if tiers[tier]]),
                              'censored': censored, 'optionalBonuses': [{'conditionMet': False}]}}
        return result
    task = {'id': 'synthetic-quality-excluded', 'stage': 'online'}
    m = {'score': 260000, 'piecesPlaced': 2, 'cascades': 1, 'maxCombo': 2, 'maxCascadeDepth': 2, 'time': 600}
    result = fixture(True, 'piece-budget', 600, m)
    audit = Audit(Path('.')); assessed = audit.quality(result, task, initial)
    assert not audit.errors and assessed['postPrimaryShowcase'] and assessed['qualityCensored'], audit.errors
    assert assessed['authoredTierThreeResiduals']['score']['remaining'] == 240000
    result = fixture(False, 'deadline', 480, {**m, 'score': 0, 'time': 480})
    audit = Audit(Path('.')); audit.quality(result, task, initial)
    assert not audit.errors, audit.errors
    bad = deepcopy(result); bad['stoppedAtSeconds'] = 479
    audit = Audit(Path('.')); audit.quality(bad, task, initial)
    assert any('deadline termination' in item['message'] for item in audit.errors)
    bad = fixture(True, 'manual-showcase-finish', 600, m)
    audit = Audit(Path('.')); audit.quality(bad, task, initial)
    assert any('full acquired three-star' in item['message'] for item in audit.errors)
    bad = fixture(False, 'piece-budget', 150, m)
    bad['trace'] = [{'completed': True, 'metricsAfter': {'score': 260000, 'piecesPlaced': 1}, 'resolvedAtMs': 100000}]
    audit = Audit(Path('.')); audit.quality(bad, task, initial)
    assert any('Primary falsely absent' in item['message'] for item in audit.errors)
    # Completed physics after a benchmark cutoff cannot promote an unacquired primary.
    bad['trace'][0]['resolvedAtMs'] = 160000
    audit = Audit(Path('.')); audit.quality(bad, task, initial)
    assert not audit.errors, audit.errors
    full = {**m, 'score': 500000, 'cascades': 35, 'maxCombo': 18, 'maxCascadeDepth': 18}
    result = fixture(True, 'manual-showcase-finish', 600, full)
    audit = Audit(Path('.')); assessed = audit.quality(result, task, initial)
    assert not audit.errors and assessed['rawTierThreeConditionsMet'] and not assessed['allOptionalBonusesMet'], audit.errors


def self_test():
    self_test_quality()
    # Integrity fixtures only. They do not load registration or any campaign output.
    metrics = {'score': 500000, 'cascades': 35, 'maxCombo': 18, 'maxCascadeDepth': 18, 'tetrises': 0}
    assert tier_met({'score': 500000, 'cascades': 35, 'combo': 18}, metrics, [False], True)
    assert not bonus_met({'type': 'tetris-count', 'target': 20}, metrics)
    assert calculate_score(4, 7, 1, False) == 3400
    assert sum(calculate_score(1, 7, wave, False) for wave in range(1, 9)) == 51000
    result = {'replayValid': True, 'traceComplete': True, 'outcome': 'win', 'qualityCensored': True,
              'quality': {'censored': True}}
    assert not qualify(result, 'replay-online', True, True)
    gap = residuals({'score': 500000, 'cascades': 35, 'combo': 18, 'maxCascadeDepth': 10},
                    {'score': 250000, 'cascades': 12, 'maxCombo': 9, 'maxCascadeDepth': 9}, [])
    assert gap['score']['remaining'] == 250000 and gap['cascades']['remaining'] == 23
    assert gap['combo']['remaining'] == 9 and gap['maxCascadeDepth']['remaining'] == 1
    assert residuals({'time': 210}, {'time': 211}, [])['time']['remaining'] == 1
    assert not residuals({'time': 210}, {'time': 211}, [])['time']['met']
    assert len(PROJECTION_KEYS) == 17 and PROJECTION_KEYS[-1] == 'computeSchedule'
    test_pose = {'shapeKey': 'I', 'x': 3, 'y': 0, 'rotation': 0}
    event = {'index': 1, 'kind': 'plan', 'step': 1, 'atMs': 150, 'readyAtMs': 350,
             'chargedMs': 200, 'computeWallMs': 7.5, 'observationHash': 'observation',
             'pose': test_pose, 'boardHash': 'board', 'target': None, 'actions': [], 'hasActions': False,
             'error': None, 'settledAtMs': 1100 / 3, 'disposition': 'no-path',
             'settledPose': test_pose, 'settledStep': 1, 'settledBoardHash': 'board', 'repairStatus': None}
    decision = {key: event[key] for key in ('index', 'kind', 'step', 'atMs', 'pose', 'observationHash', 'chargedMs')}
    decision.update({'preview': ['I', 'O', 'T'], 'nodes': 3, 'plannerWallMs': 7.5, 'plannerCpuMs': 5,
                     'repairWallMs': 0, 'repairCpuMs': 0})
    fixture = {'config': {'reactionMs': 150, 'actionIntervalMs': 100, 'planningLatency': 'fixed',
                         'fixedPlanningMs': 200, 'pathRepair': 'none', 'maxNodesPerPlan': 10,
                         'maxRepairNodes': 20, 'maxNodes': 50},
               'computeSchedule': [event], 'commands': [], 'decisions': [decision],
               'trace': [{'step': 1, 'shapeKey': 'I', 'spawnAtMs': 0, 'boardHashBefore': 'board'}],
               'stoppedAtSeconds': 1, 'nodes': 3, 'plannerNodes': 3, 'repairNodes': 0,
               'plannerWallMs': 7.5, 'plannerCpuMs': 5, 'repairWallMs': 0, 'repairCpuMs': 0,
               'planningChargedMs': 200, 'planningElapsedMs': 1100 / 3 - 150,
               'counters': {'planningCalls': 1, 'repairAttempts': 0, 'repairSuccesses': 0,
                            'repairFailures': 0, 'staleComputations': 0}}
    task = {'id': 'synthetic-excluded', 'stage': 'online'}
    audit = Audit(Path('.')); audit.computation(fixture, task)
    assert not audit.errors, audit.errors
    bad = deepcopy(fixture); bad['commands'] = [{'type': 'hardDrop', 'source': 'fallback', 'atMs': 200}]
    audit = Audit(Path('.')); audit.computation(bad, task)
    assert any('pending' in item['message'] for item in audit.errors)
    bad = deepcopy(fixture); bad['computeSchedule'][0]['chargedMs'] = 0
    audit = Audit(Path('.')); audit.computation(bad, task)
    assert any('latency model' in item['message'] for item in audit.errors)
    bad = deepcopy(fixture); bad['computeSchedule'][0]['settledAtMs'] = 350
    audit = Audit(Path('.')); audit.computation(bad, task)
    assert any('normal logic' in item['message'] for item in audit.errors)
    bad = deepcopy(fixture); bad['computeSchedule'][0]['settledBoardHash'] = 'different'
    audit = Audit(Path('.')); audit.computation(bad, task)
    assert any('Stale/errored' in item['message'] for item in audit.errors)
    for latency, charge, settle in [('uncharged', 0, 150), ('measured-wall', 7.5, 550 / 3)]:
        altered = deepcopy(fixture); altered['config']['planningLatency'] = latency
        e = altered['computeSchedule'][0]; e.update({'chargedMs': charge, 'readyAtMs': 150 + charge, 'settledAtMs': settle})
        altered['decisions'][0]['chargedMs'] = charge
        altered['planningChargedMs'] = charge; altered['planningElapsedMs'] = settle - 150
        audit = Audit(Path('.')); audit.computation(altered, task)
        assert not audit.errors, audit.errors
    repaired = deepcopy(fixture)
    repaired['config'].update({'planningLatency': 'uncharged', 'pathRepair': 'reachable-v1'})
    target = {**test_pose, 'y': 20}
    first = repaired['computeSchedule'][0]
    first.update({'chargedMs': 0, 'readyAtMs': 150, 'settledAtMs': 150, 'disposition': 'accepted',
                  'target': target, 'hasActions': True, 'actions': [{'type': 'hardDrop'}]})
    repaired['decisions'][0]['chargedMs'] = 0
    second = {**deepcopy(first), 'index': 2, 'kind': 'repair', 'atMs': 400, 'readyAtMs': 400,
              'settledAtMs': 400, 'pose': {**test_pose, 'y': 2}, 'settledPose': {**test_pose, 'y': 2},
              'repairStatus': 'reachable'}
    repaired['computeSchedule'].append(second)
    second_decision = {**deepcopy(repaired['decisions'][0]), 'index': 2, 'kind': 'repair', 'atMs': 400,
                       'pose': second['pose'], 'plannerWallMs': 0, 'plannerCpuMs': 0, 'repairWallMs': 7.5, 'repairCpuMs': 5}
    repaired['decisions'].append(second_decision)
    repaired['commands'] = [{'type': 'hardDrop', 'step': 1, 'source': 'repair', 'atMs': 400, 'accepted': True}]
    repaired['trace'][0].update({'lockedPiece': {**target, 'shape': [[1, 1, 1, 1]]}, 'lockAtMs': 400,
                                'targetValidation': {'target': target, 'actual': target, 'targetAchieved': True}})
    repaired.update({'repairWallMs': 7.5, 'repairCpuMs': 5, 'repairNodes': 3, 'nodes': 6,
                     'planningChargedMs': 0, 'planningElapsedMs': 0})
    repaired['counters'].update({'repairAttempts': 1, 'repairSuccesses': 1})
    audit = Audit(Path('.')); audit.computation(repaired, task)
    assert not audit.errors and audit.completed_repaired_targets == 1, audit.errors
    bad = deepcopy(repaired); bad['computeSchedule'][1]['target'] = {**target, 'rotation': 1}
    audit = Audit(Path('.')); audit.computation(bad, task)
    assert any('retained target' in item['message'] for item in audit.errors)
    assert any('exact target orientation' in item['message'] for item in audit.errors)
    print('Independent synthetic timing, tamper, scoring and qualifier checks pass; no study outcomes or runtime read/executed.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent.parent)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        self_test(); return
    auditor = Audit(args.root.resolve())
    result = auditor.run()
    output = args.output or args.root / 'independent-audit' / 'result-audit.json'
    output.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({key: result[key] for key in ('allChecksPassed', 'observedCounts',
                     'completedLockConservationAndScoreChecks', 'computationWindowChecks', 'completedRepairedTargetChecks')}))
    if result['errors']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()

