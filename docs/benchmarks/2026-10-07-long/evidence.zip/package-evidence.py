"""Package the complete long-study record without overwriting an earlier archive."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
DESTINATION = ROOT.parent.parent / 'docs/benchmarks/2026-10-07-long'
sha = lambda data: hashlib.sha256(data).hexdigest()
registration = json.loads((ROOT / 'registration.json').read_text())
analysis = json.loads((ROOT / 'analysis.json').read_text())
validation = json.loads((ROOT / 'validation/summary.json').read_text())
audit = json.loads((ROOT / 'independent-audit/result-audit.json').read_text())
assert analysis['sourceVerification']['verified']
assert analysis['plannedTasks'] == 24 and len(analysis['tasks']) == 24
assert validation['allPassed'] and all(row['exitCode'] == 0 for row in validation['checks'])
assert audit['allChecksPassed'] and not audit['errors']
files = [path for path in sorted(ROOT.rglob('*')) if path.is_file()
         and '__pycache__' not in path.parts and path.suffix != '.pyc']
DESTINATION.mkdir(parents=True, exist_ok=True)
archive_path = DESTINATION / 'evidence.zip'
members = []
with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in files:
        name = path.relative_to(ROOT).as_posix()
        data = path.read_bytes()
        info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, data, compresslevel=9)
        members.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
manifest = {
    'schemaVersion': 1,
    'sourceCommit': registration['sourceFreeze']['commit'],
    'sourceHash': registration['sourceFreeze']['sourceHash'],
    'registrationSha256': sha((ROOT / 'registration.json').read_bytes()),
    'plannedCounts': registration['plannedCounts'],
    'taskStatuses': analysis['taskStatuses'],
    'developmentSeeds': registration['developmentSeeds'],
    'humanCalibration': False,
    'scope': 'Controlled 192-piece exact-mastery development study with measured planning latency',
    'realtimePlanningFeasibility': 'unverified',
    'independentRawAudit': {
        'path': 'independent-audit/result-audit.json',
        'sha256': sha((ROOT / 'independent-audit/result-audit.json').read_bytes()),
        'allChecksPassed': audit['allChecksPassed'],
    },
    'archive': {'path': archive_path.name, 'bytes': archive_path.stat().st_size,
                'sha256': sha(archive_path.read_bytes())},
    'files': members,
}
with (DESTINATION / 'manifest.json').open('x') as stream:
    stream.write(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'members': len(members), **manifest['archive']}, indent=2))
