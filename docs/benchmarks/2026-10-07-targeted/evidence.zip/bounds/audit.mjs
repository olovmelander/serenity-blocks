/** Source-derived necessary bounds; no board construction or solver outcomes. */
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

const directory = new URL('./', import.meta.url);
const repository = new URL('../../../', directory);
const sha256 = (bytes) => createHash('sha256').update(bytes).digest('hex');
const sources = [
    'src/core/odyssey/data/levels.js',
    'src/core/odyssey/data/difficulty-model.js',
    'src/core/odyssey/data/chapters.js',
    'src/core/odyssey/GameplayHybridEngine.js',
    'src/core/odyssey/VictoryConditionEvaluator.js',
    'src/core/scoring.js',
    'src/core/constants.js',
    'src/core/game.js',
    'src/core/physics.js',
    'scripts/odyssey-benchmark/authored-construction.mjs',
];
const sourceFingerprints = Object.fromEntries(sources.map((path) => [
    path, sha256(readFileSync(new URL(path, repository))),
]));

// Initialization logs are presentation only. Import and initialize the production
// engine itself so the hole pattern is counted exactly, not from an average row.
const originalLog = console.log;
let configs; let starts; let scoreWave; let columns; let hiddenRows;
console.log = () => {};
try {
    const { getLevelById } = await import(new URL('src/core/odyssey/data/levels.js', repository));
    const { GameplayHybridEngine } = await import(new URL('src/core/odyssey/GameplayHybridEngine.js', repository));
    const { calculateLineClearScore } = await import(new URL('src/core/scoring.js', repository));
    const { COLS, HIDDEN_ROWS, SHAPES } = await import(new URL('src/core/constants.js', repository));
    for (const shape of Object.values(SHAPES)) assert.equal(shape.flat().filter(Boolean).length, 4);
    scoreWave = calculateLineClearScore;
    columns = COLS;
    hiddenRows = HIDDEN_ROWS;
    configs = [49, 55, 59].map((id) => getLevelById(id));
    starts = Object.fromEntries(configs.map((config) => {
        const engine = new GameplayHybridEngine();
        engine.configure(config);
        const state = engine.createGameState({ rngSeed: 9101 });
        const occupancy = state.boardGrid.map((row) => row.map(Boolean).map(Number).join(''));
        assert.equal(state.boardGrid[0].length, columns);
        assert.equal(state.linesUntilNextLevel, 15);
        return [config.id, {
            origin: 'GameplayHybridEngine.createGameState({ rngSeed: 9101 })',
            seedUse: 'Initialization only; no pieces played and no queue inspected.',
            rows: state.boardGrid.length,
            columns,
            occupiedCells: state.boardGrid.flat().filter(Boolean).length,
            occupancy,
            occupancySha256: sha256(`${occupancy.join('\n')}\n`),
        }];
    }));
} finally {
    console.log = originalLog;
}

const chainDepth = (conditions) => Math.max(conditions.combo || 0, conditions.maxCascadeDepth || 0);
const piecesNeeded = (lines, initialCells) => Math.max(0, Math.ceil((columns * lines - initialCells) / 4));
const minimumChainScore = (depth, level) => Array.from(
    { length: depth }, (_, index) => scoreWave(1, level, index + 1, false),
).reduce((sum, value) => sum + value, 0);

function jointCellBound({ depth, sequences, quads, initialCells }) {
    // Every sequence has at least two waves; one must reach the required depth.
    const waves = depth + 2 * Math.max(0, sequences - 1);
    // A counted Quad has exactly four lines, three above the one-line-wave floor.
    // More Quad waves than this floor needs would force additional waves too.
    const minimumWaves = Math.max(waves, quads);
    const minimumLines = minimumWaves + 3 * quads;
    return {
        depth, sequences, quads, minimumWaves, minimumLines,
        minimumClearedCells: minimumLines * columns,
        initialCells,
        minimumPlacedTetrominoes: piecesNeeded(minimumLines, initialCells),
        formula: 'ceil((10 * (max(D + 2 * (K - 1), Q) + 3 * Q) - initialCells) / 4)',
        scope: 'Necessary conservation bound only; no geometry, queue, scoring, survival or timing sufficiency.',
    };
}

const levels = configs.map((config) => {
    const three = config.stars.three;
    const depth = chainDepth(three);
    const bonus = (type) => Math.max(0, ...config.victory.bonuses.filter((item) => item.type === type).map((item) => item.target));
    const entry = {
        id: config.id,
        mechanics: config.mechanics,
        primary: config.victory.primary,
        failure: config.victory.failure,
        stars: config.stars,
        bonuses: config.victory.bonuses,
        finishPolicy: config.victoryLapPolicy,
        initialBoard: starts[config.id],
        effectiveThreeStarChainDepth: depth,
        minimumRequiredChainScore: minimumChainScore(depth, config.mechanics.speed.startLevel),
        scoreBoundAssumptions: 'One line per wave; initial scoring level; no perfect clear, lock bonus or prior-lock multiplier. Actual positive modifiers and progression cannot lower this bound.',
        generousTerminalBoardCellCap: (config.mechanics.board.rows + hiddenRows) * columns,
    };
    if (three.cascades) {
        entry.threeStarCellBound = jointCellBound({
            depth, sequences: three.cascades, quads: three.tetrises || 0,
            initialCells: starts[config.id].occupiedCells,
        });
        entry.threeStarsAndEveryBonusCellBound = jointCellBound({
            depth: Math.max(depth, bonus('combo'), bonus('max-cascade-depth')),
            sequences: Math.max(three.cascades, bonus('cascade')),
            quads: Math.max(three.tetrises || 0, bonus('tetris-count')),
            initialCells: starts[config.id].occupiedCells,
        });
    }
    return entry;
});

// Lower scoring envelope: each prior Quad is a separate one-wave clear,
// extra clears/bonuses/multipliers are absent, and level-up occurs before score.
const config49 = configs[0];
const primary49 = config49.victory.primary.target;
const depth49 = chainDepth(config49.stars.three);
const requiredQuads49 = config49.stars.three.tetrises;
let level = config49.mechanics.speed.startLevel;
let remaining = 15;
let priorScore = 0;
const priorQuadScoreLowerBounds = [];
for (let quads = 1; quads <= requiredQuads49; quads++) {
    remaining -= 4;
    if (remaining <= 0) { level++; remaining += 15; }
    priorScore += scoreWave(4, level, 1, false);
    priorQuadScoreLowerBounds.push({ quads, minimumClearScore: priorScore, level });
}
const maxPriorQuads = priorQuadScoreLowerBounds.filter((entry) => entry.minimumClearScore < primary49).length;
const generousBoardCellCap = starts[49].rows * columns;
const maxFinalQuads = Math.floor((generousBoardCellCap / columns - depth49) / 3);
const routes = [];
for (let priorQuads = maxPriorQuads; priorQuads >= requiredQuads49 - maxFinalQuads; priorQuads--) {
    const finalQuads = requiredQuads49 - priorQuads;
    const finalMinimumLines = depth49 + 3 * finalQuads;
    const totalMinimumLines = 4 * priorQuads + finalMinimumLines;
    const minimumPlacedTetrominoes = piecesNeeded(totalMinimumLines, starts[49].occupiedCells);
    const minimumPriorClearScore = priorQuadScoreLowerBounds[priorQuads - 1].minimumClearScore;
    const priorQuadCellOnlyMinimumLocks = piecesNeeded(4 * priorQuads, starts[49].occupiedCells);
    const optimisticMaxPretriggerLocksAt50Bonus = Math.floor((primary49 - 1 - minimumPriorClearScore) / 50);
    routes.push({
        priorQuads, finalQuads, finalDepth: depth49,
        finalMinimumLines, finalMinimumCells: columns * finalMinimumLines,
        totalMinimumLines, minimumPlacedTetrominoes,
        minimumPriorClearScore, priorQuadCellOnlyMinimumLocks,
        priorQuadClearAndInstantBonusScoreLowerBound: minimumPriorClearScore + 50 * priorQuadCellOnlyMinimumLocks,
        instantLockContext: {
            lockBonus: 50,
            optimisticMaxPretriggerLocks: optimisticMaxPretriggerLocksAt50Bonus,
            optimisticLatestFinalTriggerPiece: optimisticMaxPretriggerLocksAt50Bonus + 1,
            excludedByPrimaryBeforeTerminalChain: priorQuadCellOnlyMinimumLocks > optimisticMaxPretriggerLocksAt50Bonus,
            scope: 'Assumes the existing untimed driver clock never advances; additional scores only tighten this limit.',
        },
        excludedBy128PieceCellBudget: minimumPlacedTetrominoes > 128,
        passes192PieceCellBudgetOnly: minimumPlacedTetrominoes <= 192,
        constructionDemonstrated: false,
    });
}

assert.equal(starts[49].occupiedCells, 0);
assert.equal(starts[55].occupiedCells, 240);
assert.equal(starts[59].occupiedCells, 41);
assert.equal(levels[0].minimumRequiredChainScore, 51000);
assert.equal(levels[1].minimumRequiredChainScore, 795300);
assert.equal(levels[2].minimumRequiredChainScore, 218820);
assert.equal(levels[1].threeStarCellBound.minimumPlacedTetrominoes, 155);
assert.equal(levels[1].threeStarsAndEveryBonusCellBound.minimumPlacedTetrominoes, 305);
assert.equal(levels[2].threeStarCellBound.minimumPlacedTetrominoes, 140);
assert.deepEqual(routes.map((route) => route.minimumPlacedTetrominoes), [133, 130, 128]);
assert.deepEqual(routes.map((route) => route.instantLockContext.excludedByPrimaryBeforeTerminalChain), [true, false, false]);

const output = {
    schemaVersion: 1,
    kind: 'source-derived necessary-condition audit',
    sourceCommit: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: fileURLToPath(repository), encoding: 'utf8' }).trim(),
    sourceFingerprints,
    auditSourceSha256: sha256(readFileSync(import.meta.url.startsWith('file:') ? fileURLToPath(import.meta.url) : import.meta.url)),
    metrics: {
        cascades: 'Count of distinct lock resolutions reaching at least wave 2; one 18-wave chain increments this metric once.',
        comboAndMaxCascadeDepth: 'Peak cascade-wave ordinal.',
        tetrises: 'Count of individual clear waves containing exactly four lines.',
        threeStars: 'Conjunction of the three-star conditions, not necessarily every independent bonus.',
    },
    limits: [
        'No pieces played, search outcomes, legal constructions, human observations or win-probability inference.',
        'Counting all hidden rows makes the terminal board cap generous; spawn/top-out/reachability can impose tighter restrictions.',
        'Cell supply is initial occupied cells plus four per tetromino; Odyssey solo adds no attack garbage.',
        'Conservation bounds ignore unusable residual cells, incidental clears, bag order, topology and input timing.',
        'Passing a necessary bound does not demonstrate attainability or enough search budget.',
        'The prior archive remains unchanged; this audit corrects an informal 40-cell orb 59 estimate to the initialized 41 cells.',
    ],
    levels,
    orb49: {
        chainMustBeTerminal: levels[0].minimumRequiredChainScore >= primary49 && config49.victoryLapPolicy === 'none',
        minimumChainScore: levels[0].minimumRequiredChainScore,
        primaryScore: primary49,
        maxPriorQuads, maxFinalQuads, generousBoardCellCap,
        priorQuadScoreLowerBounds, routes,
        qualification: 'Routes are arithmetic allocations only. The existing no-clock driver adds 50 per lock; a zero-lock-bonus relaxed schedule must not be presented as its legal trace.',
    },
};
writeFileSync(new URL('analysis.json', directory), `${JSON.stringify(output, null, 2)}\n`);
console.log(JSON.stringify({
    sourceCommit: output.sourceCommit,
    levels: levels.map((entry) => ({
        id: entry.id, initialCells: entry.initialBoard.occupiedCells,
        effectiveDepth: entry.effectiveThreeStarChainDepth,
        minimumChainScore: entry.minimumRequiredChainScore,
        threeStarMinimumPieces: entry.threeStarCellBound?.minimumPlacedTetrominoes,
        threeStarsAndEveryBonusMinimumPieces: entry.threeStarsAndEveryBonusCellBound?.minimumPlacedTetrominoes,
    })),
    orb49Routes: routes,
}, null, 2));
