# Necessary conditions for targeted Odyssey mastery

Run from the repository root:

```sh
node artifacts/odyssey-targeted-mastery-2026-10-07/bounds/audit.mjs
```

This writes `analysis.json` beside the driver. It imports the production level definitions, scoring function, tetromino shapes and `GameplayHybridEngine`; initializes the actual boards with development seed 9101; and records the commit, driver hash, relevant source hashes and complete opening occupancy. It does not play pieces or inspect a queue. The formulas below are necessary conditions, not constructed solutions, estimates of human difficulty or evidence that a larger search budget will succeed. The earlier `odyssey-mastery-followup-2026-10-07/star-bounds/` audit is preserved.

## Exact joint objectives and cell budgets

`combo` and `maxCascadeDepth` mean peak wave ordinal. `cascades` counts separate locking pieces that reach wave 2, so one 18-wave chain contributes **one** cascade sequence. A Quad is exactly four lines in one wave. Stars and independent bonuses are separate evaluations.

| Orb | Three-star conjunction | Opening cells | Required lines, at least | Tetrominoes, at least |
| --- | --- | ---: | ---: | ---: |
| 49 | 36,000 score; 12 Quads; depth 8 | 0 | 51–53 in the terminal allocations below | 128–133 |
| 55 | 500,000 score; 35 sequences; depth 10; combo 18 (effective depth 18) | 240 | 86 | 155 |
| 59 | 260,000 score; 25 sequences; depth 7; combo 12 (effective depth 12) | 41 | 60 | 140 |

For `K` sequences including one depth-`D` chain, at least `D + 2(K−1)` waves must clear. Each wave consumes at least one ten-cell line. Thus orb 55 needs `18 + 2×34 = 86` lines and `ceil((860−240)/4) = 155` pieces; orb 59 needs `12 + 2×24 = 60` lines and `ceil((600−41)/4) = 140` pieces. The initialized orb 59 board contains **41** cells, correcting the informal estimate of 40; the rounded 140-piece bound is unchanged. Residual cells and incidental clears can only increase the actual requirement.

Orb 55's **20-Quad bonus is not a three-star requirement**. Satisfying all bonuses together with three stars adds at least 60 cleared lines (three additional lines for each of 20 Quad waves), raising the bound to `ceil((1460−240)/4) = 305` pieces. Orb 59's bonuses add no conditions beyond its three-star conjunction. Search and reporting must distinguish three stars from “three stars and every bonus.”

At the starting scoring level, a one-line-per-wave chain alone scores at least 51,000 / 795,300 / 218,820 for orbs 49 / 55 / 59, respectively. These lower bounds omit lock bonuses, perfect clears, progression and prior-lock multipliers. In orb 55 the required 18-wave chain already exceeds its three-star score threshold. In orb 59 the required 12-wave chain alone does not guarantee 260,000; the joint score still must be evaluated.

## Orb 49: terminal score and Quad allocation

Orb 49 ends after the full resolution that acquires its 36,000 primary; there is no showcase. Since any eight-wave chain scores at least 51,000, its required chain must be the terminal resolution. Ten earlier isolated Quads already score 36,000 before lock bonuses, so at most nine Quads can precede that resolution. A generous 24-row board, including all four hidden rows, holds 240 cells. A depth-eight chain containing `q` Quads consumes at least `10×(8+3q)` cells, allowing at most five terminal Quads. Actual spawn and geometry restrictions may be tighter.

| Prior Quads + terminal Quads | Minimum prior clear score | Terminal cells, at least | Total pieces, at least | Existing instant-lock context |
| --- | ---: | ---: | ---: | --- |
| 9 + 3 | 32,200 | 170 | 133 | Excluded: nine prior Quads require at least 90 locks; 32,200 + 90×50 = 36,700 already acquires primary. |
| 8 + 4 | 28,400 | 200 | 130 | Arithmetic bound passes; optimistic terminal-trigger limit is piece 152. |
| 7 + 5 | 24,600 | 230 | 128 | Arithmetic bound passes; optimistic terminal-trigger limit is piece 228. |

The current untimed construction clock does not advance, so the production elapsed lock-bonus formula gives 50 points on each lock. For a prior-Quad score floor `S`, fewer than 36,000 points before the final trigger permits at most `floor((35,999−S)/50)` earlier locks. Extra clears, perfect clears and multipliers tighten that limit. These routes only allocate required Quads: they do not establish legal geometry, reachable commands, a suitable random bag or an actual attainable neutral multiplier.

A relaxed zero-lock-bonus 9+3 schedule remains an arithmetic possibility, but is not a trace in the existing instant-lock context. Pursuing it requires a separately declared elapsed-lock condition and eventual legal timing with gravity; silently omitting the bonus is invalid. A terminal cascade is drained fully even when primary is crossed during its resolution.

## What a 192-piece search budget means

The previous 128-piece construction cap could not satisfy orb 55 or 59's three-star cell supply and excluded the more spacious orb 49 allocations. A 192-piece budget removes those particular three-star exclusions. It does **not** establish a solution, sufficient search coverage, survivability, real-time execution or fair human challenge. It remains below the 305-piece minimum for orb 55's three stars plus every bonus. Search should prune impossible cell/score budgets, retain exact finish semantics, and report depth-only, three-star and all-bonus milestones separately.

Prepared board topology is only a prepared-board witness. The next meaningful stage is legal assembly from each actual authored start, observing the current piece plus three visible previews, followed by production replay with connected-piece state, conservation, exact scores and the terminal point checked. Development remains on seeds 9101–9103. Freeze successful search/replay code before a separately registered fresh descriptive cohort; reserve seeds 11001 and above for later confirmation. Timed gravity/input validation and actual player sessions remain subsequent evidence, not implications of these bounds.
