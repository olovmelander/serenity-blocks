#!/usr/bin/env python3
"""Independent, standard-library description of the frozen targeted mastery plan.

This reads artifacts only. It never invokes the planner, production engine or replay.
Missing/failed tasks remain in the denominator. Source/options/bytes are verified
before any task is eligible to qualify a witness.
"""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path, PurePosixPath
import shlex
import statistics
import zipfile

ALLOWED_FINISHES = {"primary-goal", "manual-showcase-finish", "showcase-top-out"}
SEARCH_DEFAULTS = {"maxPieces": 192, "beamWidth": 8, "maxNodes": 240000,
                   "maxNodesPerPlan": 2400, "unknownTailDepth": 1}
FLAG_KEYS = {"level": "levelId", "seed": "seed", "max-pieces": "maxPieces",
             "beam-width": "beamWidth", "max-nodes": "maxNodes",
             "nodes-per-plan": "maxNodesPerPlan", "unknown-tail-depth": "unknownTailDepth",
             "reaction-ms": "reactionMs", "action-ms": "actionIntervalMs",
             "max-seconds": "maxSimSeconds", "wall-ms": "wallBudgetMs"}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def utf16(value):
    """Match JavaScript Array.sort's UTF-16 code-unit ordering."""
    return value.encode("utf-16-be", errors="surrogatepass")


class Inputs:
    def __init__(self, root):
        self.root = root
        self.hashes = {}

    def read(self, path):
        path = Path(path).resolve()
        data = path.read_bytes()
        try:
            name = path.relative_to(self.root).as_posix()
        except ValueError:
            name = str(path)
        self.hashes[name] = {"bytes": len(data), "sha256": sha(data)}
        return data

    def json(self, path):
        return json.loads(self.read(path))


def referenced_file(root, value, label, inputs):
    require(isinstance(value, dict) and value.get("path") and value.get("sha256"),
            f"{label} requires path and sha256")
    path = root / value["path"]
    data = inputs.read(path)
    require(sha(data) == value["sha256"], f"{label} checksum differs")
    return path, data


def verify_source(root, registration, inputs):
    freeze = registration["sourceFreeze"]
    require(registration.get("executionReady") is True, "Registration is not frozen for execution")
    registration_bytes = inputs.read(root / "registration.json")
    checksum = inputs.read(root / "registration.sha256").decode().split()[0]
    require(sha(registration_bytes) == checksum, "Frozen registration checksum differs")
    require(sha(Path(__file__).read_bytes()) == freeze["analyzerSha256"], "Running analyzer changed")
    require(sha(inputs.read(root / "analyze.py")) == freeze["analyzerSha256"], "Archived analyzer changed")
    for field, filename in (("runnerSha256", "run-development.py"), ("freezeScriptSha256", "freeze-development.mjs")):
        if registration.get(field):
            require(sha(inputs.read(root / filename)) == registration[field], f"Frozen {filename} changed")
    _, manifest_bytes = referenced_file(root, freeze["sourceManifest"], "Source manifest", inputs)
    snapshot_path, _ = referenced_file(root, freeze["sourceSnapshot"], "Source snapshot", inputs)
    manifest = json.loads(manifest_bytes)
    require(bool(manifest), "Empty source manifest")
    with zipfile.ZipFile(snapshot_path) as archive:
        members = [entry.filename for entry in archive.infolist() if not entry.is_dir()]
        require(len(members) == len(set(members)), "Duplicate source ZIP members")
        require(set(members) == set(manifest), "Source ZIP and manifest member sets differ")
        digest = hashlib.sha256()
        for name in sorted(manifest, key=utf16):
            parts = PurePosixPath(name)
            require(not parts.is_absolute() and ".." not in parts.parts, f"Unsafe ZIP path: {name}")
            data = archive.read(name)
            require(manifest[name] == {"bytes": len(data), "sha256": sha(data)},
                    f"Source bytes differ from manifest: {name}")
            digest.update((name + "\0").encode("utf-8"))
            digest.update(data)
    require(digest.hexdigest() == freeze["sourceHash"], "Source path-NUL-bytes digest differs")
    if freeze.get("sourcePatch"):
        referenced_file(root, freeze["sourcePatch"], "Source patch", inputs)
    return manifest, {"verified": True, "files": len(manifest), "commit": freeze["commit"],
                      "sourceHash": digest.hexdigest(), "runtime": freeze["runtime"],
                      "ordering": "Full relative paths sorted as UTF-16 code units; path, NUL, file bytes"}


def command_options(command, repo):
    argv = shlex.split(command) if isinstance(command, str) else command
    require(isinstance(argv, list) and len(argv) >= 3, "Command must be an argv array or shell-quoted string")
    positions = [i for i, value in enumerate(argv) if Path(value).name == "odyssey-mastery.mjs"]
    require(len(positions) == 1, "Command must invoke exactly one odyssey-mastery.mjs")
    index = positions[0] + 1
    stage = argv[index]
    require(stage in ("search", "replay"), "Unknown command stage")
    values = {}
    index += 1
    while index < len(argv):
        token = argv[index]
        require(token.startswith("--"), f"Unexpected command token: {token}")
        name, equal, value = token[2:].partition("=")
        require(name not in values, f"Duplicate flag: {name}")
        if not equal:
            index += 1
            require(index < len(argv), f"Missing flag value: {name}")
            value = argv[index]
        values[name] = value
        index += 1
    allowed = {"output", "wall-ms"} | (set(FLAG_KEYS) - {"reaction-ms", "action-ms", "max-seconds"}
                if stage == "search" else {"candidate", "mode", "reaction-ms", "action-ms", "max-seconds"})
    require(set(values) <= allowed, "Unknown or misplaced command flags")
    require("output" in values, "Missing command output")
    options = {"command": stage, "outputDir": str((repo / values["output"]).resolve()),
               "wallBudgetMs": int(values.get("wall-ms", 120000))}
    if stage == "search":
        options.update(SEARCH_DEFAULTS)
        require("level" in values and "seed" in values, "Missing search level/seed")
    else:
        require("candidate" in values, "Missing replay candidate")
        options.update({"candidatePath": str((repo / values["candidate"]).resolve()),
                        "mode": values.get("mode", "untimed"), "reactionMs": 150,
                        "actionIntervalMs": 100, "maxSimSeconds": 1800})
    for name, key in FLAG_KEYS.items():
        if name in values:
            require(str(values[name]).isdigit(), f"Non-integer flag: {name}")
            options[key] = int(values[name])
    return options


def independently_met(conditions, metrics, bonus_count=0, untimed=False):
    aliases = {"combo": "maxCombo", "cascade": "cascades", "max-cascade-depth": "maxCascadeDepth",
               "tetris-count": "tetrises", "pieces": "piecesPlaced", "maxDeaths": "deaths"}
    details = []
    for name, target in conditions.items():
        if untimed and name == "time":
            continue
        actual = bonus_count if name == "bonuses" else metrics.get(aliases.get(name, name), 0)
        actual = 0 if actual is None else actual
        upper = name in ("time", "maxDeaths")
        met = actual <= target if upper else actual >= target
        details.append({"key": name, "target": target, "actual": actual, "upperBound": upper,
                        "met": met, "remaining": max(0, actual - target if upper else target - actual)})
    return {"conditionsMet": bool(details) and all(item["met"] for item in details), "residual": details}


def inspect_trace(result):
    trace = result.get("trace", [])
    complete = [entry for entry in trace if entry.get("completed") is True]
    mismatches = 0
    comparisons = 0
    continuity = 0
    previous = result.get("initialBoardHash")
    for entry in trace:
        if previous is not None and entry.get("boardHashBefore") != previous:
            continuity += 1
        previous = entry.get("boardHashAfter")
        prediction = entry.get("prediction")
        if prediction and entry.get("metricsAfter") is not None:
            comparisons += 1
            actual = entry["metricsAfter"]
            predicted = prediction.get("metricsAfter", {})
            match = prediction.get("boardHashAfter") == entry.get("boardHashAfter") and all(
                predicted.get(key) == value for key, value in actual.items())
            mismatches += not match
    bad_conservation = []
    non_tetromino = []
    for entry in complete:
        cell = entry.get("cellConservation", {})
        if not cell or cell.get("expected") != cell.get("actual") or cell.get("valid") is False or cell.get("overlap"):
            bad_conservation.append(entry.get("step"))
        piece = entry.get("lockedPiece", {})
        shape_cells = sum(bool(value) for row in piece.get("shape", []) for value in row)
        if shape_cells != 4 or ("cells" in piece and piece["cells"] != 4):
            non_tetromino.append(entry.get("step"))
    rejected = sum(action.get("accepted") is False and not action.get("legalStop", False)
                   for entry in trace for action in entry.get("actions", []))
    preview_violations = sum(len(entry.get("preview", [])) != 3 for entry in trace)
    return {"entries": len(trace), "completedEntries": len(complete),
            "incompleteEntries": len(trace) - len(complete), "rejectedActions": rejected,
            "conservationFailureSteps": bad_conservation, "nonTetrominoSteps": non_tetromino,
            "boardContinuityMismatches": continuity, "previewLengthViolations": preview_violations,
            "predictionComparisons": comparisons, "predictionMismatches": mismatches,
            "evidenceConsistent": not (bad_conservation or non_tetromino or rejected or continuity or preview_violations),
            "limits": "Recorded arithmetic and continuity checks only; Python does not execute physics or prove planner information access."}


def timed_full_witness(result, provenance=True, trace_consistent=True):
    quality = result.get("quality", {})
    return bool(provenance and trace_consistent and result.get("timed") is True
                and result.get("replayValid") is True and result.get("outcome") == "win"
                and result.get("reason") in ALLOWED_FINISHES
                and result.get("qualityCensored") is False and quality.get("censored") is False
                and quality.get("masteryConditionsMet") is True)


def describe_search(result):
    evidence = inspect_trace(result)
    quality = result.get("quality", {})
    metrics = result.get("metrics", {})
    conditions = result.get("requirements", {}).get("stars", {}).get("three", {}).get("conditions", {})
    bonuses = sum(item.get("untimedConditionMet") is True for item in quality.get("bonuses", []))
    independent = independently_met(conditions, metrics, bonuses, untimed=True)
    reported_mismatches = result.get("compute", {}).get("predictionMismatches")
    return {"resultStatus": result.get("status"), "termination": result.get("termination"),
            "traceValid": result.get("traceValid") is True, "traceEvidence": evidence,
            "primaryReachedUntimed": quality.get("primaryReachedUntimed") is True,
            "primaryReachedAtPiece": result.get("primaryReachedAtPiece"),
            "tierThreeUntimedConditionsMet": quality.get("tierThreeUntimedConditionsMet") is True,
            "masteryUntimedConditionsMet": quality.get("masteryUntimedConditionsMet") is True,
            "qualifiedUntimedSearchCandidate": bool(result.get("status") == "candidate"
                and result.get("traceValid") is True and evidence["entries"] > 0
                and evidence["incompleteEntries"] == 0 and evidence["evidenceConsistent"]
                and quality.get("masteryUntimedConditionsMet") is True and independent["conditionsMet"]),
            "allOptionalBonusesUntimedConditionsMet": quality.get("allBonusesUntimedConditionsMet") is True,
            "independentTierThree": independent,
            "reportedResidualRequirements": quality.get("residualRequirements"),
            "scoreFinishHeadroom": quality.get("scoreFinishHeadroom"),
            "topOut": result.get("topOut"), "metrics": metrics,
            "maximumDepth": metrics.get("maxCascadeDepth"), "piecesPlaced": result.get("piecesPlaced"),
            "compute": result.get("compute"), "budgets": result.get("budgets"),
            "budgetReached": result.get("termination") in ("piece-budget", "node-budget", "wall-budget"),
            "predictionMismatchReportAgrees": reported_mismatches == evidence["predictionMismatches"],
            "error": result.get("error"), "timingQualified": False}


def describe_replay(result, candidate):
    evidence = inspect_trace(result)
    quality = result.get("quality", {})
    metrics = result.get("metrics", {})
    conditions = result.get("requirements", {}).get("stars", {}).get("three", {}).get("conditions", {})
    bonuses = sum(item.get("conditionMet") is True for item in quality.get("optionalBonuses", []))
    independent = independently_met(conditions, metrics, bonuses, untimed=not result.get("timed"))
    expected = candidate.get("trace", [])
    replay_trace = result.get("trace", [])
    candidate_mismatches = []
    for index, entry in enumerate(replay_trace):
        if index >= len(expected):
            candidate_mismatches.append({"step": index + 1, "fields": ["extra-entry"]})
            continue
        fields = [name for name in ("shapeKey", "preview", "boardHashBefore") if entry.get(name) != expected[index].get(name)]
        if entry.get("completed") and entry.get("boardHashAfter") != expected[index].get("boardHashAfter"):
            fields.append("boardHashAfter")
        if fields:
            candidate_mismatches.append({"step": index + 1, "fields": fields})
    evidence["candidateMismatches"] = candidate_mismatches
    evidence["evidenceConsistent"] &= not candidate_mismatches
    quality_censored = bool(result.get("qualityCensored") or quality.get("censored"))
    valid = result.get("replayValid") is True and evidence["evidenceConsistent"]
    terminal_qualified = bool(valid and result.get("outcome") == "win"
                              and result.get("reason") in ALLOWED_FINISHES and not quality_censored)
    return {"mode": result.get("mode"), "timed": result.get("timed"),
            "resultStatus": result.get("status"), "outcome": result.get("outcome"), "reason": result.get("reason"),
            "reportedReplayValid": result.get("replayValid") is True, "replayValidWithEvidenceChecks": valid,
            "traceComplete": result.get("traceComplete") is True, "traceEvidence": evidence,
            "primaryReached": result.get("primaryReached") is True,
            "primaryReachedAtPiece": result.get("primaryReachedAtPiece"),
            "goalReachedAtSeconds": result.get("goalReachedAtSeconds"),
            "tierThreeConditionsMet": quality.get("tierThreeConditionsMet") is True,
            "masteryConditionsMet": quality.get("masteryConditionsMet") is True,
            "independentTierThree": independent, "timedStars": quality.get("timedStars"),
            "allOptionalBonusesMet": bool(quality.get("optionalBonuses")) and all(
                item.get("conditionMet") is True for item in quality.get("optionalBonuses", [])),
            "qualityCensored": quality_censored,
            "validUncensoredTerminalPrimary": terminal_qualified and result.get("primaryReached") is True,
            "qualifiedUntimedReplayMastery": bool(not result.get("timed") and terminal_qualified
                and quality.get("masteryConditionsMet") is True and independent["conditionsMet"]),
            "qualifiedTimedFullWitness": timed_full_witness(result, trace_consistent=evidence["evidenceConsistent"])
                and independent["conditionsMet"],
            "metrics": metrics, "maximumDepth": result.get("maximumDepth"),
            "piecesReplayed": result.get("piecesReplayed"), "unusedPieces": result.get("unusedPieces"),
            "automaticLocks": result.get("automaticLocks"), "cadence": result.get("cadence"),
            "budgets": result.get("budgets"), "wallMs": result.get("wallMs"),
            "budgetReached": result.get("reason") in ("wall-budget", "simulation-budget"),
            "failure": result.get("failure"), "cleanupError": result.get("cleanupError")}


def analyze_task(root, repo, task, registration, manifest, inputs, execution):
    record = {"id": task["id"], "stage": task["stage"], "output": task["output"],
              "status": "missing", "provenanceVerified": False, "execution": execution.get(task["id"])}
    folder = root / task["output"]
    try:
        options = command_options(task["command"], repo)
        require(options["command"] == task["stage"], "Task stage differs from command")
        # Commands/configs retain original absolute paths. Verify their exact
        # registered suffix, then read only from the current extracted root.
        output_parts = Path(task["output"]).parts
        require(not Path(task["output"]).is_absolute() and ".." not in output_parts and output_parts,
                "Task output must be a safe path relative to the artifact root")
        declared_output = Path(options["outputDir"])
        require(declared_output.parts[-len(output_parts):] == output_parts, "Task output differs from command")
        original_root = declared_output.parents[len(output_parts) - 1]
        if task["stage"] == "replay":
            require(Path(options["candidatePath"]) == (original_root / task["candidate"]).resolve(),
                    "Task candidate differs from command")
            owners = [entry for entry in registration["tasks"] if entry["stage"] == "search"
                      and task["candidate"] == entry["output"] + "/candidate.json"]
            require(len(owners) == 1, "Replay candidate must belong to exactly one registered search")
            owner_options = command_options(owners[0]["command"], repo)
            record.update({"levelId": owner_options["levelId"], "seed": owner_options["seed"],
                           "candidateTaskId": owners[0]["id"]})
        else:
            record.update({"levelId": options["levelId"], "seed": options["seed"]})
        record["declaredOptions"] = options
        if not folder.exists():
            run = record["execution"] or {}
            if run.get("status") == "not executed":
                record["status"] = "not-executed"
            elif run.get("status") == "runner error" or run.get("exitCode", 0) != 0:
                record["status"] = "error"
            else:
                record["status"] = "missing"
            return record
        config_path = folder / "config.json"
        if not config_path.exists():
            record["status"] = "missing-config"
            return record
        config = inputs.json(config_path)
        require(config.get("schemaVersion") == 1, "Unknown configuration schema")
        require(config["options"] == options, "Invocation options differ from declared command")
        freeze = registration["sourceFreeze"]
        revision = config["revision"]
        for key, expected in {"head": freeze["commit"], "sourceHash": freeze["sourceHash"],
                              "runtime": freeze["runtime"]}.items():
            require(revision.get(key) == expected, f"Invocation revision {key} differs")
        require(inputs.json(folder / "source-manifest.json") == manifest, "Invocation source manifest differs")
        if (folder / "source.patch").exists():
            inputs.read(folder / "source.patch")
        candidate = None
        if task["stage"] == "replay":
            candidate_bytes = inputs.read(root / task["candidate"])
            require(config["candidateSha256"] == sha(candidate_bytes), "Replay candidate checksum differs")
            require(inputs.read(folder / "input-candidate.json") == candidate_bytes, "Archived replay candidate bytes differ")
            candidate = json.loads(candidate_bytes)
        else:
            require(config.get("candidateSha256") is None, "Search unexpectedly declares an input candidate")
        record["provenanceVerified"] = True
        if (folder / "failure.json").exists():
            record["failure"] = inputs.json(folder / "failure.json")
        if not (folder / "summary.json").exists():
            record["status"] = "error" if record.get("failure") else "incomplete"
            filename = "candidate.json" if task["stage"] == "search" else "replay.json"
            if (folder / filename).exists():
                inputs.read(folder / filename)
                record["unqualifiedResultRetained"] = filename
            return record
        summary = inputs.json(folder / "summary.json")
        require(not record.get("failure"), "Invocation has both success summary and failure record")
        require(summary.get("status") == "completed" and summary.get("sourceStable") is True,
                "Invocation not completed with stable source")
        require(summary.get("command") == task["stage"], "Summary command differs")
        require(summary.get("revision") == revision, "Summary revision differs from config")
        require(summary.get("candidateSha256") == config.get("candidateSha256"), "Summary candidate checksum differs")
        filename = "candidate.json" if task["stage"] == "search" else "replay.json"
        require(summary["result"]["path"] == filename, "Unexpected summary result path")
        result_bytes = inputs.read(folder / filename)
        require(summary["result"] == {"path": filename, "bytes": len(result_bytes), "sha256": sha(result_bytes)},
                "Result size/checksum differs from summary")
        result = json.loads(result_bytes)
        require(result.get("schemaVersion") == 1, "Unknown result schema")
        identity = options if task["stage"] == "search" else candidate
        for key in ("levelId", "seed"):
            require(result.get(key) == identity[key], f"Result {key} differs from invocation/input")
        record.update({"levelId": result["levelId"], "seed": result["seed"],
                       "status": "completed", "elapsedWallMs": summary.get("elapsedWallMs"),
                       "resultSha256": sha(result_bytes)})
        if task["stage"] == "search":
            require(result.get("kind") == "targeted-mastery-search", "Unexpected search result kind")
            require(result.get("budgets") == {key: options[key] for key in (*SEARCH_DEFAULTS, "wallBudgetMs")},
                    "Result search budgets differ from invocation")
            require(result.get("previewLimit") == 3 and result.get("timed") is False,
                    "Unexpected search observation/timing declaration")
            record["observation"] = describe_search(result)
        else:
            require(result.get("kind") == "mastery-candidate-replay", "Unexpected replay result kind")
            require(result.get("mode") == options["mode"] and result.get("timed") == (options["mode"] == "timed"),
                    "Replay mode differs from invocation")
            if result.get("status") != "error":
                require(result.get("budgets") == {key: options[key] for key in ("maxSimSeconds", "wallBudgetMs")},
                        "Replay budgets differ from invocation")
                if options["mode"] == "timed":
                    require(all(result.get("cadence", {}).get(key) == options[key]
                                for key in ("reactionMs", "actionIntervalMs")), "Replay cadence differs")
            record["observation"] = describe_replay(result, candidate)
        if result.get("status") == "error" or result.get("error"):
            record["status"] = "result-error"
        return record
    except (ValueError, KeyError, TypeError, OSError) as error:
        record["status"] = "verification-error"
        record["provenanceVerified"] = False
        record["verificationError"] = str(error)
        record.pop("observation", None)
        return record


def aggregate(records):
    groups = defaultdict(list)
    for record in records:
        options = record.get("declaredOptions", {})
        observation = record.get("observation", {})
        level = record.get("levelId", options.get("levelId"))
        if record["stage"] == "search":
            key = f"orb-{level}/search"
        else:
            mode = options.get("mode", "unknown")
            key = f"orb-{level}/replay/{mode}"
            if mode == "timed":
                key += f"/{options.get('reactionMs')}-{options.get('actionIntervalMs')}"
        groups[key].append((record, observation))
    output = {}
    for key, group in sorted(groups.items()):
        observed = [observation for record, observation in group if record.get("provenanceVerified") and observation]
        depths = [item["maximumDepth"] for item in observed if isinstance(item.get("maximumDepth"), (int, float))]
        timed_witnesses = [item for item in observed if item.get("qualifiedTimedFullWitness")]
        times = [item["metrics"]["time"] for item in timed_witnesses if isinstance(item.get("metrics", {}).get("time"), (int, float))]
        output[key] = {"planned": len(group), "statuses": dict(Counter(record["status"] for record, _ in group)),
                       "observed": len(observed), "maximumObservedDepth": max(depths, default=None),
                       "terminationsOrReasons": dict(Counter(item.get("termination", item.get("reason")) for item in observed)),
                       "outcomes": dict(Counter(item["outcome"] for item in observed if item.get("outcome") is not None)),
                       "qualifiedUntimedSearchCandidates": sum(item.get("qualifiedUntimedSearchCandidate", False) for item in observed),
                       "qualifiedUntimedReplayMastery": sum(item.get("qualifiedUntimedReplayMastery", False) for item in observed),
                       "qualifiedTimedFullWitnesses": len(timed_witnesses),
                       "primaryReached": sum(item.get("primaryReached", item.get("primaryReachedUntimed", False)) for item in observed),
                       "replayValidWithEvidenceChecks": sum(item.get("replayValidWithEvidenceChecks", False) for item in observed),
                       "traceComplete": sum(item.get("traceComplete", False) for item in observed),
                       "qualityCensored": sum(item.get("qualityCensored", False) for item in observed),
                       "budgetReached": sum(item.get("budgetReached", False) for item in observed),
                       "predictionMismatches": sum(item.get("traceEvidence", {}).get("predictionMismatches", 0) for item in observed),
                       "fullTimedWitnessMedianSeconds": statistics.median(times) if times else None}
    return output


def analyze(root):
    root = root.resolve()
    inputs = Inputs(root)
    registration = inputs.json(root / "registration.json")
    manifest, source = verify_source(root, registration, inputs)
    repo = Path(registration.get("repositoryRoot", root.parent.parent)).resolve()
    tasks = registration["tasks"]
    require(len({task["id"] for task in tasks}) == len(tasks), "Duplicate planned task IDs")
    require(len({task["output"] for task in tasks}) == len(tasks), "Duplicate planned task output directories")
    execution = {}
    for name in ("execution-search.json", "execution-replay.json", "execution.json"):
        path = root / name
        if path.exists():
            entries = inputs.json(path)
            require(len({entry["id"] for entry in entries}) == len(entries), f"Duplicate execution IDs: {name}")
            require(set(entry["id"] for entry in entries) <= set(task["id"] for task in tasks),
                    f"Unregistered execution IDs: {name}")
            execution.update({entry["id"]: entry for entry in entries})
    records = [analyze_task(root, repo, task, registration, manifest, inputs, execution) for task in tasks]
    return {"schemaVersion": 1, "kind": "independent descriptive targeted mastery audit",
            "sourceVerification": source, "plannedTasks": len(tasks),
            "plannedStages": dict(Counter(task["stage"] for task in tasks)),
            "taskStatuses": dict(Counter(record["status"] for record in records)),
            "allPlannedInvocationsCompleted": all(record["status"] == "completed" for record in records),
            "allObservedProvenanceVerified": all(record["provenanceVerified"] for record in records
                if record["status"] not in ("missing", "not-executed")),
            "groups": aggregate(records), "tasks": records,
            "limits": [
                "Development seeds 9101–9103 are exploratory; no confirmation or human probability inference.",
                "All planned searches and replays are retained, including misses, budgets, invalid paths and missing outputs.",
                "A completed CLI invocation is not necessarily a complete trace, valid replay, primary win or mastery witness.",
                "Timed full witness requires verified provenance and trace checks, replayValid, outcome win, an allowed live finish, uncensored quality and mastery conditions.",
                "A valid replay can stop before the candidate ends; traceComplete is reported separately and is not silently substituted for actual terminal success.",
                "Python verifies recorded byte provenance, command options, arithmetic and continuity; production legality is exercised by the Node replay, not reconstructed here.",
                "Three-preview and seed isolation are Node test/source properties, not proven by matching recorded previews or by this Python analyzer.",
                "Scripted timed execution does not certify online planning speed, player skill, campaign fairness or a human win rate.",
            ], "inputHashes": dict(sorted(inputs.hashes.items()))}


def self_test():
    import copy
    import shutil
    import tempfile
    import unittest

    class QualificationTests(unittest.TestCase):
        def test_full_witness_requires_every_gate(self):
            base = {"timed": True, "replayValid": True, "outcome": "win", "reason": "primary-goal",
                    "qualityCensored": False, "quality": {"censored": False, "masteryConditionsMet": True}}
            self.assertTrue(timed_full_witness(base))
            for key, value in {"timed": False, "replayValid": False, "outcome": "censored",
                               "reason": "simulation-budget", "qualityCensored": True}.items():
                sample = copy.deepcopy(base); sample[key] = value
                self.assertFalse(timed_full_witness(sample), key)
            for key, value in {"censored": True, "masteryConditionsMet": False}.items():
                sample = copy.deepcopy(base); sample["quality"][key] = value
                self.assertFalse(timed_full_witness(sample), key)
            self.assertFalse(timed_full_witness(base, provenance=False))
            self.assertFalse(timed_full_witness(base, trace_consistent=False))
            for reason in ALLOWED_FINISHES:
                sample = copy.deepcopy(base); sample["reason"] = reason
                self.assertTrue(timed_full_witness(sample))

        def test_raw_quality_cannot_qualify_interrupted_replay(self):
            sample = {"timed": True, "replayValid": False, "outcome": "win", "reason": "execution-interrupted",
                      "qualityCensored": True, "quality": {"censored": True, "masteryConditionsMet": True}}
            self.assertFalse(timed_full_witness(sample))

        def test_alias_and_joint_conditions(self):
            result = independently_met({"combo": 18, "cascades": 35, "score": 500000},
                                       {"maxCombo": 18, "cascades": 1, "score": 800000})
            self.assertFalse(result["conditionsMet"])
            self.assertEqual(result["residual"][1]["remaining"], 34)

        def test_exact_options_and_defaults(self):
            options = command_options(["node", "scripts/odyssey-mastery.mjs", "search", "--level", "49",
                "--seed=9101", "--output", "artifacts/check", "--wall-ms", "240000"], Path("/example"))
            self.assertEqual(options["outputDir"], "/example/artifacts/check")
            self.assertEqual(options["maxPieces"], 192)
            self.assertEqual(options["wallBudgetMs"], 240000)
            with self.assertRaises(ValueError):
                command_options(["node", "odyssey-mastery.mjs", "search", "--output", "x", "--output", "y"], Path("/"))

        def test_utf16_sort_matches_javascript_non_bmp_order(self):
            self.assertEqual(sorted(["\ue000", "\U00010000"], key=utf16), ["\U00010000", "\ue000"])

        def test_conservation_failure_retained(self):
            result = {"trace": [{"step": 1, "completed": True, "preview": ["I", "T", "O"],
                "lockedPiece": {"shape": [[1, 1, 1, 1]]}, "cellConservation": {"expected": 4, "actual": 5}}]}
            evidence = inspect_trace(result)
            self.assertEqual(evidence["conservationFailureSteps"], [1])
            self.assertFalse(evidence["evidenceConsistent"])

        def test_frozen_archive_relocation_and_tamper_detection(self):
            with tempfile.TemporaryDirectory() as temp:
                root = Path(temp) / "original"
                root.mkdir()
                (root / "analyze.py").write_bytes(Path(__file__).read_bytes())
                source = {"src/z.js": b"first", "src/\U00010000.js": b"second", "src/\ue000.js": b"third"}
                manifest = {name: {"bytes": len(data), "sha256": sha(data)} for name, data in source.items()}
                digest = hashlib.sha256()
                with zipfile.ZipFile(root / "source-snapshot.zip", "w") as archive:
                    for name in sorted(source, key=utf16):
                        archive.writestr(name, source[name])
                        digest.update((name + "\0").encode()); digest.update(source[name])
                def write(path, value):
                    path.write_text(json.dumps(value, sort_keys=True) + "\n")
                write(root / "source-manifest.json", manifest)
                command = ["node", "scripts/odyssey-mastery.mjs", "search", "--level", "49", "--seed", "9101",
                           "--output", "/frozen/repo/artifacts/mastery/search/orb49"]
                options = command_options(command, Path("/frozen/repo"))
                runtime = {"node": "v22.fixture", "platform": "linux", "arch": "x64"}
                revision = {"head": "fixture-commit", "sourceHash": digest.hexdigest(), "runtime": runtime}
                registration = {"executionReady": True, "repositoryRoot": "/frozen/repo",
                    "tasks": [{"id": "orb49", "stage": "search", "output": "search/orb49", "command": command}],
                    "sourceFreeze": {"commit": revision["head"], "sourceHash": digest.hexdigest(), "runtime": runtime,
                        "analyzerSha256": sha(Path(__file__).read_bytes()),
                        "sourceManifest": {"path": "source-manifest.json", "sha256": sha((root / "source-manifest.json").read_bytes())},
                        "sourceSnapshot": {"path": "source-snapshot.zip", "sha256": sha((root / "source-snapshot.zip").read_bytes())}}}
                write(root / "registration.json", registration)
                (root / "registration.sha256").write_text(sha((root / "registration.json").read_bytes()) + "  registration.json\n")
                folder = root / "search/orb49"
                folder.mkdir(parents=True)
                config = {"schemaVersion": 1, "options": options, "revision": revision, "candidateSha256": None}
                write(folder / "config.json", config)
                write(folder / "source-manifest.json", manifest)
                candidate = {"schemaVersion": 1, "kind": "targeted-mastery-search", "levelId": 49, "seed": 9101,
                    "previewLimit": 3, "timed": False, "status": "inconclusive", "termination": "no-plan",
                    "budgets": {key: options[key] for key in (*SEARCH_DEFAULTS, "wallBudgetMs")},
                    "trace": [], "traceValid": True, "metrics": {"maxCascadeDepth": 0},
                    "compute": {"predictionMismatches": 0}}
                write(folder / "candidate.json", candidate)
                data = (folder / "candidate.json").read_bytes()
                write(folder / "summary.json", {"status": "completed", "command": "search", "sourceStable": True,
                    "revision": revision, "candidateSha256": None,
                    "result": {"path": "candidate.json", "bytes": len(data), "sha256": sha(data)}})
                first = analyze(root)
                self.assertEqual(first["taskStatuses"], {"completed": 1})
                self.assertFalse(first["tasks"][0]["observation"]["qualifiedUntimedSearchCandidate"])
                relocated = Path(temp) / "different-name" / "extracted"
                shutil.copytree(root, relocated)
                self.assertEqual(first, analyze(relocated))
                (relocated / "search/orb49/candidate.json").write_text("{}\n")
                broken = analyze(relocated)
                self.assertEqual(broken["taskStatuses"], {"verification-error": 1})
                self.assertNotIn("observation", broken["tasks"][0])
                (root / "source-snapshot.zip").write_bytes(b"changed")
                with self.assertRaisesRegex(ValueError, "Source snapshot checksum"):
                    analyze(root)

    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(QualificationTests))
    return result.wasSuccessful()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        raise SystemExit(0 if self_test() else 1)
    result = analyze(args.root)
    output = args.output or args.root / "analysis.json"
    output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"output": str(output), "plannedTasks": result["plannedTasks"],
                      "taskStatuses": result["taskStatuses"], "groups": result["groups"]}, indent=2))


if __name__ == "__main__":
    main()
