#!/usr/bin/env python3
"""Post-result cross-check from raw traces; does not change the frozen analyzer."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
HASHES = {}


def read(name):
    data = (ROOT / name).read_bytes()
    HASHES[name] = hashlib.sha256(data).hexdigest()
    return data


def load(name):
    return json.loads(read(name))


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    reg = load('registration.json')
    freeze = reg['sourceFreeze']
    assert digest(read('registration.json')) == read('registration.sha256').decode().split()[0]
    assert digest(read('analyze.py')) == freeze['analyzerSha256']
    manifest = load(freeze['sourceManifest']['path'])
    assert HASHES[freeze['sourceManifest']['path']] == freeze['sourceManifest']['sha256']
    assert digest(read(freeze['sourceSnapshot']['path'])) == freeze['sourceSnapshot']['sha256']
    source_hash = hashlib.sha256()
    with zipfile.ZipFile(ROOT / freeze['sourceSnapshot']['path']) as archive:
        names = [item.filename for item in archive.infolist() if not item.is_dir()]
        assert len(names) == len(set(names)) and set(names) == set(manifest)
        for name in sorted(names, key=lambda value: value.encode('utf-16-be')):
            data = archive.read(name)
            assert manifest[name] == {'bytes': len(data), 'sha256': digest(data)}
            source_hash.update((name + '\0').encode())
            source_hash.update(data)
    assert source_hash.hexdigest() == freeze['sourceHash']
    searches, replays = [], []
    total_completed_lock_checks = 0
    for task in reg['tasks']:
        folder = task['output']
        config = load(folder + '/config.json')
        summary = load(folder + '/summary.json')
        assert summary['status'] == 'completed' and summary['sourceStable'] is True
        assert summary['revision'] == config['revision']
        for name, expected in [('head', freeze['commit']), ('sourceHash', freeze['sourceHash']), ('runtime', freeze['runtime'])]:
            assert config['revision'][name] == expected
        assert load(folder + '/source-manifest.json') == manifest
        assert config['options']['command'] == task['stage']
        argv = task['command'][3:]
        flags = dict(zip(argv[::2], argv[1::2]))
        option_names = {'--output': 'outputDir', '--wall-ms': 'wallBudgetMs', '--level': 'levelId', '--seed': 'seed',
                        '--max-pieces': 'maxPieces', '--beam-width': 'beamWidth', '--max-nodes': 'maxNodes',
                        '--nodes-per-plan': 'maxNodesPerPlan', '--unknown-tail-depth': 'unknownTailDepth',
                        '--candidate': 'candidatePath', '--mode': 'mode', '--reaction-ms': 'reactionMs',
                        '--action-ms': 'actionIntervalMs', '--max-seconds': 'maxSimSeconds'}
        for flag, value in flags.items():
            assert str(config['options'][option_names[flag]]) == value
        filename = 'candidate.json' if task['stage'] == 'search' else 'replay.json'
        raw = read(folder + '/' + filename)
        assert summary['result'] == {'path': filename, 'bytes': len(raw), 'sha256': digest(raw)}
        result = json.loads(raw)
        trace = result['trace']
        for entry in trace:
            if not entry['completed']:
                continue
            total_completed_lock_checks += 1
            shape = entry['lockedPiece']['shape']
            assert sum(bool(cell) for row in shape for cell in row) == 4
            cells = entry['cellConservation']
            assert cells['expected'] == cells['actual']
            assert cells.get('valid', True) is True and not cells.get('overlap', False)
        if task['stage'] == 'search':
            assert result['traceValid'] is True and len(trace) == result['piecesPlaced']
            assert all(entry['completed'] and entry['predictionMatches'] for entry in trace)
            metrics = result['metrics']
            assert metrics['lines'] == sum(sum(entry['lineClears']) for entry in trace)
            assert metrics['cascades'] == sum(len(entry['lineClears']) >= 2 for entry in trace)
            assert metrics['tetrises'] == sum(value == 4 for entry in trace for value in entry['lineClears'])
            assert metrics['maxCascadeDepth'] == max((len(entry['lineClears']) if len(entry['lineClears']) >= 2 else 0 for entry in trace), default=0)
            for entry in trace:
                assert entry['prediction']['boardHashAfter'] == entry['boardHashAfter']
                assert entry['prediction']['metricsAfter'] == entry['metricsAfter']
                expected = result['initialBoard']['occupiedCells'] + 4 * entry['metricsAfter']['piecesPlaced'] - 10 * entry['metricsAfter']['lines']
                assert entry['cellConservation']['expected'] == expected
            searches.append({'id': task['id'], 'orb': result['levelId'], 'seed': result['seed'],
                             'pieces': result['piecesPlaced'], 'depth': metrics['maxCascadeDepth'],
                             'cascades': metrics['cascades'], 'quads': metrics['tetrises'], 'score': metrics['score'],
                             'primaryGoal': result['requirements']['primary']['target'],
                             'primaryReached': result['quality']['primaryReachedUntimed'],
                             'threeStarsMet': result['quality']['tierThreeUntimedConditionsMet'],
                             'termination': result['termination'], 'predictionMismatches': result['compute']['predictionMismatches']})
        else:
            candidate_raw = read(task['candidate'])
            assert digest(candidate_raw) == config['candidateSha256'] == summary['candidateSha256']
            assert read(folder + '/input-candidate.json') == candidate_raw
            candidate = json.loads(candidate_raw)
            assert result['levelId'] == candidate['levelId'] and result['seed'] == candidate['seed']
            if result['replayValid'] and result['traceComplete']:
                assert len(trace) == len(candidate['trace']) == result['piecesReplayed']
                for expected, actual in zip(candidate['trace'], trace):
                    assert actual['completed']
                    for key in ['shapeKey', 'preview', 'boardHashBefore', 'boardHashAfter']:
                        assert expected[key] == actual[key]
                if not result['timed']:
                    assert result['metrics'] == candidate['metrics']
            quality = result['quality']
            full_timed = (result['timed'] and result['replayValid'] and result['outcome'] == 'win'
                          and result['reason'] in ['primary-goal', 'manual-showcase-finish', 'showcase-top-out']
                          and not result['qualityCensored'] and not quality['censored'] and quality['masteryConditionsMet'])
            replays.append({'id': task['id'], 'orb': result['levelId'], 'seed': result['seed'], 'timed': result['timed'],
                            'cadence': result['cadence'], 'replayValid': result['replayValid'], 'traceComplete': result['traceComplete'],
                            'outcome': result['outcome'], 'reason': result['reason'], 'failure': result['failure'],
                            'piecesReplayed': result['piecesReplayed'], 'depth': result['maximumDepth'], 'score': result['metrics']['score'],
                            'seconds': result['metrics']['time'], 'primaryReached': result['primaryReached'],
                            'primaryCensored': result['outcome'] == 'censored' and not result['primaryReached'],
                            'qualityCensored': result['qualityCensored'], 'threeStarsMet': quality['tierThreeConditionsMet'],
                            'qualifiedTimedFullWitness': full_timed})
    timed = [item for item in replays if item['timed']]
    untimed = [item for item in replays if not item['timed']]
    assert len(searches) == 9 and len(untimed) == 9 and len(timed) == 18
    assert all(item['replayValid'] and item['traceComplete'] for item in untimed)
    assert sum(item['traceComplete'] and item['replayValid'] for item in timed) == 5
    assert all(item['primaryCensored'] and not item['qualityCensored'] for item in timed)
    assert not any(item['qualifiedTimedFullWitness'] for item in timed)
    output = {'kind': 'Post-result independent raw-trace audit; original registration and analyzer unchanged',
              'sourceHashVerified': source_hash.hexdigest(), 'sourceFilesVerified': len(manifest),
              'completedInvocationChecks': len(reg['tasks']), 'completedLockConservationChecks': total_completed_lock_checks,
              'searches': searches, 'replays': replays,
              'counts': {'untimedValidComplete': len(untimed), 'untimedPrimaryWins': sum(item['primaryReached'] for item in untimed),
                         'untimedPrimaryCensors': sum(item['primaryCensored'] for item in untimed),
                         'timedValidComplete': sum(item['traceComplete'] and item['replayValid'] for item in timed),
                         'timedInterrupted': sum(item['reason'] == 'execution-interrupted' for item in timed),
                         'timedFailureReasons': dict(Counter(item['failure']['reason'] for item in timed if item['failure'])),
                         'timedPrimaryCensors': sum(item['primaryCensored'] for item in timed),
                         'timedQualityCensorsAfterPrimary': sum(item['qualityCensored'] for item in timed),
                         'timedFullWitnesses': sum(item['qualifiedTimedFullWitness'] for item in timed)},
              'interpretation': ['qualityCensored=false before primary is not evidence of complete quality observation.',
                                 'All 18 timed attempts are primary-censored: 13 invalid interrupted command traces and 5 complete partial candidates exhausted before primary.',
                                 'Interrupted replays are execution failures of these fixed scripts, not player losses or proof of impossible mastery.',
                                 'No search or replay meets the full joint three-star objective; development misses do not establish human difficulty.'],
              'auditSourceSha256': digest(Path(__file__).read_bytes()), 'inputHashes': dict(sorted(HASHES.items()))}
    (ROOT / 'independent-result-audit.json').write_text(json.dumps(output, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'checks': total_completed_lock_checks, 'counts': output['counts'], 'searches': searches,
                      'validCompleteTimed': [item for item in timed if item['replayValid'] and item['traceComplete']]}, indent=2))


if __name__ == '__main__':
    main()
