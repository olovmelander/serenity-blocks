#!/usr/bin/env python3
"""Run the frozen development plan; preserve failed and incomplete invocations."""
import concurrent.futures
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent.parent


def load(path):
    return json.loads(path.read_text())


def invoke(task):
    log_path = ROOT / 'logs' / (task['id'] + '.log')
    with log_path.open('x') as log:
        result = subprocess.run(task['command'], cwd=REPO, stdout=log, stderr=subprocess.STDOUT)
    return {'id': task['id'], 'exitCode': result.returncode,
            'log': str(log_path.relative_to(ROOT)), 'output': task['output']}


def main():
    registration = load(ROOT / 'registration.json')
    assert registration['executionReady'] is True
    assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest() == registration['runnerSha256']
    assert not (ROOT / 'execution.json').exists(), 'Do not overwrite a completed execution'
    (ROOT / 'logs').mkdir(exist_ok=True)
    records = []
    for stage in ['search', 'replay']:
        tasks = [task for task in registration['tasks'] if task['stage'] == stage]
        eligible = []
        for task in tasks:
            if stage == 'replay':
                candidate = ROOT / task['candidate']
                if not candidate.exists() or not load(candidate).get('trace'):
                    records.append({'id': task['id'], 'status': 'not executed',
                                    'reason': 'Search did not retain a nonempty candidate trace',
                                    'output': task['output']})
                    continue
            eligible.append(task)
        with concurrent.futures.ThreadPoolExecutor(max_workers=registration['workers']) as pool:
            futures = {pool.submit(invoke, task): task for task in eligible}
            for future in concurrent.futures.as_completed(futures):
                task = futures[future]
                try:
                    record = future.result()
                except Exception as error:
                    record = {'id': task['id'], 'status': 'runner error', 'error': str(error),
                              'output': task['output']}
                records.append(record)
                print(json.dumps(record), flush=True)
        (ROOT / ('execution-' + stage + '.json')).write_text(json.dumps(records, indent=2) + '\n')
    (ROOT / 'execution.json').write_text(json.dumps(records, indent=2) + '\n')


if __name__ == '__main__':
    main()
