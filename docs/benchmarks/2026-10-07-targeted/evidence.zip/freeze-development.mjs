import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { captureSourceRevision } from '../../scripts/odyssey-mastery.mjs';

const root = dirname(fileURLToPath(import.meta.url));
const repositoryRoot = resolve(root, '../..');
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const write = (name, value) => writeFileSync(resolve(root, name), `${JSON.stringify(value, null, 2)}\n`, { flag: 'wx' });
if (existsSync(resolve(root, 'registration.json'))) throw new Error('Registration already exists; never overwrite it');
execFileSync('git', ['diff', '--quiet', 'HEAD', '--', 'src', 'scripts', 'tests', 'package.json', 'package-lock.json'], { cwd: repositoryRoot });
const untracked = execFileSync('git', ['ls-files', '--others', '--exclude-standard', '--', 'src', 'scripts', 'tests'],
    { cwd: repositoryRoot, encoding: 'utf8' }).trim();
if (untracked) throw new Error(`Commit the experiment implementation before freezing: ${untracked}`);
const source = captureSourceRevision();
write('source-manifest.json', source.files);
writeFileSync(resolve(root, 'source.patch'), source.patch, { flag: 'wx' });
execFileSync('python3', ['-c', `
import hashlib,json,pathlib,sys,zipfile
root,repo=map(pathlib.Path,sys.argv[1:])
manifest=json.loads((root/'source-manifest.json').read_text())
with zipfile.ZipFile(root/'source-snapshot.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,item in manifest.items():
        data=(repo/name).read_bytes()
        assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
        info=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0))
        info.compress_type=zipfile.ZIP_DEFLATED
        archive.writestr(info,data,compresslevel=9)
`, root, repositoryRoot]);
const tasks = [];
for (const seed of [9101, 9102, 9103]) {
    for (const level of [49, 55, 59]) {
        const id = `orb-${level}-seed-${seed}`;
        const output = `search/${id}`;
        tasks.push({ id, stage: 'search', output, command: [
            'node', 'scripts/odyssey-mastery.mjs', 'search', '--level', String(level), '--seed', String(seed),
            '--max-pieces', '192', '--beam-width', '8', '--max-nodes', '240000', '--nodes-per-plan', '2400',
            '--unknown-tail-depth', '1', '--wall-ms', '240000', '--output', resolve(root, output),
        ] });
        for (const [label, mode, reaction, interval] of [
            ['untimed', 'untimed', 150, 100],
            ['timed-steady', 'timed', 150, 100],
            ['timed-deliberate', 'timed', 300, 180],
        ]) {
            const replayId = `${label}-${id}`;
            const replayOutput = `replay/${replayId}`;
            const candidate = `${output}/candidate.json`;
            tasks.push({ id: replayId, stage: 'replay', output: replayOutput, candidate, command: [
                'node', 'scripts/odyssey-mastery.mjs', 'replay', '--candidate', resolve(root, candidate),
                '--mode', mode, '--reaction-ms', String(reaction), '--action-ms', String(interval),
                '--max-seconds', '1800', '--wall-ms', '120000', '--output', resolve(root, replayOutput),
            ] });
        }
    }
}
const registration = {
    schemaVersion: 1,
    executionReady: true,
    frozenAt: new Date().toISOString(),
    repositoryRoot,
    purpose: 'Bounded development search and independent scripted replay, not fresh confirmation or human calibration.',
    sourceFreeze: {
        commit: source.revision.head,
        sourceHash: source.revision.sourceHash,
        runtime: source.revision.runtime,
        sourceManifest: { path: 'source-manifest.json', sha256: sha(readFileSync(resolve(root, 'source-manifest.json'))) },
        sourceSnapshot: { path: 'source-snapshot.zip', sha256: sha(readFileSync(resolve(root, 'source-snapshot.zip'))) },
        analyzerSha256: sha(readFileSync(resolve(root, 'analyze.py'))),
    },
    runnerSha256: sha(readFileSync(resolve(root, 'run-development.py'))),
    freezeScriptSha256: sha(readFileSync(fileURLToPath(import.meta.url))),
    workers: 3,
    developmentSeeds: [9101, 9102, 9103],
    reservedConfirmationSeedsStart: 11001,
    plannedSearches: 9,
    plannedUntimedReplays: 9,
    plannedTimedReplays: 18,
    selectionRule: 'Replay every nonempty retained search trace, including partial and unsuccessful traces; retain skipped/failed invocations.',
    knowledgePolicy: 'Current piece plus three visible previews. Unknown tail uses a uniform seven-shape surrogate, never the actual hidden bag.',
    timedCadences: [
        { label: 'steady', reactionMs: 150, actionIntervalMs: 100 },
        { label: 'deliberate', reactionMs: 300, actionIntervalMs: 180 },
    ],
    timedScope: 'Fixed command sequences under real authored gravity and live finish semantics; no online replanning or human feasibility claim.',
    reporting: 'Keep validity, trace completion, primary wins, exact tier-three conditions, optional bonuses, budgets and quality censoring separate. Retain every failure. No policy adoption or authored retune gate.',
    tasks,
};
write('registration.json', registration);
writeFileSync(resolve(root, 'registration.sha256'), `${sha(readFileSync(resolve(root, 'registration.json')))}  registration.json\n`, { flag: 'wx' });
process.stdout.write(`${JSON.stringify({ commit: source.revision.head, sourceHash: source.revision.sourceHash, tasks: tasks.length })}\n`);
