import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
DESTINATION = ROOT.parent.parent / 'docs/benchmarks/2026-10-07-targeted'


def sha(data):
    return hashlib.sha256(data).hexdigest()


analysis = json.loads((ROOT / 'analysis.json').read_text())
registration = json.loads((ROOT / 'registration.json').read_text())
validation = json.loads((ROOT / 'validation.json').read_text())
assert analysis['allObservedProvenanceVerified'] and analysis['allPlannedInvocationsCompleted']
assert analysis['taskStatuses'] == {'completed': 36}
assert validation['fullSuite']['exitCode'] == 0
files = [path for path in sorted(ROOT.rglob('*')) if path.is_file()
         and '__pycache__' not in path.parts and path.suffix != '.pyc']
DESTINATION.mkdir(parents=True, exist_ok=True)
archive_path = DESTINATION / 'evidence.zip'
members = []
with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in files:
        name = path.relative_to(ROOT).as_posix()
        data = path.read_bytes()
        info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        archive.writestr(info, data, compresslevel=9)
        members.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
manifest = {
    'schemaVersion': 1,
    'sourceCommit': registration['sourceFreeze']['commit'],
    'sourceHash': registration['sourceFreeze']['sourceHash'],
    'searches': 9, 'untimedReplays': 9, 'timedReplays': 18,
    'developmentSeeds': registration['developmentSeeds'],
    'humanCalibration': False,
    'archive': {'path': archive_path.name, 'bytes': archive_path.stat().st_size,
                'sha256': sha(archive_path.read_bytes())},
    'files': members,
}
(DESTINATION / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'members': len(members), **manifest['archive']}, indent=2))
